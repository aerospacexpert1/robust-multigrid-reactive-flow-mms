# Benchmark A-E Ubuntu + TRUBA rerun package

This package is designed for the final rerun of the RMT benchmark campaign used in the thesis. It keeps the existing Benchmark A-E solver families and CSV conventions, but separates **performance timing**, **field/contour output**, and **Benchmark D code verification** so that the final thesis results can be regenerated cleanly on TRUBA.

## 1. What is in the package

- `src/` — updated A-E C sources.
- `original_sources/` — archived pre-update sources for audit/diff.
- `scripts/workflow.sh` — common Ubuntu/TRUBA workflow.
- `scripts/run_local.sh` — local Ubuntu entry point.
- `slurm/run_all_benchmarks.slurm` — one TRUBA Slurm job for the complete campaign.
- `scripts/collect_performance.py` — merges performance summaries into thesis-ready CSV tables.
- `scripts/collect_benchmarkD_verification.py` — computes Benchmark D observed order and PASS/FAIL checks.
- `results/` — generated outputs.

The four solver names are unchanged:
`gsRB`, `mg33`, `rmt3p6`, `rmt3c4p6`.

## 2. Important timing change

During a performance campaign use:

```bash
-writeCSV 1 -writeFields 0
```

Summary CSV files are still created, but exact/solution fields are not written. This prevents disk I/O and very large n=431 contour files from contaminating or bloating the timing campaign. The thesis contour cases are generated separately by the `fields` stage.

For B/C/E, `mg33Profile` is disabled in performance runs. Otherwise MG33 alone contains extra profiling-clock calls inside its cycle, which is not a clean wall-clock comparison against RMT.

## 3. Ubuntu

Requirements: GCC with OpenMP support and Python 3. On Ubuntu/Debian, `build-essential` and `python3` are sufficient.

First run the smoke test:

```bash
unzip Benchmark_A-E_TRUBA_Rerun_2026.zip
cd Benchmark_A-E_TRUBA_Rerun_2026
chmod +x scripts/*.sh
./scripts/run_local.sh smoke
```

Then choose one stage:

```bash
./scripts/run_local.sh performance
./scripts/run_local.sh verifyD
./scripts/run_local.sh fields
./scripts/run_local.sh all
```

`all` can be a long calculation. `smoke` is intentionally small.

## 4. TRUBA / Slurm

Transfer and unzip the package in your project/scratch area, then submit **from the package root**:

```bash
mkdir -p logs
sbatch slurm/run_all_benchmarks.slurm
```

The supplied job requests one node, one task and 4 CPUs per task. It does not hard-code an account or partition because those depend on the active TRUBA allocation. Add the required `#SBATCH --account=...` or `#SBATCH --partition=...` only if your allocation requires it.

The job sets:

```bash
OMP_DYNAMIC=FALSE
OMP_PROC_BIND=close
OMP_PLACES=cores
```

so OpenMP runs are pinned rather than migrating between cores.

Timing defaults can be overridden at submission:

```bash
TIMING_REPEATS=5 A_OUTER_REPEATS=7 sbatch slurm/run_all_benchmarks.slurm
```

A uses independent outer repeats because the A source predates the internal median-timing implementation used in B-E.

## 5. Performance campaign

The performance stage recreates the final benchmark families without writing contour fields.

- **A:** the pruned final A campaign, repeated independently 5 times by default.
- **B:** n = 53,107,215 and amplitude = 0.25,0.50,0.75.
- **C:** final stress defaults, including both flow families, n = 107,215,431 and Pe = 200,800,3200.
- **D:** the nonlinear Arrhenius performance campaign remains separate from its MMS order test.
- **E:** final momentum-like campaign with both families, n = 53,107,215 and Re/advection = 200,800,3200.

After the runs, the collector writes:

- `results/collected/performance_long.csv`
- `results/collected/performance_aggregated.csv`
- `results/collected/performance_thesis_table.csv`
- `results/collected/performance_best_by_config.csv`

`performance_thesis_table.csv` is the main table for updating wall-clock/speedup plots in the thesis.

## 6. Field/contour cases

The `fields` stage writes exact and solution CSVs for the representative cases used in the archived thesis campaign, including the n=431 C/D stress plots. Because this stage is not used for performance timing, large CSV output is acceptable here.

Output is grouped below `results/field_cases/A` through `E` so files from different configurations cannot overwrite one another.

## 7. Benchmark D: corrected continuous-MMS verification

The D source already uses an analytical manufactured temperature field, analytical continuous forcing, and analytical Dirichlet data. The problem in the previous interpretation is that D also uses **first-order upwind advection**. Consequently, it is not correct to demand second-order convergence from the full `PeRef=800` operator.

The new verification stage deliberately runs two complementary continuous-MMS studies on

```text
n = 53, 107, 215, 431
h = 1/(n+1)
```

so each refinement halves h exactly.

### D-ADV: full advective nonlinear operator

```text
PeRef        = 800
reactRef     = 1e3
picardRelax  = 0.60
expected p   = 1
```

The expected first-order behavior follows from the first-order upwind term.

### D-DIFFREACT: diffusion-reaction isolation

```text
PeRef        = 0
reactRef     = 1e2
picardRelax  = 0.20
expected p   = 2
```

This isolates the second-order finite-volume diffusion-reaction spatial core and uses a stable Picard setting.

Both studies use `tol=1e-10`, MG33 with one thread for the verification solve, and continuous forcing. The verification solver choice is not a performance claim; it is chosen so all four meshes converge without the n=431 GS cost dominating the test.

The collector computes for L2 and Linf:

```text
p = log(E_h / E_h/2) / log(h / (h/2))
```

for 53->107, 107->215 and 215->431, plus a four-grid log(error)-log(h) regression slope. PASS requires converged/non-timeout rows, monotone error decrease, the final two pair orders within the expected-order band, and the regression slope within the same band.

The package uses an explicit acceptance band of **expected order +/- 0.20**. This is a project tolerance used to automate the check; it is not presented as a universal Oberkampf/Roy tolerance.

Outputs:

- `results/collected/benchmarkD_order_pairs.csv`
- `results/collected/benchmarkD_order_summary.csv`
- `results/collected/benchmarkD_order_summary.txt`

This is the material to use when rewriting the Benchmark D thesis section from the beginning. Performance results should not be mixed with the code-verification order study.

## 8. Recommended thesis update sequence

1. Rerun the TRUBA `performance` campaign and replace A/B/C/E timing and speedup plots/tables.
2. Use the `fields` output only where contours/solution/error fields need regeneration.
3. Replace Benchmark D methodology/results with the two continuous-MMS order studies above, then report its performance separately.
4. Preserve residual and error columns alongside timing; do not infer numerical correctness from speedup alone.

## 9. Reference basis for the D protocol

The verification structure follows the code-verification principles in:

William L. Oberkampf and Christopher J. Roy, *Verification and Validation in Scientific Computing*, Cambridge University Press, 2010 — especially systematic mesh refinement, order verification, MMS, and separation of iterative error from discretization error.

The RMT solver comparison remains based on the Martynenko robust-multigrid framework already used throughout the thesis.
