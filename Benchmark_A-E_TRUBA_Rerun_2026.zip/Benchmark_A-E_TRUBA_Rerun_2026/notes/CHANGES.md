# Changes in the TRUBA/Ubuntu rerun package

## All Benchmark A-E sources
- Added `-writeFields 0|1`.
- `-writeCSV 1 -writeFields 0` writes summary CSV files but suppresses large exact/solution/profile field files.
- Numerical operators, solver cycles, tolerances, transfer operations, and smoothing algorithms were not changed by this output-control update.

## Timing protocol
- Benchmark A has no internal timing-repeat implementation. The workflow runs the entire A performance campaign 5 independent times and the collector reports the median/min/max across repeats.
- Benchmarks B-E retain their internal repeated timing. The workflow uses 3 repeats by default (`TIMING_REPEATS`).
- `mg33Profile` is disabled in B/C/E timing campaigns to prevent profiler instrumentation from biasing MG33 wall-clock time relative to the other solvers.
- OpenMP dynamic teams are disabled and threads are pinned to cores.

## Benchmark D correction / verification
The existing D source already manufactures its forcing from the **continuous nonlinear PDE** and applies analytical Dirichlet data. The methodological problem is the interpretation of spatial order:

- The D advection discretization is first-order upwind. Therefore a continuous-MMS run with `PeRef != 0` has formal global order **p=1**, not p=2.
- The package adds a `verificationMode` so 53,107,215,431 can be run with a single converged solver (default workflow: MG33, 1 thread) without spending most of the job on the slow GS baseline at n=431.
- Advective verification: `PeRef=800`, `reactRef=1e3`, expected p=1.
- Diffusion-reaction isolation verification: `PeRef=0`, `reactRef=1e2`, `picardRelax=0.2`, expected p=2.
- Both use continuous forcing, grids 53/107/215/431, and `tol=1e-10` so iterative error is small relative to discretization error.
- The collector checks L2 and Linf errors, pairwise observed orders, four-grid log-log regression order, monotone error decrease, convergence, and timeout status.
- The +/-0.20 order tolerance is an explicit project acceptance criterion, **not** a universal value prescribed by Oberkampf and Roy.

This separation lets the rewritten thesis section make two defensible claims: the full advective D operator demonstrates its expected first-order behavior, while the diffusion-reaction spatial core independently demonstrates second-order behavior.
