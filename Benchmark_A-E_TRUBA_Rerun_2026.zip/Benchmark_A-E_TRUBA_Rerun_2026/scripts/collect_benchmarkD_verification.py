#!/usr/bin/env python3
"""Oberkampf-style continuous-MMS order collector for Benchmark D.
Protocol in this package:
  advective: PeRef=800, reactRef=1e3 -> expected p=1 (first-order upwind dominates)
  diffusion_reaction: PeRef=0, reactRef=1e2 -> expected p=2
Acceptance tolerance +/-0.20 is a project criterion, not a universal Oberkampf tolerance.
"""
from pathlib import Path
import csv, math, sys
ROOT=Path(__file__).resolve().parents[1]
INROOT=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/"results"/"benchmarkD_verification"
OUT=ROOT/"results"/"collected"; OUT.mkdir(parents=True,exist_ok=True)
REGIMES={
    "advective":{"expected":1.0,"tol":0.20,"description":"PeRef=800, first-order upwind + continuous MMS"},
    "diffusion_reaction":{"expected":2.0,"tol":0.20,"description":"PeRef=0, second-order diffusion-reaction continuous MMS"},
}

def read_csv(p):
    try:
        if p.stat().st_size < 20:return []
        with p.open(newline="") as f:return list(csv.DictReader(f))
    except:return []

def load_regime(d):
    g=d/"csv_benchmarkD_v2_arrhenius_mms"/"all_runs_summary.csv"
    rows=read_csv(g)
    if rows:return rows
    # robust fallback if job stopped before global file was closed
    out=[]
    for p in sorted((d/"csv_benchmarkD_v2_arrhenius_mms").glob("*_summary.csv")):
        if p.name=="all_runs_summary.csv":continue
        out.extend(read_csv(p))
    return out

def slope(xs,ys):
    xm=sum(xs)/len(xs); ym=sum(ys)/len(ys)
    den=sum((x-xm)**2 for x in xs)
    return sum((x-xm)*(y-ym) for x,y in zip(xs,ys))/den if den else math.nan

detail=[]; summary=[]; text=[]
for regime,cfg in REGIMES.items():
    rows=load_regime(INROOT/regime)
    # verification mode should have one solver/thread; retain only converged-looking data and sort meshes
    rows=sorted(rows,key=lambda r:int(r["n"]))
    if len(rows)<4:
        summary.append({"regime":regime,"status":"FAIL_MISSING_MESHES","expected_order":cfg["expected"],"tolerance":cfg["tol"],"n_meshes":len(rows)})
        text.append(f"{regime}: FAIL - found {len(rows)} mesh rows, expected 4")
        continue
    conv=all(int(r.get("converged","0"))==1 and int(r.get("timed_out","0"))==0 for r in rows)
    meshes=[int(r["n"]) for r in rows]; hs=[float(r["h"]) for r in rows]
    regime_pass=conv and meshes==[53,107,215,431]
    metrics={}
    for norm in ("error_l2","error_inf"):
        errs=[float(r[norm]) for r in rows]
        mono=all(errs[i+1] < errs[i] for i in range(3))
        pair_orders=[]
        for i in range(3):
            p=math.log(errs[i]/errs[i+1])/math.log(hs[i]/hs[i+1])
            ok=abs(p-cfg["expected"]) <= cfg["tol"]
            pair_orders.append(p)
            detail.append({"regime":regime,"norm":norm,"coarse_n":meshes[i],"fine_n":meshes[i+1],
                           "h_coarse":hs[i],"h_fine":hs[i+1],"error_coarse":errs[i],"error_fine":errs[i+1],
                           "observed_order":p,"expected_order":cfg["expected"],"tolerance":cfg["tol"],"pair_pass":int(ok)})
        preg=slope([math.log(h) for h in hs],[math.log(e) for e in errs])
        # asymptotic acceptance: last two pair orders + four-grid regression.
        ok_asym=all(abs(p-cfg["expected"])<=cfg["tol"] for p in pair_orders[-2:]) and abs(preg-cfg["expected"])<=cfg["tol"]
        metric_pass=mono and ok_asym
        regime_pass=regime_pass and metric_pass
        metrics[norm]=(errs,pair_orders,preg,mono,metric_pass)
    status="PASS" if regime_pass else "FAIL"
    r0=rows[0]
    rec={"regime":regime,"status":status,"solver":r0.get("solver",""),"threads":r0.get("threads",""),
         "meshes":"53;107;215;431","expected_order":cfg["expected"],"tolerance":cfg["tol"],"converged_all":int(conv),"n_meshes":len(rows)}
    for norm,(_,po,pr,mono,mp) in metrics.items():
        prefix="l2" if norm=="error_l2" else "linf"
        rec.update({f"{prefix}_p_53_107":po[0],f"{prefix}_p_107_215":po[1],f"{prefix}_p_215_431":po[2],
                    f"{prefix}_p_regression":pr,f"{prefix}_monotone":int(mono),f"{prefix}_pass":int(mp)})
    summary.append(rec)
    text.append(f"{regime}: {status} | expected p={cfg['expected']:.1f} +/- {cfg['tol']:.2f} | solver={r0.get('solver')} t={r0.get('threads')}")
    text.append(f"  L2   pairs={metrics['error_l2'][1][0]:.4f}, {metrics['error_l2'][1][1]:.4f}, {metrics['error_l2'][1][2]:.4f}; regression={metrics['error_l2'][2]:.4f}")
    text.append(f"  Linf pairs={metrics['error_inf'][1][0]:.4f}, {metrics['error_inf'][1][1]:.4f}, {metrics['error_inf'][1][2]:.4f}; regression={metrics['error_inf'][2]:.4f}")

if detail:
    with (OUT/"benchmarkD_order_pairs.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(detail[0].keys()));w.writeheader();w.writerows(detail)
if summary:
    keys=[]
    for r in summary:
        for k in r:
            if k not in keys:keys.append(k)
    with (OUT/"benchmarkD_order_summary.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(summary)
(OUT/"benchmarkD_order_summary.txt").write_text("\n".join(text)+"\n")
print("\n".join(text))
