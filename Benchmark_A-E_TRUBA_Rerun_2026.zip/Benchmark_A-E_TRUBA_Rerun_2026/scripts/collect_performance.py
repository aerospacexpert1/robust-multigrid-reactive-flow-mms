#!/usr/bin/env python3
"""Collect Benchmark A-E performance summaries into thesis-friendly CSV files.
Uses only Python standard library so it works on a clean TRUBA login/compute node.
"""
from pathlib import Path
import csv, math, statistics, sys

ROOT = Path(__file__).resolve().parents[1]
INROOT = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "results" / "performance"
OUTDIR = ROOT / "results" / "collected"
OUTDIR.mkdir(parents=True, exist_ok=True)

bench_map = {
    "A": "Benchmark A", "B": "Benchmark B", "C": "Benchmark C",
    "D": "Benchmark D", "E": "Benchmark E"
}

def fnum(x, default=math.nan):
    try: return float(x)
    except Exception: return default

def inum(x, default=0):
    try: return int(float(x))
    except Exception: return default

def detect_benchmark(path: Path):
    parts = list(path.parts)
    for p in parts:
        if p in bench_map: return p
    # fallback from folder/source naming
    txt = str(path)
    for p in bench_map:
        if f"/{p}/" in txt or f"Benchmark{p}" in txt or f"benchmark{p}" in txt:
            return p
    return "?"

def read_nonempty_csv(path):
    try:
        if path.stat().st_size < 10: return []
        with path.open(newline="") as f:
            return list(csv.DictReader(f))
    except Exception:
        return []

files = sorted(INROOT.rglob("all_runs_summary.csv"))
rows = []
for path in files:
    b = detect_benchmark(path)
    for r in read_nonempty_csv(path):
        tcol = "solve_s_median" if "solve_s_median" in r else "solve_s"
        rr = dict(r)
        rr["benchmark"] = b
        try:
            rr["source_file"] = str(path.relative_to(ROOT))
        except ValueError:
            rr["source_file"] = str(path)
        rr["time_s"] = r.get(tcol, "")
        rr["outer_repeat"] = next((p for p in path.parts if p.startswith("rep")), "")
        rows.append(rr)

if not rows:
    print(f"No performance all_runs_summary.csv files found below {INROOT}", file=sys.stderr)
    sys.exit(2)

# Long normalized file: union of columns, with normalized time_s.
preferred = ["benchmark","problem","stiff_name","stiff_value","n","h","solver","threads",
             "converged","timed_out","iterations","outer_iterations","residual_rel","error_inf","error_l2",
             "time_s","solve_s_median","solve_s_min","solve_s_max","solve_s","timing_repeats","speedup",
             "outer_repeat","source_file"]
allkeys = []
for r in rows:
    for k in r:
        if k not in allkeys: allkeys.append(k)
fields = preferred + [k for k in allkeys if k not in preferred]
with (OUTDIR/"performance_long.csv").open("w", newline="") as f:
    w=csv.DictWriter(f, fieldnames=fields, extrasaction="ignore"); w.writeheader(); w.writerows(rows)

# Aggregate repeated campaign results. Group only on benchmark/config/solver/thread.
def key(r):
    return (r.get("benchmark","?"), r.get("problem",""), r.get("stiff_name",""), r.get("stiff_value",""),
            r.get("n",""), r.get("h",""), r.get("solver",""), r.get("threads",""))

groups={}
for r in rows: groups.setdefault(key(r), []).append(r)
agg=[]
for k, rs in sorted(groups.items()):
    times=[fnum(r.get("time_s")) for r in rs if math.isfinite(fnum(r.get("time_s")))]
    base=rs[0]
    rec={
        "benchmark":k[0], "problem":k[1], "stiff_name":k[2], "stiff_value":k[3], "n":k[4], "h":k[5],
        "solver":k[6], "threads":k[7], "samples":len(times),
        "time_median_s": statistics.median(times) if times else math.nan,
        "time_min_s": min(times) if times else math.nan,
        "time_max_s": max(times) if times else math.nan,
        "converged_all": int(all(inum(r.get("converged"))==1 for r in rs)),
        "timed_out_any": int(any(inum(r.get("timed_out"))==1 for r in rs)),
        "iterations": base.get("iterations", base.get("outer_iterations","")),
        "residual_rel": base.get("residual_rel",""), "error_inf":base.get("error_inf",""), "error_l2":base.get("error_l2","")
    }
    agg.append(rec)

agg_fields=["benchmark","problem","stiff_name","stiff_value","n","h","solver","threads","samples",
            "time_median_s","time_min_s","time_max_s","converged_all","timed_out_any","iterations","residual_rel","error_inf","error_l2"]
with (OUTDIR/"performance_aggregated.csv").open("w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=agg_fields); w.writeheader(); w.writerows(agg)

# Wide thesis table: serial vs 4-thread side by side.
basekey=lambda r:(r["benchmark"],r["problem"],r["stiff_name"],r["stiff_value"],r["n"],r["h"],r["solver"])
pairs={}
for r in agg:
    pairs.setdefault(basekey(r),{})[inum(r["threads"])]=r
wide=[]
for k,d in sorted(pairs.items()):
    r1=d.get(1); r4=d.get(4)
    t1=fnum(r1["time_median_s"]) if r1 else math.nan
    t4=fnum(r4["time_median_s"]) if r4 else math.nan
    wide.append({
        "benchmark":k[0],"problem":k[1],"stiff_name":k[2],"stiff_value":k[3],"n":k[4],"h":k[5],"solver":k[6],
        "serial_time_s":t1,"parallel4_time_s":t4,"speedup_1_to_4":(t1/t4 if t4>0 and math.isfinite(t1) else math.nan),
        "serial_converged":r1["converged_all"] if r1 else "","parallel4_converged":r4["converged_all"] if r4 else "",
        "serial_timed_out":r1["timed_out_any"] if r1 else "","parallel4_timed_out":r4["timed_out_any"] if r4 else "",
        "iterations_serial":r1["iterations"] if r1 else "","iterations_parallel4":r4["iterations"] if r4 else "",
        "residual_rel_serial":r1["residual_rel"] if r1 else "","error_inf_serial":r1["error_inf"] if r1 else "","error_l2_serial":r1["error_l2"] if r1 else "",
        "serial_samples":r1["samples"] if r1 else "","parallel4_samples":r4["samples"] if r4 else ""
    })
wide_fields=list(wide[0].keys())
with (OUTDIR/"performance_thesis_table.csv").open("w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=wide_fields); w.writeheader(); w.writerows(wide)

# Best-per-configuration table for narrative/plots.
config_groups={}
for r in wide:
    ck=(r["benchmark"],r["problem"],r["stiff_name"],r["stiff_value"],r["n"],r["h"])
    config_groups.setdefault(ck,[]).append(r)
best=[]
for ck,rs in sorted(config_groups.items()):
    conv=[r for r in rs if str(r["serial_converged"])=="1"]
    conv4=[r for r in rs if str(r["parallel4_converged"])=="1"]
    bs=min(conv,key=lambda r:fnum(r["serial_time_s"],math.inf)) if conv else None
    bp=min(conv4,key=lambda r:fnum(r["parallel4_time_s"],math.inf)) if conv4 else None
    best.append({"benchmark":ck[0],"problem":ck[1],"stiff_name":ck[2],"stiff_value":ck[3],"n":ck[4],"h":ck[5],
                 "fastest_serial_solver":bs["solver"] if bs else "","fastest_serial_s":bs["serial_time_s"] if bs else "",
                 "fastest_parallel4_solver":bp["solver"] if bp else "","fastest_parallel4_s":bp["parallel4_time_s"] if bp else "",
                 "parallel4_speedup_of_winner":bp["speedup_1_to_4"] if bp else ""})
with (OUTDIR/"performance_best_by_config.csv").open("w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=list(best[0].keys())); w.writeheader(); w.writerows(best)

print(f"Collected {len(rows)} rows from {len(files)} campaign summaries")
print(OUTDIR/"performance_thesis_table.csv")
