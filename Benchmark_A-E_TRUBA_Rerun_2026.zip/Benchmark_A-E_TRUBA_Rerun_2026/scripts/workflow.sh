#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SRC="$ROOT/src"; BIN="$ROOT/bin"; RES="$ROOT/results"
mkdir -p "$BIN" "$RES" "$ROOT/logs"
export OMP_DYNAMIC=FALSE
export OMP_PROC_BIND=${OMP_PROC_BIND:-close}
export OMP_PLACES=${OMP_PLACES:-cores}
TIMING_REPEATS=${TIMING_REPEATS:-3}
A_OUTER_REPEATS=${A_OUTER_REPEATS:-5}
CC=${CC:-gcc}
CFLAGS=${CFLAGS:-"-O3 -std=c11 -fopenmp"}

compile_all(){
  echo "[compile] CC=$CC CFLAGS=$CFLAGS"
  $CC $CFLAGS "$SRC/benchmarkA_2d_pruned_final_parallel_csv_fixed.c" -lm -o "$BIN/benchmarkA"
  $CC $CFLAGS "$SRC/benchmarkB_v1_variable_diffusion_parallel_csv_final.c" -lm -o "$BIN/benchmarkB"
  $CC $CFLAGS "$SRC/benchmarkC_v2_rmtstress_parallel_csv.c" -lm -o "$BIN/benchmarkC"
  $CC $CFLAGS "$SRC/benchmarkD_v2_arrhenius_mms_parallel_csv.c" -lm -o "$BIN/benchmarkD"
  $CC $CFLAGS "$SRC/benchmarkE_v1_momentum_mms_parallel_csv_final.c" -lm -o "$BIN/benchmarkE"
}
run_logged(){
  local dir="$1"; shift
  mkdir -p "$dir"
  printf '[run] %s\n' "$dir"
  ( cd "$dir" && "$@" > run.log 2>&1 )
}

performance(){
  mkdir -p "$RES/performance"
  # A has no internal timing-repeat statistic, so perform independent campaign repeats.
  for rep in $(seq -w 1 "$A_OUTER_REPEATS"); do
    run_logged "$RES/performance/A/rep${rep}" "$BIN/benchmarkA" \
      -writeCSV 1 -writeFields 0 -maxSolveSeconds 60
  done
  # B: thesis amplitude family, 53/107/215. MG33 profiling disabled during timing.
  run_logged "$RES/performance/B/campaign" "$BIN/benchmarkB" \
      -meshSweep 1 -nList 53,107,215 -ampSweep 1 -ampList 0.25,0.5,0.75 \
      -timingRepeats "$TIMING_REPEATS" -mg33Profile 0 -includeUnfairMeshes 1 \
      -writeCSV 1 -writeFields 0 -maxSolveSeconds 60
  # C: retain final stress campaign defaults (107/215/431 x Pe 200/800/3200, both families).
  run_logged "$RES/performance/C/campaign" "$BIN/benchmarkC" \
      -timingRepeats "$TIMING_REPEATS" -mg33Profile 0 -includeUnfairMeshes 1 \
      -writeCSV 1 -writeFields 0 -maxSolveSeconds 60
  # D performance remains separate from D code-verification.
  run_logged "$RES/performance/D/campaign" "$BIN/benchmarkD" \
      -timingRepeats "$TIMING_REPEATS" -includeUnfairMeshes 1 \
      -writeCSV 1 -writeFields 0 -maxSolveSeconds 60
  # E: final momentum-like campaign defaults.
  run_logged "$RES/performance/E/campaign" "$BIN/benchmarkE" \
      -timingRepeats "$TIMING_REPEATS" -mg33Profile 0 -includeUnfairMeshes 1 \
      -writeCSV 1 -writeFields 0 -maxSolveSeconds 60
  python3 "$ROOT/scripts/collect_performance.py"
}

verifyD(){
  mkdir -p "$RES/benchmarkD_verification"
  # Continuous MMS with the original advective D operator. Formal order is 1 due to first-order upwind.
  run_logged "$RES/benchmarkD_verification/advective" "$BIN/benchmarkD" \
      -case reactFlow -meshSweep 1 -stiffSweep 0 -nList 53,107,215,431 \
      -reactRef 1e3 -PeRef 800 -picardRelax 0.60 \
      -tol 1e-10 -maxIter 1200 -timingRepeats 1 -maxSolveSeconds 60 \
      -includeUnfairMeshes 1 -verificationMode 1 -verificationSolver mg33 -verificationThreads 1 \
      -writeCSV 1 -writeFields 0
  # Isolated second-order diffusion-reaction MMS check. Lower Da/relaxation is used so Picard error is negligible and converged.
  run_logged "$RES/benchmarkD_verification/diffusion_reaction" "$BIN/benchmarkD" \
      -case reactFlow -meshSweep 1 -stiffSweep 0 -nList 53,107,215,431 \
      -reactRef 1e2 -PeRef 0 -picardRelax 0.20 \
      -tol 1e-10 -maxIter 1200 -timingRepeats 1 -maxSolveSeconds 60 \
      -includeUnfairMeshes 1 -verificationMode 1 -verificationSolver mg33 -verificationThreads 1 \
      -writeCSV 1 -writeFields 0
  python3 "$ROOT/scripts/collect_benchmarkD_verification.py"
}

fields(){
  mkdir -p "$RES/field_cases"
  # Cases corresponding to the thesis contour/solution selections in the archived campaign.
  run_logged "$RES/field_cases/A/poisson_n107_q100" "$BIN/benchmarkA" -case poisson -meshSweep 0 -stiffSweep 0 -n 107 -poissonQ 100 -writeCSV 1 -writeFields 1 -maxSolveSeconds 120
  run_logged "$RES/field_cases/A/jump_n107_c1e6" "$BIN/benchmarkA" -case jump -meshSweep 0 -stiffSweep 0 -n 107 -jumpContrast 1e6 -writeCSV 1 -writeFields 1 -maxSolveSeconds 120
  run_logged "$RES/field_cases/A/aniso_n107_ky003" "$BIN/benchmarkA" -case aniso -meshSweep 0 -stiffSweep 0 -n 107 -anisoKy 0.03 -writeCSV 1 -writeFields 1 -maxSolveSeconds 120
  run_logged "$RES/field_cases/A/aniso_n107_ky0003" "$BIN/benchmarkA" -case aniso -meshSweep 0 -stiffSweep 0 -n 107 -anisoKy 0.003 -writeCSV 1 -writeFields 1 -maxSolveSeconds 120

  for amp in 0.25 0.5 0.75; do
    run_logged "$RES/field_cases/B/amp_${amp}" "$BIN/benchmarkB" -case smooth -meshSweep 0 -ampSweep 0 -n 107 -amp "$amp" -timingRepeats 1 -mg33Profile 0 -includeUnfairMeshes 1 -writeCSV 1 -writeFields 1 -maxSolveSeconds 120
  done

  run_logged "$RES/field_cases/C/constFlow_n215_Pe800" "$BIN/benchmarkC" -case constFlow -meshSweep 0 -peSweep 0 -n 215 -PeRef 800 -timingRepeats 1 -mg33Profile 0 -includeUnfairMeshes 1 -writeCSV 1 -writeFields 1 -maxSolveSeconds 180
  run_logged "$RES/field_cases/C/advAniso_n215_Pe800" "$BIN/benchmarkC" -case advAniso -meshSweep 0 -peSweep 0 -n 215 -PeRef 800 -timingRepeats 1 -mg33Profile 0 -includeUnfairMeshes 1 -writeCSV 1 -writeFields 1 -maxSolveSeconds 180
  run_logged "$RES/field_cases/C/advAniso_n431_Pe3200" "$BIN/benchmarkC" -case advAniso -meshSweep 0 -peSweep 0 -n 431 -PeRef 3200 -timingRepeats 1 -mg33Profile 0 -includeUnfairMeshes 1 -writeCSV 1 -writeFields 1 -maxSolveSeconds 300

  run_logged "$RES/field_cases/D/reactFlow_n215_react1e4" "$BIN/benchmarkD" -case reactFlow -meshSweep 0 -stiffSweep 0 -n 215 -reactRef 1e4 -timingRepeats 1 -includeUnfairMeshes 1 -writeCSV 1 -writeFields 1 -maxSolveSeconds 300
  run_logged "$RES/field_cases/D/reactAniso_n215_react1e2" "$BIN/benchmarkD" -case reactAniso -meshSweep 0 -stiffSweep 0 -n 215 -reactRef 1e2 -timingRepeats 1 -includeUnfairMeshes 1 -writeCSV 1 -writeFields 1 -maxSolveSeconds 300
  run_logged "$RES/field_cases/D/reactAniso_n431_react1e5" "$BIN/benchmarkD" -case reactAniso -meshSweep 0 -stiffSweep 0 -n 431 -reactRef 1e5 -timingRepeats 1 -includeUnfairMeshes 1 -writeCSV 1 -writeFields 1 -maxSolveSeconds 300

  run_logged "$RES/field_cases/E/momFlow_n107_Re800" "$BIN/benchmarkE" -case momFlow -meshSweep 0 -peSweep 0 -n 107 -PeRef 800 -timingRepeats 1 -mg33Profile 0 -includeUnfairMeshes 1 -writeCSV 1 -writeFields 1 -maxSolveSeconds 180
  run_logged "$RES/field_cases/E/momShear_n107_Re800" "$BIN/benchmarkE" -case momShear -meshSweep 0 -peSweep 0 -n 107 -PeRef 800 -timingRepeats 1 -mg33Profile 0 -includeUnfairMeshes 1 -writeCSV 1 -writeFields 1 -maxSolveSeconds 180
}

smoke(){
  rm -rf "$RES/smoke"; mkdir -p "$RES/smoke"
  run_logged "$RES/smoke/A" "$BIN/benchmarkA" -case poisson -meshSweep 0 -stiffSweep 0 -n 53 -poissonQ 100 -writeCSV 1 -writeFields 0 -maxSolveSeconds 5
  run_logged "$RES/smoke/B" "$BIN/benchmarkB" -case smooth -meshSweep 0 -ampSweep 0 -n 53 -amp 0.5 -timingRepeats 1 -mg33Profile 0 -includeUnfairMeshes 1 -writeCSV 1 -writeFields 0 -maxSolveSeconds 5
  run_logged "$RES/smoke/C" "$BIN/benchmarkC" -case constFlow -meshSweep 0 -peSweep 0 -n 53 -PeRef 200 -timingRepeats 1 -mg33Profile 0 -includeUnfairMeshes 1 -writeCSV 1 -writeFields 0 -maxSolveSeconds 5
  run_logged "$RES/smoke/D" "$BIN/benchmarkD" -case reactFlow -meshSweep 0 -stiffSweep 0 -n 53 -reactRef 1e3 -timingRepeats 1 -includeUnfairMeshes 1 -verificationMode 1 -verificationSolver mg33 -verificationThreads 1 -writeCSV 1 -writeFields 0 -maxSolveSeconds 5
  run_logged "$RES/smoke/E" "$BIN/benchmarkE" -case momFlow -meshSweep 0 -peSweep 0 -n 53 -PeRef 200 -timingRepeats 1 -mg33Profile 0 -includeUnfairMeshes 1 -writeCSV 1 -writeFields 0 -maxSolveSeconds 5
  echo "Smoke test complete."
}

cmd=${1:-all}
case "$cmd" in
  compile) compile_all ;;
  smoke) compile_all; smoke ;;
  performance) compile_all; performance ;;
  verifyD) compile_all; verifyD ;;
  fields) compile_all; fields ;;
  all) compile_all; performance; verifyD; fields ;;
  *) echo "Usage: $0 {compile|smoke|performance|verifyD|fields|all}"; exit 2 ;;
esac
