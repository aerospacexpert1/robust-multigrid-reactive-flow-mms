#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>

#define OMP_MIN_WORK 6000
#define MAX_SWEEP 16

#ifdef _OPENMP
#include <omp.h>
#endif

/*
   Benchmark A mesh-and-stiffness sweep final CSV version
   ------------------------------------------------------
   Frozen solver set:
     1) gsRB       : red-black Gauss-Seidel baseline
     2) mg33       : classical geometric MG, pre=3 post=3
     3) rmt3p6     : RMT-style triple-coarsening, post=6
     4) rmt3c4p6   : RMT-style + combined coarse CG(4), post=6

   Runs for each configuration:
     - serial (threads=1)
     - 4-core OpenMP (threads=4)

   Sweep dimensions:
     - mesh sweep: n list (default 53,107,161)
     - stiffness sweep:
         poisson -> q list      (default 10,100,500)
         jump    -> contrast list (default 1e3,1e5,1e6)
         aniso   -> ky list     (default 3e-2,3e-3,3e-4)

   Exact manufactured discrete solution:
      u_exact(x,y) = exp(sigma*(x+y))
   RHS built algebraically from the discrete operator.

   CSV outputs:
     csv_benchmarkA_pruned_final/
       - all_runs_summary.csv
       - one summary CSV per (case, n, stiffness)
       - one exact CSV per (case, n, stiffness)
       - one field CSV per (case, n, stiffness, solver, threads)
   CSV writing is done AFTER timing and is excluded from solve time.

   Compile:
     gcc -O2 -std=c11 -fopenmp benchmarkA_2d_sweep_parallel_csv.c -lm -o benchmarkA_2d_sweep_parallel_csv

   Run defaults:
     ./benchmarkA_2d_sweep_parallel_csv

   Run one case only:
     ./benchmarkA_2d_sweep_parallel_csv -case aniso

   Custom mesh list:
     ./benchmarkA_2d_sweep_parallel_csv -nList 53,107,161,215

   Disable sweeps and run single configuration:
     ./benchmarkA_2d_sweep_parallel_csv -case jump -meshSweep 0 -stiffSweep 0 -n 107 -jumpContrast 1e6
*/


/* TRUBA/Ubuntu rerun package update (2026-09):
   -writeFields 0 suppresses large exact/field CSV files while retaining summary CSVs.
   This changes output control only; numerical operators and solver algorithms are unchanged.
*/
#define ID(i,j,nx) ((size_t)(i) + (size_t)(nx) * (size_t)(j))

typedef enum {
    CASE_POISSON = 0,
    CASE_JUMP    = 1,
    CASE_ANISO   = 2,
    CASE_ALL     = 3
} CaseType;

typedef struct {
    int n;
    double h;
    double *aP, *aE, *aW, *aN, *aS;
    double *kxCell, *kyCell, *qCell;
} Op2D;

typedef struct {
    int n;
    double h;
    double tol;
    int maxIter;
    int verbose;
    int writeCSV;
    int writeFields; /* write exact/field CSVs; summaries still controlled by writeCSV */
    int runAllCases;
    int coarseExactN;
    double omegaEuler;
    double sigma;
    double poisson_q;
    double jump_contrast;
    double jump_q;
    double aniso_ky;
    double aniso_q;
    CaseType problem;
    int meshSweep;
    int stiffSweep;
    int nList[MAX_SWEEP];
    int nCount;
    double poissonQList[MAX_SWEEP];
    int poissonQCount;
    double jumpContrastList[MAX_SWEEP];
    int jumpContrastCount;
    double anisoKyList[MAX_SWEEP];
    int anisoKyCount;
    int includePoisson161;
    int includeAniso161;
    int appendixStress;
    double maxSolveSeconds;
} Params;

typedef enum {
    SOLVER_GS = 0,
    SOLVER_MG33,
    SOLVER_RMT3P6,
    SOLVER_RMT3C4P6
} SolverType;

typedef struct {
    const char *name;
    int threads;
    int converged;
    int iterations;
    double residual_rel;
    double error_inf;
    double error_l2;
    double solve_seconds;
    double speedup_vs_serial;
    int timed_out;
    double *x;
} Summary;

static double now_seconds(void) {
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (double)ts.tv_sec + 1.0e-9 * (double)ts.tv_nsec;
}

static void *xcalloc(size_t n, size_t sz, const char *what) {
    void *p = calloc(n, sz);
    if (!p) {
        fprintf(stderr, "FATAL: allocation failed for %s\n", what);
        exit(1);
    }
    return p;
}

static int ensure_dir(const char *path) {
    if (mkdir(path, 0777) == 0) return 0;
    if (errno == EEXIST) return 0;
    return -1;
}

static const char *case_name(CaseType c) {
    switch (c) {
        case CASE_POISSON: return "poisson";
        case CASE_JUMP:    return "jump";
        case CASE_ANISO:   return "aniso";
        case CASE_ALL:     return "all";
        default: return "unknown";
    }
}

static const char *stiff_name(CaseType c) {
    switch (c) {
        case CASE_POISSON: return "q";
        case CASE_JUMP:    return "contrast";
        case CASE_ANISO:   return "ky";
        default: return "stiff";
    }
}

static const char *solver_name(SolverType s) {
    switch (s) {
        case SOLVER_GS:       return "gsRB";
        case SOLVER_MG33:     return "mg33";
        case SOLVER_RMT3P6:   return "rmt3p6";
        case SOLVER_RMT3C4P6: return "rmt3c4p6";
        default: return "unknown";
    }
}

static int parse_int_list(const char *txt, int *out, int maxn) {
    char buf[512];
    strncpy(buf, txt, sizeof(buf)-1);
    buf[sizeof(buf)-1] = '\0';
    int cnt = 0;
    char *tok = strtok(buf, ",");
    while (tok && cnt < maxn) {
        out[cnt++] = atoi(tok);
        tok = strtok(NULL, ",");
    }
    return cnt;
}

static int parse_double_list(const char *txt, double *out, int maxn) {
    char buf[512];
    strncpy(buf, txt, sizeof(buf)-1);
    buf[sizeof(buf)-1] = '\0';
    int cnt = 0;
    char *tok = strtok(buf, ",");
    while (tok && cnt < maxn) {
        out[cnt++] = atof(tok);
        tok = strtok(NULL, ",");
    }
    return cnt;
}

static double u_exact_sigma(double x, double y, double sigma) { return exp(sigma * (x + y)); }

static double kx_case(const Params *p, CaseType c, double x, double y) {
    (void)y;
    switch (c) {
        case CASE_POISSON: return 1.0;
        case CASE_JUMP:    return (x < 0.5 ? 1.0 : p->jump_contrast);
        case CASE_ANISO:   return 1.0;
        default: return 1.0;
    }
}

static double ky_case(const Params *p, CaseType c, double x, double y) {
    (void)x; (void)y;
    switch (c) {
        case CASE_POISSON: return 1.0;
        case CASE_JUMP:    return (x < 0.5 ? 1.0 : p->jump_contrast);
        case CASE_ANISO:   return p->aniso_ky;
        default: return 1.0;
    }
}

static double q_case(const Params *p, CaseType c, double x, double y) {
    (void)x; (void)y;
    switch (c) {
        case CASE_POISSON: return p->poisson_q;
        case CASE_JUMP:    return p->jump_q;
        case CASE_ANISO:   return p->aniso_q;
        default: return 0.0;
    }
}

static void op2d_alloc(Op2D *A, int n) {
    const size_t N = (size_t)n * (size_t)n;
    A->n = n;
    A->h = 1.0 / (double)(n + 1);
    A->aP = (double*)xcalloc(N, sizeof(double), "aP");
    A->aE = (double*)xcalloc(N, sizeof(double), "aE");
    A->aW = (double*)xcalloc(N, sizeof(double), "aW");
    A->aN = (double*)xcalloc(N, sizeof(double), "aN");
    A->aS = (double*)xcalloc(N, sizeof(double), "aS");
    A->kxCell = (double*)xcalloc(N, sizeof(double), "kxCell");
    A->kyCell = (double*)xcalloc(N, sizeof(double), "kyCell");
    A->qCell  = (double*)xcalloc(N, sizeof(double), "qCell");
}

static void op2d_free(Op2D *A) {
    free(A->aP); free(A->aE); free(A->aW); free(A->aN); free(A->aS);
    free(A->kxCell); free(A->kyCell); free(A->qCell);
    memset(A, 0, sizeof(*A));
}

static void build_operator(Op2D *A, const Params *p, int n, CaseType c) {
    op2d_alloc(A, n);
    const double h = A->h;
    const double h2 = h * h;
    for (int j = 0; j < n; ++j) {
        for (int i = 0; i < n; ++i) {
            const double x = (double)(i + 1) * h;
            const double y = (double)(j + 1) * h;
            const double ke = kx_case(p, c, x + 0.5*h, y) / h2;
            const double kw = kx_case(p, c, x - 0.5*h, y) / h2;
            const double kn = ky_case(p, c, x, y + 0.5*h) / h2;
            const double ks = ky_case(p, c, x, y - 0.5*h) / h2;
            const double qv = q_case(p, c, x, y);
            const size_t idx = ID(i,j,n);
            A->aE[idx] = ke; A->aW[idx] = kw; A->aN[idx] = kn; A->aS[idx] = ks;
            A->aP[idx] = ke + kw + kn + ks + qv;
            A->kxCell[idx] = kx_case(p, c, x, y);
            A->kyCell[idx] = ky_case(p, c, x, y);
            A->qCell[idx]  = qv;
        }
    }
}

static void build_u_exact(const Op2D *A, double sigma, double *u) {
    const int n = A->n;
    const double h = A->h;
    #pragma omp parallel for collapse(2) schedule(static) if(((size_t)n*(size_t)n) >= OMP_MIN_WORK)
    for (int j = 0; j < n; ++j)
        for (int i = 0; i < n; ++i)
            u[ID(i,j,n)] = u_exact_sigma((double)(i + 1) * h, (double)(j + 1) * h, sigma);
}

static void apply_A(const Op2D *A, const double *x, double *y) {
    const int n = A->n;
    #pragma omp parallel for collapse(2) schedule(static) if(((size_t)n*(size_t)n) >= OMP_MIN_WORK)
    for (int j = 0; j < n; ++j) {
        for (int i = 0; i < n; ++i) {
            const size_t p = ID(i,j,n);
            double v = A->aP[p] * x[p];
            if (i + 1 < n) v -= A->aE[p] * x[ID(i+1,j,n)];
            if (i > 0)     v -= A->aW[p] * x[ID(i-1,j,n)];
            if (j + 1 < n) v -= A->aN[p] * x[ID(i,j+1,n)];
            if (j > 0)     v -= A->aS[p] * x[ID(i,j-1,n)];
            y[p] = v;
        }
    }
}

static void build_rhs(const Op2D *A, const double *uEx, double *b) { apply_A(A, uEx, b); }
static void compute_residual(const Op2D *A, const double *x, const double *b, double *r) {
    apply_A(A, x, r);
    const size_t N = (size_t)A->n * (size_t)A->n;
    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t p = 0; p < N; ++p) r[p] = b[p] - r[p];
}

static double l2_norm(const double *x, size_t N) {
    double s = 0.0;
    #pragma omp parallel for reduction(+:s) schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t i = 0; i < N; ++i) s += x[i] * x[i];
    return sqrt(s / (double)(N > 0 ? N : 1));
}
static double linf_error(const double *x, const double *y, size_t N) {
    double m = 0.0;
    #pragma omp parallel for reduction(max:m) schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t i = 0; i < N; ++i) { double e = fabs(x[i] - y[i]); if (e > m) m = e; }
    return m;
}
static double l2_error(const double *x, const double *y, size_t N) {
    double s = 0.0;
    #pragma omp parallel for reduction(+:s) schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t i = 0; i < N; ++i) { double e = x[i] - y[i]; s += e * e; }
    return sqrt(s / (double)(N > 0 ? N : 1));
}

static void rbgs_sweep(const Op2D *A, double *x, const double *b) {
    const int n = A->n;
    for (int color = 0; color < 2; ++color) {
        #pragma omp parallel for collapse(2) schedule(static) if(((size_t)n*(size_t)n) >= OMP_MIN_WORK)
        for (int j = 0; j < n; ++j) {
            for (int i = 0; i < n; ++i) {
                if (((i + j) & 1) != color) continue;
                const size_t p = ID(i,j,n);
                double rhs = b[p];
                if (i + 1 < n) rhs += A->aE[p] * x[ID(i+1,j,n)];
                if (i > 0)     rhs += A->aW[p] * x[ID(i-1,j,n)];
                if (j + 1 < n) rhs += A->aN[p] * x[ID(i,j+1,n)];
                if (j > 0)     rhs += A->aS[p] * x[ID(i,j-1,n)];
                x[p] = rhs / A->aP[p];
            }
        }
    }
}

static void jacobi_step(const Op2D *A, double *x, const double *b, double omega, double *rbuf) {
    compute_residual(A, x, b, rbuf);
    const size_t N = (size_t)A->n * (size_t)A->n;
    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t p = 0; p < N; ++p) x[p] += omega * rbuf[p] / A->aP[p];
}

static double dot_vec(const double *a, const double *b, size_t N) {
    double s = 0.0;
    #pragma omp parallel for reduction(+:s) schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t i = 0; i < N; ++i) s += a[i] * b[i];
    return s;
}

static void cg_fixed_iters(const Op2D *A, double *x, const double *b, int iters) {
    const size_t N = (size_t)A->n * (size_t)A->n;
    if (iters <= 0 || N == 0) return;
    double *r  = (double*)xcalloc(N, sizeof(double), "cg r");
    double *z  = (double*)xcalloc(N, sizeof(double), "cg z");
    double *p  = (double*)xcalloc(N, sizeof(double), "cg p");
    double *Ap = (double*)xcalloc(N, sizeof(double), "cg Ap");
    compute_residual(A, x, b, r);
    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t i = 0; i < N; ++i) { z[i] = r[i] / A->aP[i]; p[i] = z[i]; }
    double rz_old = dot_vec(r, z, N);
    if (!(rz_old > 0.0)) { free(r); free(z); free(p); free(Ap); return; }
    for (int k = 0; k < iters; ++k) {
        apply_A(A, p, Ap);
        double pAp = dot_vec(p, Ap, N);
        if (!(fabs(pAp) > 1.0e-30)) break;
        double alpha = rz_old / pAp;
        #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
        for (size_t i = 0; i < N; ++i) {
            x[i] += alpha * p[i];
            r[i] -= alpha * Ap[i];
            z[i] = r[i] / A->aP[i];
        }
        double rz_new = dot_vec(r, z, N);
        if (!(rz_new > 0.0)) break;
        double beta = rz_new / rz_old;
        #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
        for (size_t i = 0; i < N; ++i) p[i] = z[i] + beta * p[i];
        rz_old = rz_new;
    }
    free(r); free(z); free(p); free(Ap);
}

static void exact_solve_dense(const Op2D *A, const double *b, double *x) {
    const int n = A->n; const int N = n*n;
    double *M = (double*)xcalloc((size_t)N * (size_t)N, sizeof(double), "dense matrix");
    double *rhs = (double*)xcalloc((size_t)N, sizeof(double), "dense rhs");
    for (int j=0;j<n;++j) for (int i=0;i<n;++i) {
        int row = i + n*j; size_t p = ID(i,j,n);
        M[(size_t)row*(size_t)N + (size_t)row] = A->aP[p];
        if (i + 1 < n) M[(size_t)row*(size_t)N + (size_t)(row+1)] = -A->aE[p];
        if (i > 0)     M[(size_t)row*(size_t)N + (size_t)(row-1)] = -A->aW[p];
        if (j + 1 < n) M[(size_t)row*(size_t)N + (size_t)(row+n)] = -A->aN[p];
        if (j > 0)     M[(size_t)row*(size_t)N + (size_t)(row-n)] = -A->aS[p];
        rhs[row] = b[p];
    }
    for (int k=0;k<N;++k) {
        int piv = k; double amax = fabs(M[(size_t)k*(size_t)N + (size_t)k]);
        for (int i=k+1;i<N;++i) { double av=fabs(M[(size_t)i*(size_t)N + (size_t)k]); if (av>amax){amax=av;piv=i;} }
        if (amax < 1e-30) { fprintf(stderr,"FATAL: singular coarse matrix\n"); exit(1); }
        if (piv != k) {
            for (int jcol=k;jcol<N;++jcol) {
                double tmp=M[(size_t)k*(size_t)N + (size_t)jcol];
                M[(size_t)k*(size_t)N + (size_t)jcol]=M[(size_t)piv*(size_t)N + (size_t)jcol];
                M[(size_t)piv*(size_t)N + (size_t)jcol]=tmp;
            }
            double tr=rhs[k]; rhs[k]=rhs[piv]; rhs[piv]=tr;
        }
        double diag=M[(size_t)k*(size_t)N + (size_t)k];
        for (int i=k+1;i<N;++i) {
            double f=M[(size_t)i*(size_t)N + (size_t)k]/diag; M[(size_t)i*(size_t)N + (size_t)k]=0.0;
            if (f==0.0) continue;
            for (int jcol=k+1;jcol<N;++jcol) M[(size_t)i*(size_t)N + (size_t)jcol] -= f*M[(size_t)k*(size_t)N + (size_t)jcol];
            rhs[i] -= f*rhs[k];
        }
    }
    for (int i=N-1;i>=0;--i) {
        double s=rhs[i];
        for (int jcol=i+1;jcol<N;++jcol) s -= M[(size_t)i*(size_t)N + (size_t)jcol]*x[jcol];
        x[i] = s / M[(size_t)i*(size_t)N + (size_t)i];
    }
    free(M); free(rhs);
}

static int can_coarsen_2h(int n) { return ((n + 1) % 2) == 0 && (((n + 1) / 2) - 1) >= 1; }
static int coarse_n_2h(int n) { return ((n + 1) / 2) - 1; }
static int can_coarsen_3h(int n) { return ((n + 1) % 3) == 0 && (((n + 1) / 3) - 1) >= 1; }
static int coarse_n_3h(int n) { return ((n + 1) / 3) - 1; }

static void restrict_fw_2h(const double *rf, int nf, double *rc, int nc) {
    #pragma omp parallel for collapse(2) schedule(static) if(((size_t)nc*(size_t)nc) >= OMP_MIN_WORK)
    for (int J=0;J<nc;++J) for (int I=0;I<nc;++I) {
        int jf = 2*(J+1)-1, ifi = 2*(I+1)-1; double s=0.0;
        s += 4.0*rf[ID(ifi,jf,nf)];
        if (ifi>0)      s += 2.0*rf[ID(ifi-1,jf,nf)];
        if (ifi+1<nf)   s += 2.0*rf[ID(ifi+1,jf,nf)];
        if (jf>0)       s += 2.0*rf[ID(ifi,jf-1,nf)];
        if (jf+1<nf)    s += 2.0*rf[ID(ifi,jf+1,nf)];
        if (ifi>0 && jf>0)           s += rf[ID(ifi-1,jf-1,nf)];
        if (ifi>0 && jf+1<nf)        s += rf[ID(ifi-1,jf+1,nf)];
        if (ifi+1<nf && jf>0)        s += rf[ID(ifi+1,jf-1,nf)];
        if (ifi+1<nf && jf+1<nf)     s += rf[ID(ifi+1,jf+1,nf)];
        rc[ID(I,J,nc)] = s/16.0;
    }
}

static void prolong_bilinear_generic(const double *ec, int nc, double *ef, int nf) {
    const int Nc = nc + 2;
    double *Uc = (double*)xcalloc((size_t)Nc * (size_t)Nc, sizeof(double), "Uc");
    for (int J=1;J<=nc;++J) for (int I=1;I<=nc;++I) Uc[ID(I,J,Nc)] = ec[ID(I-1,J-1,nc)];
    #pragma omp parallel for collapse(2) schedule(static) if(((size_t)nf*(size_t)nf) >= OMP_MIN_WORK)
    for (int j=0;j<nf;++j) for (int i=0;i<nf;++i) {
        double y = (double)(j+1)/(double)(nf+1), sc = y*(double)(nc+1); int J0=(int)floor(sc); if(J0<0)J0=0; if(J0>nc)J0=nc; double ty=sc-(double)J0; int J1=J0+1;
        double x = (double)(i+1)/(double)(nf+1), tc = x*(double)(nc+1); int I0=(int)floor(tc); if(I0<0)I0=0; if(I0>nc)I0=nc; double tx=tc-(double)I0; int I1=I0+1;
        double c00=Uc[ID(I0,J0,Nc)], c10=Uc[ID(I1,J0,Nc)], c01=Uc[ID(I0,J1,Nc)], c11=Uc[ID(I1,J1,Nc)];
        ef[ID(i,j,nf)] = (1.0-tx)*(1.0-ty)*c00 + tx*(1.0-ty)*c10 + (1.0-tx)*ty*c01 + tx*ty*c11;
    }
    free(Uc);
}

static void restrict_avg_3h(const double *rf, int nf, double *rc, int nc) {
    #pragma omp parallel for collapse(2) schedule(static) if(((size_t)nc*(size_t)nc) >= OMP_MIN_WORK)
    for (int J=0;J<nc;++J) for (int I=0;I<nc;++I) {
        int jf = 3*(J+1)-1, ifi = 3*(I+1)-1; double s=0.0; int cnt=0;
        for (int dj=-1;dj<=1;++dj) {
            int jj=jf+dj; if (jj<0 || jj>=nf) continue;
            for (int di=-1;di<=1;++di) { int ii=ifi+di; if(ii<0||ii>=nf) continue; s += rf[ID(ii,jj,nf)]; ++cnt; }
        }
        rc[ID(I,J,nc)] = (cnt>0? s/(double)cnt : 0.0);
    }
}

static void mg33_vcycle(const Params *p, const Op2D *A, double *x, const double *b, CaseType c) {
    int n=A->n; size_t N=(size_t)n*(size_t)n;
    if (n <= p->coarseExactN || !can_coarsen_2h(n)) { exact_solve_dense(A,b,x); return; }
    for (int s=0;s<3;++s) rbgs_sweep(A,x,b);
    double *r=(double*)xcalloc(N,sizeof(double),"mg r"); compute_residual(A,x,b,r);
    int nc=coarse_n_2h(n); Op2D Ac; build_operator(&Ac,p,nc,c); size_t Nc=(size_t)nc*(size_t)nc;
    double *bc=(double*)xcalloc(Nc,sizeof(double),"mg bc"), *ec=(double*)xcalloc(Nc,sizeof(double),"mg ec"), *ef=(double*)xcalloc(N,sizeof(double),"mg ef");
    restrict_fw_2h(r,n,bc,nc); mg33_vcycle(p,&Ac,ec,bc,c); prolong_bilinear_generic(ec,nc,ef,n);
    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t q=0;q<N;++q) x[q]+=ef[q];
    for (int s=0;s<3;++s) rbgs_sweep(A,x,b);
    free(r); free(bc); free(ec); free(ef); op2d_free(&Ac);
}

static void rmt3p6_cycle(const Params *p, const Op2D *A, double *x, const double *b, CaseType c) {
    int n=A->n; size_t N=(size_t)n*(size_t)n;
    if (n <= p->coarseExactN || !can_coarsen_3h(n)) { exact_solve_dense(A,b,x); return; }
    double *r=(double*)xcalloc(N,sizeof(double),"rmt r"); compute_residual(A,x,b,r);
    int nc=coarse_n_3h(n); Op2D Ac; build_operator(&Ac,p,nc,c); size_t Nc=(size_t)nc*(size_t)nc;
    double *bc=(double*)xcalloc(Nc,sizeof(double),"rmt bc"), *ec=(double*)xcalloc(Nc,sizeof(double),"rmt ec"), *ef=(double*)xcalloc(N,sizeof(double),"rmt ef");
    restrict_avg_3h(r,n,bc,nc); rmt3p6_cycle(p,&Ac,ec,bc,c); prolong_bilinear_generic(ec,nc,ef,n);
    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t q=0;q<N;++q) x[q]+=ef[q];
    for (int s=0;s<6;++s) rbgs_sweep(A,x,b);
    free(r); free(bc); free(ec); free(ef); op2d_free(&Ac);
}

static void rmt3c4p6_cycle_level(const Params *p, const Op2D *A, double *x, const double *b, CaseType c, int level) {
    int n=A->n; size_t N=(size_t)n*(size_t)n;
    if (n <= p->coarseExactN || !can_coarsen_3h(n)) { exact_solve_dense(A,b,x); return; }
    if (level > 0) cg_fixed_iters(A,x,b,4);
    double *r=(double*)xcalloc(N,sizeof(double),"rmtc r"); compute_residual(A,x,b,r);
    int nc=coarse_n_3h(n); Op2D Ac; build_operator(&Ac,p,nc,c); size_t Nc=(size_t)nc*(size_t)nc;
    double *bc=(double*)xcalloc(Nc,sizeof(double),"rmtc bc"), *ec=(double*)xcalloc(Nc,sizeof(double),"rmtc ec"), *ef=(double*)xcalloc(N,sizeof(double),"rmtc ef");
    restrict_avg_3h(r,n,bc,nc); rmt3c4p6_cycle_level(p,&Ac,ec,bc,c,level+1); if(level>0) cg_fixed_iters(&Ac,ec,bc,4); prolong_bilinear_generic(ec,nc,ef,n);
    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t q=0;q<N;++q) x[q]+=ef[q];
    if (level==0) for(int s=0;s<6;++s) rbgs_sweep(A,x,b); else cg_fixed_iters(A,x,b,4);
    free(r); free(bc); free(ec); free(ef); op2d_free(&Ac);
}
static void rmt3c4p6_cycle(const Params *p, const Op2D *A, double *x, const double *b, CaseType c) { rmt3c4p6_cycle_level(p,A,x,b,c,0); }

static void init_params(Params *p) {
    memset(p, 0, sizeof(*p));
    p->n = 107; p->tol = 1e-8; p->maxIter = 800; p->verbose = 0; p->writeCSV = 1; p->writeFields = 1; p->runAllCases = 1; p->coarseExactN = 5; p->omegaEuler = 0.8;
    p->sigma = 6.0; p->poisson_q = 100.0; p->jump_contrast = 1e6; p->jump_q = 10.0; p->aniso_ky = 3e-3; p->aniso_q = 0.5; p->problem = CASE_ALL;
    p->meshSweep = 1; p->stiffSweep = 1;
    p->nList[0]=53; p->nList[1]=107; p->nList[2]=161; p->nCount=3;
    p->poissonQList[0]=10.0; p->poissonQList[1]=100.0; p->poissonQList[2]=500.0; p->poissonQCount=3;
    p->jumpContrastList[0]=1e3; p->jumpContrastList[1]=1e5; p->jumpContrastList[2]=1e6; p->jumpContrastCount=3;
    p->anisoKyList[0]=3e-2; p->anisoKyList[1]=3e-3; p->anisoKyList[2]=3e-4; p->anisoKyCount=3;
    p->includePoisson161 = 0;
    p->includeAniso161 = 0;
    p->appendixStress = 0;
    p->maxSolveSeconds = 20.0;
}

static void parse_args(int argc, char **argv, Params *p) {
    for (int i=1;i<argc;++i) {
        if (!strcmp(argv[i], "-n") && i+1<argc) p->n = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-tol") && i+1<argc) p->tol = atof(argv[++i]);
        else if (!strcmp(argv[i], "-maxIter") && i+1<argc) p->maxIter = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-verbose") && i+1<argc) p->verbose = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-writeCSV") && i+1<argc) p->writeCSV = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-writeFields") && i+1<argc) p->writeFields = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-coarseExactN") && i+1<argc) p->coarseExactN = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-sigma") && i+1<argc) p->sigma = atof(argv[++i]);
        else if (!strcmp(argv[i], "-poissonQ") && i+1<argc) p->poisson_q = atof(argv[++i]);
        else if (!strcmp(argv[i], "-jumpContrast") && i+1<argc) p->jump_contrast = atof(argv[++i]);
        else if (!strcmp(argv[i], "-jumpQ") && i+1<argc) p->jump_q = atof(argv[++i]);
        else if (!strcmp(argv[i], "-anisoKy") && i+1<argc) p->aniso_ky = atof(argv[++i]);
        else if (!strcmp(argv[i], "-anisoQ") && i+1<argc) p->aniso_q = atof(argv[++i]);
        else if (!strcmp(argv[i], "-meshSweep") && i+1<argc) p->meshSweep = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-stiffSweep") && i+1<argc) p->stiffSweep = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-nList") && i+1<argc) p->nCount = parse_int_list(argv[++i], p->nList, MAX_SWEEP);
        else if (!strcmp(argv[i], "-poissonQList") && i+1<argc) p->poissonQCount = parse_double_list(argv[++i], p->poissonQList, MAX_SWEEP);
        else if (!strcmp(argv[i], "-jumpContrastList") && i+1<argc) p->jumpContrastCount = parse_double_list(argv[++i], p->jumpContrastList, MAX_SWEEP);
        else if (!strcmp(argv[i], "-anisoKyList") && i+1<argc) p->anisoKyCount = parse_double_list(argv[++i], p->anisoKyList, MAX_SWEEP);
        else if (!strcmp(argv[i], "-includePoisson161") && i+1<argc) p->includePoisson161 = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-includeAniso161") && i+1<argc) p->includeAniso161 = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-appendixStress") && i+1<argc) p->appendixStress = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-maxSolveSeconds") && i+1<argc) p->maxSolveSeconds = atof(argv[++i]);
        else if (!strcmp(argv[i], "-case") && i+1<argc) {
            ++i; p->runAllCases = 0;
            if (!strcmp(argv[i], "poisson")) p->problem = CASE_POISSON;
            else if (!strcmp(argv[i], "jump")) p->problem = CASE_JUMP;
            else if (!strcmp(argv[i], "aniso")) p->problem = CASE_ANISO;
            else if (!strcmp(argv[i], "all")) { p->problem = CASE_ALL; p->runAllCases = 1; }
            else { fprintf(stderr, "unknown case '%s'\n", argv[i]); exit(1); }
        }
    }
}

static void set_threads(int nthreads) {
#ifdef _OPENMP
    omp_set_dynamic(0); omp_set_num_threads(nthreads);
#else
    (void)nthreads;
#endif
}

static Summary run_solver(const Params *p, const Op2D *A, const double *b, const double *uEx, double r0, SolverType solver, int threads) {
    Summary s; memset(&s,0,sizeof(s)); s.name=solver_name(solver); s.threads=threads;
    size_t N=(size_t)A->n*(size_t)A->n;
    double *x=(double*)xcalloc(N,sizeof(double),s.name); double *r=(double*)xcalloc(N,sizeof(double),"residual buffer");
    if (solver == SOLVER_GS) memset(x, 0, N*sizeof(double));
    set_threads(threads);
    double t0=now_seconds();
    for (int it=1; it<=p->maxIter; ++it) {
        if (solver == SOLVER_GS) rbgs_sweep(A,x,b);
        else if (solver == SOLVER_MG33) mg33_vcycle(p,A,x,b,p->problem);
        else if (solver == SOLVER_RMT3P6) rmt3p6_cycle(p,A,x,b,p->problem);
        else if (solver == SOLVER_RMT3C4P6) rmt3c4p6_cycle(p,A,x,b,p->problem);
        compute_residual(A,x,b,r); s.iterations=it; s.residual_rel=l2_norm(r,N)/r0;
        if (p->verbose && (it <= 10 || it % 50 == 0)) printf("  %-9s thr=%d iter=%6d residual_rel=% .5e\n", s.name, threads, it, s.residual_rel);
        if (s.residual_rel < p->tol) { s.converged=1; break; }
        if (p->maxSolveSeconds > 0.0 && (now_seconds() - t0) > p->maxSolveSeconds) { s.timed_out = 1; break; }
    }
    s.solve_seconds=now_seconds()-t0; s.error_inf=linf_error(x,uEx,N); s.error_l2=l2_error(x,uEx,N); s.x=x; free(r); return s;
}

static void write_csv_solution(const char *path, const Op2D *A, const double *u, const double *uEx, const double *b, const char *caseLabel, const char *solverLabel, int threads, const char *stiffLabel, double stiffVal) {
    FILE *fp=fopen(path,"w"); if(!fp){ fprintf(stderr,"warning: could not open %s\n",path); return; }
    int n=A->n; double h=A->h;
    fprintf(fp,"# case,%s\n# solver,%s\n# threads,%d\n# n,%d\n# h,%.16e\n# %s,%.16e\n", caseLabel, solverLabel, threads, n, h, stiffLabel, stiffVal);
    fprintf(fp,"i,j,x,y,u,u_exact,error,rhs,kx_cell,ky_cell,q_cell\n");
    for(int j=0;j<n;++j) for(int i=0;i<n;++i) {
        size_t idx=ID(i,j,n); double x=(double)(i+1)*h, y=(double)(j+1)*h; double uu=u?u[idx]:uEx[idx], ue=uEx[idx];
        fprintf(fp,"%d,%d,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e\n", i,j,x,y,uu,ue,uu-ue,b[idx],A->kxCell[idx],A->kyCell[idx],A->qCell[idx]);
    }
    fclose(fp);
}

static void write_summary_csv(const char *path, const Summary *S, int m, const Params *p, const Op2D *A, const char *stiffLabel, double stiffVal) {
    FILE *fp=fopen(path,"w"); if(!fp){ fprintf(stderr,"warning: could not open %s\n",path); return; }
    fprintf(fp,"problem,stiff_name,stiff_value,n,h,tol,maxIter,sigma,solver,threads,converged,timed_out,iterations,residual_rel,error_inf,error_l2,solve_s,speedup\n");
    for(int i=0;i<m;++i) fprintf(fp,"%s,%s,%.16e,%d,%.16e,%.16e,%d,%.16e,%s,%d,%d,%d,%d,%.16e,%.16e,%.16e,%.16e,%.16e\n",
            case_name(p->problem), stiffLabel, stiffVal, p->n, A->h, p->tol, p->maxIter, p->sigma,
            S[i].name, S[i].threads, S[i].converged, S[i].timed_out, S[i].iterations, S[i].residual_rel, S[i].error_inf, S[i].error_l2, S[i].solve_seconds, S[i].speedup_vs_serial);
    fclose(fp);
}

static void append_global_summary(FILE *fp, const Summary *S, int m, const Params *p, const Op2D *A, const char *stiffLabel, double stiffVal) {
    for(int i=0;i<m;++i) fprintf(fp,"%s,%s,%.16e,%d,%.16e,%.16e,%d,%.16e,%s,%d,%d,%d,%d,%.16e,%.16e,%.16e,%.16e,%.16e\n",
            case_name(p->problem), stiffLabel, stiffVal, p->n, A->h, p->tol, p->maxIter, p->sigma,
            S[i].name, S[i].threads, S[i].converged, S[i].timed_out, S[i].iterations, S[i].residual_rel, S[i].error_inf, S[i].error_l2, S[i].solve_seconds, S[i].speedup_vs_serial);
}

static void free_summaries(Summary *S, int m) { for(int i=0;i<m;++i){ free(S[i].x); S[i].x=NULL; } }

static void print_summary(const Summary *S, int m) {
    printf("solver      threads status    iterations residual_rel      error_inf         error_l2          solve_s   speedup\n");
    printf("----------  ------- --------- ---------- ------------      ---------         --------          -------   -------\n");
    for(int i=0;i<m;++i) {
        const char *status = S[i].converged ? "yes" : (S[i].timed_out ? "timeout" : "no");
        printf("%-10s  %7d %-9s %10d % .5e   % .5e   % .5e   %8.3f   %6.2f\n",
            S[i].name,S[i].threads,status,S[i].iterations,S[i].residual_rel,S[i].error_inf,S[i].error_l2,S[i].solve_seconds,S[i].speedup_vs_serial);
    }
}

static void print_winners(const Summary *S, int m) {
    int bestSerial=-1, bestParallel=-1, bestErr=-1;
    for (int i=0;i<m;++i) {
        if (!S[i].converged) continue;
        if (S[i].threads==1 && (bestSerial<0 || S[i].solve_seconds < S[bestSerial].solve_seconds)) bestSerial=i;
        if (S[i].threads==4 && (bestParallel<0 || S[i].solve_seconds < S[bestParallel].solve_seconds)) bestParallel=i;
        if (bestErr<0 || S[i].error_inf < S[bestErr].error_inf) bestErr=i;
    }
    printf("Quick takeaways:\n");
    if (bestSerial>=0)  printf("  fastest serial   : %s in %.3f s (%d iterations)\n", S[bestSerial].name, S[bestSerial].solve_seconds, S[bestSerial].iterations);
    if (bestParallel>=0)printf("  fastest 4-thread : %s in %.3f s (speedup %.2f)\n", S[bestParallel].name, S[bestParallel].solve_seconds, S[bestParallel].speedup_vs_serial);
    if (bestErr>=0)     printf("  lowest error_inf : %s (thr=%d) with %.5e\n", S[bestErr].name, S[bestErr].threads, S[bestErr].error_inf);
}

static void describe_stiffness(const Params *p, char *buf, size_t nbuf) {
    if (p->problem == CASE_POISSON) snprintf(buf, nbuf, "kx=1 ky=1 q=%g", p->poisson_q);
    else if (p->problem == CASE_JUMP) snprintf(buf, nbuf, "jump contrast=%g q=%g", p->jump_contrast, p->jump_q);
    else if (p->problem == CASE_ANISO) snprintf(buf, nbuf, "kx=1 ky=%g q=%g", p->aniso_ky, p->aniso_q);
    else snprintf(buf, nbuf, "n/a");
}

static double current_stiff_value(const Params *p) {
    if (p->problem == CASE_POISSON) return p->poisson_q;
    if (p->problem == CASE_JUMP) return p->jump_contrast;
    if (p->problem == CASE_ANISO) return p->aniso_ky;
    return 0.0;
}

static void set_stiff_value(Params *p, double v) {
    if (p->problem == CASE_POISSON) p->poisson_q = v;
    else if (p->problem == CASE_JUMP) p->jump_contrast = v;
    else if (p->problem == CASE_ANISO) p->aniso_ky = v;
}

static const double *stiff_list_for_case(const Params *p, CaseType c, int *count) {
    if (c == CASE_POISSON) { *count = p->poissonQCount; return p->poissonQList; }
    if (c == CASE_JUMP)    { *count = p->jumpContrastCount; return p->jumpContrastList; }
    *count = p->anisoKyCount; return p->anisoKyList;
}

static int pruned_keep_config(const Params *p, CaseType c, int n, double stiffVal) {
    if (!p->meshSweep && !p->stiffSweep) return 1;
    if (c == CASE_POISSON) {
        if (p->meshSweep && n == 161 && !p->includePoisson161) return 0;
        return 1;
    }
    if (c == CASE_JUMP) return 1;
    if (c == CASE_ANISO) {
        if (p->meshSweep && n == 161 && !p->includeAniso161) return 0;
        if (p->stiffSweep && stiffVal < 1.0e-3 && !p->appendixStress) return 0;
        return 1;
    }
    return 1;
}

static int pruned_total_configs(const Params *p, int caseStart, int caseEnd, const CaseType *cases) {
    int total = 0;
    for (int ci=caseStart; ci<caseEnd; ++ci) {
        int stiffCount = 1;
        const double *stiffList = NULL;
        if (p->stiffSweep) stiffList = stiff_list_for_case(p, cases[ci], &stiffCount);
        int meshCount = p->meshSweep ? p->nCount : 1;
        for (int si=0; si<stiffCount; ++si) {
            double sval = p->stiffSweep ? stiffList[si] : 0.0;
            for (int mi=0; mi<meshCount; ++mi) {
                int n = p->meshSweep ? p->nList[mi] : p->n;
                if (pruned_keep_config(p, cases[ci], n, sval)) ++total;
            }
        }
    }
    return total;
}

static void run_case_config(const Params *pIn, FILE *globalCsv) {
    Params p=*pIn; Op2D A; build_operator(&A,&p,p.n,p.problem); size_t N=(size_t)p.n*(size_t)p.n;
    double *uEx=(double*)xcalloc(N,sizeof(double),"uEx"), *b=(double*)xcalloc(N,sizeof(double),"b"), *r0v=(double*)xcalloc(N,sizeof(double),"r0v");
    build_u_exact(&A,p.sigma,uEx); build_rhs(&A,uEx,b); memcpy(r0v,b,N*sizeof(double)); set_threads(1); double r0=l2_norm(r0v,N);
    char stiffBuf[128]; describe_stiffness(&p, stiffBuf, sizeof(stiffBuf));
    printf("\n------------------------------------------------------------\n");
    printf("case=%s | n=%d | h=%e | %s | tol=%g | maxIter=%d\n", case_name(p.problem), p.n, A.h, stiffBuf, p.tol, p.maxIter);
    printf("exact solution: u_ij = exp(sigma*(x_i + y_j)), sigma=%g\n", p.sigma);
    if (!can_coarsen_2h(p.n)) printf("warning: mg33 falls back to exact solve immediately because n is not perfectly 2h-nested\n");
    if (!can_coarsen_3h(p.n)) printf("warning: rmt3 falls back to exact solve immediately because n is not perfectly 3h-nested\n");
    Summary S[8]; SolverType solvers[4]={SOLVER_GS,SOLVER_MG33,SOLVER_RMT3P6,SOLVER_RMT3C4P6}; int idx=0;
    for (int si=0;si<4;++si) { S[idx++]=run_solver(&p,&A,b,uEx,r0,solvers[si],1); S[idx++]=run_solver(&p,&A,b,uEx,r0,solvers[si],4); }
    for (int si=0;si<4;++si) { double t1=S[2*si].solve_seconds, t4=S[2*si+1].solve_seconds; S[2*si].speedup_vs_serial=1.0; S[2*si+1].speedup_vs_serial=(t4>0.0? t1/t4 : 0.0); }
    print_summary(S,8); print_winners(S,8);
    if (p.writeCSV) {
        ensure_dir("csv_benchmarkA_pruned_final");
        char path[512]; double sval=current_stiff_value(&p); const char *sname=stiff_name(p.problem);
        snprintf(path,sizeof(path),"csv_benchmarkA_pruned_final/%s_n%d_%s%.3e_summary.csv",case_name(p.problem),p.n,sname,sval);
        write_summary_csv(path,S,8,&p,&A,sname,sval);
        if (p.writeFields) {
            snprintf(path,sizeof(path),"csv_benchmarkA_pruned_final/%s_n%d_%s%.3e_exact.csv",case_name(p.problem),p.n,sname,sval);
            write_csv_solution(path,&A,NULL,uEx,b,case_name(p.problem),"exact",0,sname,sval);
            for (int i=0;i<8;++i) {
                snprintf(path,sizeof(path),"csv_benchmarkA_pruned_final/%s_n%d_%s%.3e_%s_t%d.csv",case_name(p.problem),p.n,sname,sval,S[i].name,S[i].threads);
                write_csv_solution(path,&A,S[i].x,uEx,b,case_name(p.problem),S[i].name,S[i].threads,sname,sval);
            }
        }
        if (globalCsv) append_global_summary(globalCsv,S,8,&p,&A,sname,sval);
        printf("CSV written for this configuration.\n");
    }
    free_summaries(S,8); free(uEx); free(b); free(r0v); op2d_free(&A);
}

static void run_sweeps(const Params *pBase) {
    ensure_dir("csv_benchmarkA_pruned_final");
    FILE *global = NULL;
    if (pBase->writeCSV) {
        global = fopen("csv_benchmarkA_pruned_final/all_runs_summary.csv", "w");
        if (global) fprintf(global, "problem,stiff_name,stiff_value,n,h,tol,maxIter,sigma,solver,threads,converged,timed_out,iterations,residual_rel,error_inf,error_l2,solve_s,speedup\n");
    }

    CaseType cases[3] = {CASE_POISSON, CASE_JUMP, CASE_ANISO};
    int caseStart = 0, caseEnd = 3;
    if (!pBase->runAllCases && pBase->problem != CASE_ALL) {
        caseStart = 0; caseEnd = 1; cases[0] = pBase->problem;
    }

    int totalConfigs = pruned_total_configs(pBase, caseStart, caseEnd, cases);

    int cfg = 0;
    for (int ci=caseStart; ci<caseEnd; ++ci) {
        CaseType c = cases[ci];
        int stiffCount = 1; const double *stiffList = NULL;
        if (pBase->stiffSweep) stiffList = stiff_list_for_case(pBase, c, &stiffCount);
        double oneStiff = 0.0; if (!pBase->stiffSweep) { Params tmp=*pBase; tmp.problem=c; oneStiff=current_stiff_value(&tmp); }
        int meshCount = pBase->meshSweep ? pBase->nCount : 1;

        printf("\n============================================================\n");
        printf("Starting case family: %s | mesh sweep=%s | stiffness sweep=%s\n", case_name(c), pBase->meshSweep?"on":"off", pBase->stiffSweep?"on":"off");
        printf("============================================================\n");
        for (int si=0; si<stiffCount; ++si) {
            for (int mi=0; mi<meshCount; ++mi) {
                int nThis = pBase->meshSweep ? pBase->nList[mi] : pBase->n;
                double sval = pBase->stiffSweep ? stiffList[si] : oneStiff;
                if (!pruned_keep_config(pBase, c, nThis, sval)) continue;
                Params p = *pBase; p.problem = c; p.runAllCases = 0;
                p.n = nThis;
                set_stiff_value(&p, sval);
                ++cfg;
                printf("\n>>> Configuration %d / %d\n", cfg, totalConfigs);
                run_case_config(&p, global);
            }
        }
    }
    if (global) fclose(global);
    if (pBase->writeCSV) printf("\nGlobal CSV summary written to csv_benchmarkA_pruned_final/all_runs_summary.csv\n");
}

int main(int argc, char **argv) {
    Params p; init_params(&p); parse_args(argc, argv, &p);
    printf("Compile note: use -fopenmp for 4-core parallel runs.\n");
#ifdef _OPENMP
    printf("OpenMP detected. Max available threads reported by runtime: %d\n", omp_get_max_threads());
#else
    printf("OpenMP not enabled at compile time. Parallel cases will behave like serial.\n");
#endif
    printf("Frozen solver set: gsRB, mg33, rmt3p6, rmt3c4p6\n");
    printf("Pruned main benchmark defaults:\n");
    printf("  Poisson main meshes : 53,107%s\n", p.includePoisson161 ? ",161 (enabled)" : " (161 excluded by default)");
    printf("  Jump main meshes    : 53,107,161\n");
    printf("  Aniso main meshes   : 53,107%s\n", p.includeAniso161 ? ",161 (enabled)" : " (161 excluded by default)");
    printf("  Aniso main ky list  : 0.03,0.003%s\n", p.appendixStress ? ",0.0003 appendix stress enabled" : " (0.0003 excluded by default)");
    printf("Mesh sweep: %s\n", p.meshSweep ? "on" : "off");
    if (p.meshSweep) {
        printf("  nList = "); for (int i=0;i<p.nCount;++i) printf("%d%s", p.nList[i], (i+1<p.nCount? ",":"\n"));
    } else printf("  single n = %d\n", p.n);
    printf("Stiffness sweep: %s\n", p.stiffSweep ? "on" : "off");
    if (p.stiffSweep) {
        printf("  poisson q list      = "); for (int i=0;i<p.poissonQCount;++i) printf("%g%s", p.poissonQList[i], (i+1<p.poissonQCount? ",":"\n"));
        printf("  jump contrast list  = "); for (int i=0;i<p.jumpContrastCount;++i) printf("%g%s", p.jumpContrastList[i], (i+1<p.jumpContrastCount? ",":"\n"));
        printf("  aniso ky list       = "); for (int i=0;i<p.anisoKyCount;++i) printf("%g%s", p.anisoKyList[i], (i+1<p.anisoKyCount? ",":"\n"));
        if (!p.appendixStress) printf("  pruning note        : ky < 1e-3 excluded from main benchmark\n");
    }
    printf("CSV writing is NOT included in solve time.\n");
    printf("Per-solver wall-time guard: %.1f s (set 0 to disable)\n", p.maxSolveSeconds);
    printf("CSV folder: csv_benchmarkA_pruned_final/\n");
    run_sweeps(&p);
    return 0;
}
