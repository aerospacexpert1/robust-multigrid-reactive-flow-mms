#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>

#define OMP_MIN_WORK 6000
#define MAX_SWEEP 16

#ifdef _OPENMP
#include <omp.h>
#endif

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/*
   Benchmark C V1: convection-diffusion mesh / Peclet sweep CSV version
   --------------------------------------------------------------------
   Frozen solver set (same family used in Benchmarks A and B):
     1) gsRB       : red-black Gauss-Seidel baseline
     2) mg33       : classical geometric MG, pre=3 post=3
     3) rmt3p6     : RMT-style triple-coarsening, post=6
     4) rmt3c4p6   : RMT-style + combined coarse 4-sweep smoothing, post=6

   Runs for each configuration:
     - serial (threads=1)
     - 4-core OpenMP (threads=4)

   Benchmark C V1 operator:
      -d/dx( kx(x,y) du/dx ) - d/dy( ky(x,y) du/dy )
      + bx du/dx + by du/dy + q0 u = f

   Diffusion field:
      constFlow : kx=1+amp*sin(2*pi*x), ky=1+amp*cos(2*pi*y)
      advAniso  : kx=1+amp*sin(2*pi*x), ky=anisoKy*(1+amp*cos(2*pi*y))

   Advection field:
      constant diagonal flow with magnitude |b| = PeRef
      bx = by = PeRef / sqrt(2)

   Discretization notes:
      - diffusion is finite-volume flux form, identical in spirit to Benchmark B
      - advection is first-order upwind to keep the benchmark robust as Pe increases
      - RHS is built algebraically from the discrete operator, consistent with the
        discrete-manufactured approach used in Benchmarks A and B

   Exact manufactured discrete solution:
      u_exact(x,y) = exp(sigma*(x+y))

   CSV outputs:
     csv_benchmarkC_v2_rmtstress/
       - all_runs_summary.csv
       - one summary CSV per (n, Pe)
       - one exact CSV per (n, Pe)
       - one field CSV per (n, Pe, solver, threads)

   Compile:
     gcc -O2 -std=c11 -fopenmp benchmarkC_v1_convection_diffusion_parallel_csv.c -lm -o benchmarkC_v1_convection_diffusion_parallel_csv

   Run defaults:
     ./benchmarkC_v1_convection_diffusion_parallel_csv

   Run one fixed configuration only:
     ./benchmarkC_v1_convection_diffusion_parallel_csv -meshSweep 0 -peSweep 0 -n 107 -PeRef 200

   Custom mesh list:
     ./benchmarkC_v1_convection_diffusion_parallel_csv -nList 53,107,215

   Optional Pe sweep:
     ./benchmarkC_v1_convection_diffusion_parallel_csv -peSweep 1 -peList 50,200,800
*/


/* TRUBA/Ubuntu rerun package update (2026-09):
   -writeFields 0 suppresses large exact/field CSV files while retaining summary CSVs.
   This changes output control only; numerical operators and solver algorithms are unchanged.
*/
#define ID(i,j,nx) ((size_t)(i) + (size_t)(nx) * (size_t)(j))

typedef enum {
    CASE_CONSTFLOW = 0,
    CASE_ADVANISO  = 1,
    CASE_ALL       = 2
} CaseType;

typedef struct {
    int n;
    double h;
    double *aP, *aE, *aW, *aN, *aS;
    double *kxCell, *kyCell, *qCell;
    double *bxCell, *byCell, *peCell;
} Op2D;

typedef struct {
    int n;
    double h;
    double tol;
    int maxIter;
    int verbose;
    int writeCSV;
    int writeFields; /* write exact/field CSVs; summaries still controlled by writeCSV */
    int runAllCases;
    int coarseExactN;
    double omegaEuler;
    double sigma;
    double q0;
    double amp;
    double anisoKy;
    double PeRef;
    double flowAngleDeg;
    CaseType problem;
    int meshSweep;
    int peSweep;
    int nList[MAX_SWEEP];
    int nCount;
    double peList[MAX_SWEEP];
    int peCount;
    double maxSolveSeconds;
    int timingRepeats;
    int mg33Profile;
    int fairLeafMaxN;
    int includeUnfairMeshes;
} Params;

typedef enum {
    SOLVER_GS = 0,
    SOLVER_MG33,
    SOLVER_RMT3P6,
    SOLVER_RMT3C4P6
} SolverType;

typedef struct {
    double total;
    double pre_smooth;
    double residual;
    double coarse_setup;
    double restrict_t;
    double coarse_cycle;
    double prolong_t;
    double correction;
    double post_smooth;
    double exact_solve;
    long long vcycles;
    long long exact_calls;
} MG33Profile;

typedef struct {
    const char *name;
    int threads;
    int converged;
    int iterations;
    double residual_rel;
    double error_inf;
    double error_l2;
    double solve_seconds;
    double solve_seconds_min;
    double solve_seconds_max;
    int timing_repeats;
    double speedup_vs_serial;
    int timed_out;
    double *x;
    int has_mg33_profile;
    MG33Profile mg33_profile;
} Summary;

typedef struct {
    int nLevels;
    int stride;
    Op2D *A;
    size_t *N;
    double **r;
    double **bc;
    double **ec;
    double **ef;
} MGHierarchy;

static MG33Profile *g_mg33_prof = NULL;

static double now_seconds(void) {
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (double)ts.tv_sec + 1.0e-9 * (double)ts.tv_nsec;
}

static void *xcalloc(size_t n, size_t sz, const char *what) {
    void *p = calloc(n, sz);
    if (!p) {
        fprintf(stderr, "FATAL: allocation failed for %s\n", what);
        exit(1);
    }
    return p;
}

static int ensure_dir(const char *path) {
    if (mkdir(path, 0777) == 0) return 0;
    if (errno == EEXIST) return 0;
    return -1;
}

static void mg33_profile_reset(MG33Profile *p) {
    memset(p, 0, sizeof(*p));
}

static int cmp_double_asc(const void *a, const void *b) {
    const double da = *(const double*)a;
    const double db = *(const double*)b;
    return (da > db) - (da < db);
}

static double median_of(double *vals, int n) {
    if (n <= 0) return 0.0;
    qsort(vals, (size_t)n, sizeof(double), cmp_double_asc);
    if (n & 1) return vals[n/2];
    return 0.5 * (vals[n/2 - 1] + vals[n/2]);
}

static const char *case_name(CaseType c) {
    switch (c) {
        case CASE_CONSTFLOW: return "constFlow";
        case CASE_ADVANISO:  return "advAniso";
        case CASE_ALL:       return "all";
        default: return "unknown";
    }
}

static const char *stiff_name(CaseType c) {
    (void)c;
    return "Pe";
}

static const char *solver_name(SolverType s) {
    switch (s) {
        case SOLVER_GS:       return "gsRB";
        case SOLVER_MG33:     return "mg33";
        case SOLVER_RMT3P6:   return "rmt3p6";
        case SOLVER_RMT3C4P6: return "rmt3c4p6";
        default: return "unknown";
    }
}

static int parse_int_list(const char *txt, int *out, int maxn) {
    char buf[512];
    strncpy(buf, txt, sizeof(buf)-1);
    buf[sizeof(buf)-1] = '\0';
    int cnt = 0;
    char *tok = strtok(buf, ",");
    while (tok && cnt < maxn) {
        out[cnt++] = atoi(tok);
        tok = strtok(NULL, ",");
    }
    return cnt;
}

static int parse_double_list(const char *txt, double *out, int maxn) {
    char buf[512];
    strncpy(buf, txt, sizeof(buf)-1);
    buf[sizeof(buf)-1] = '\0';
    int cnt = 0;
    char *tok = strtok(buf, ",");
    while (tok && cnt < maxn) {
        out[cnt++] = atof(tok);
        tok = strtok(NULL, ",");
    }
    return cnt;
}

static double u_exact_sigma(double x, double y, double sigma) {
    return exp(sigma * (x + y));
}

static double kx_case(const Params *p, CaseType c, double x, double y) {
    (void)c; (void)y;
    return 1.0 + p->amp * sin(2.0 * M_PI * x);
}

static double ky_case(const Params *p, CaseType c, double x, double y) {
    (void)x;
    if (c == CASE_ADVANISO) return p->anisoKy * (1.0 + p->amp * cos(2.0 * M_PI * y));
    return 1.0 + p->amp * cos(2.0 * M_PI * y);
}

static double q_case(const Params *p, CaseType c, double x, double y) {
    (void)c; (void)x; (void)y;
    return p->q0;
}

static void advection_components(const Params *p, double *bx, double *by) {
    const double ang = p->flowAngleDeg * (M_PI / 180.0);
    *bx = p->PeRef * cos(ang);
    *by = p->PeRef * sin(ang);
}

static double bx_case(const Params *p, CaseType c, double x, double y) {
    (void)c; (void)x; (void)y;
    double bx = 0.0, by = 0.0;
    advection_components(p, &bx, &by);
    return bx;
}

static double by_case(const Params *p, CaseType c, double x, double y) {
    (void)c; (void)x; (void)y;
    double bx = 0.0, by = 0.0;
    advection_components(p, &bx, &by);
    return by;
}

static void op2d_alloc(Op2D *A, int n) {
    const size_t N = (size_t)n * (size_t)n;
    A->n = n;
    A->h = 1.0 / (double)(n + 1);
    A->aP = (double*)xcalloc(N, sizeof(double), "aP");
    A->aE = (double*)xcalloc(N, sizeof(double), "aE");
    A->aW = (double*)xcalloc(N, sizeof(double), "aW");
    A->aN = (double*)xcalloc(N, sizeof(double), "aN");
    A->aS = (double*)xcalloc(N, sizeof(double), "aS");
    A->kxCell = (double*)xcalloc(N, sizeof(double), "kxCell");
    A->kyCell = (double*)xcalloc(N, sizeof(double), "kyCell");
    A->qCell  = (double*)xcalloc(N, sizeof(double), "qCell");
    A->bxCell = (double*)xcalloc(N, sizeof(double), "bxCell");
    A->byCell = (double*)xcalloc(N, sizeof(double), "byCell");
    A->peCell = (double*)xcalloc(N, sizeof(double), "peCell");
}

static void op2d_free(Op2D *A) {
    free(A->aP); free(A->aE); free(A->aW); free(A->aN); free(A->aS);
    free(A->kxCell); free(A->kyCell); free(A->qCell);
    free(A->bxCell); free(A->byCell); free(A->peCell);
    memset(A, 0, sizeof(*A));
}

static void build_operator(Op2D *A, const Params *p, int n, CaseType c) {
    op2d_alloc(A, n);
    const double h = A->h;
    const double h2 = h * h;
    for (int j = 0; j < n; ++j) {
        for (int i = 0; i < n; ++i) {
            const double x = (double)(i + 1) * h;
            const double y = (double)(j + 1) * h;
            const double ke = kx_case(p, c, x + 0.5*h, y) / h2;
            const double kw = kx_case(p, c, x - 0.5*h, y) / h2;
            const double kn = ky_case(p, c, x, y + 0.5*h) / h2;
            const double ks = ky_case(p, c, x, y - 0.5*h) / h2;
            const double qv = q_case(p, c, x, y);
            const double bx = bx_case(p, c, x, y);
            const double by = by_case(p, c, x, y);

            const double aEadv = (bx < 0.0) ? (-bx) / h : 0.0;
            const double aWadv = (bx > 0.0) ? ( bx) / h : 0.0;
            const double aNadv = (by < 0.0) ? (-by) / h : 0.0;
            const double aSadv = (by > 0.0) ? ( by) / h : 0.0;

            const double aE = ke + aEadv;
            const double aW = kw + aWadv;
            const double aN = kn + aNadv;
            const double aS = ks + aSadv;

            const size_t idx = ID(i,j,n);
            A->aE[idx] = aE;
            A->aW[idx] = aW;
            A->aN[idx] = aN;
            A->aS[idx] = aS;
            A->aP[idx] = aE + aW + aN + aS + qv;
            A->kxCell[idx] = kx_case(p, c, x, y);
            A->kyCell[idx] = ky_case(p, c, x, y);
            A->qCell[idx]  = qv;
            A->bxCell[idx] = bx;
            A->byCell[idx] = by;
            {
                const double km = 0.5 * (A->kxCell[idx] + A->kyCell[idx]);
                const double bmag = sqrt(bx*bx + by*by);
                A->peCell[idx] = (km > 0.0) ? (bmag * h / (2.0 * km)) : 0.0;
            }
        }
    }
}

static void build_u_exact(const Op2D *A, double sigma, double *u) {
    const int n = A->n;
    const double h = A->h;
    #pragma omp parallel for collapse(2) schedule(static) if(((size_t)n*(size_t)n) >= OMP_MIN_WORK)
    for (int j = 0; j < n; ++j)
        for (int i = 0; i < n; ++i)
            u[ID(i,j,n)] = u_exact_sigma((double)(i + 1) * h, (double)(j + 1) * h, sigma);
}

static void apply_A(const Op2D *A, const double *x, double *y) {
    const int n = A->n;
    #pragma omp parallel for collapse(2) schedule(static) if(((size_t)n*(size_t)n) >= OMP_MIN_WORK)
    for (int j = 0; j < n; ++j) {
        for (int i = 0; i < n; ++i) {
            const size_t p = ID(i,j,n);
            double v = A->aP[p] * x[p];
            if (i + 1 < n) v -= A->aE[p] * x[ID(i+1,j,n)];
            if (i > 0)     v -= A->aW[p] * x[ID(i-1,j,n)];
            if (j + 1 < n) v -= A->aN[p] * x[ID(i,j+1,n)];
            if (j > 0)     v -= A->aS[p] * x[ID(i,j-1,n)];
            y[p] = v;
        }
    }
}

static void build_rhs(const Op2D *A, const double *uEx, double *b) { apply_A(A, uEx, b); }

static void compute_residual(const Op2D *A, const double *x, const double *b, double *r) {
    apply_A(A, x, r);
    const size_t N = (size_t)A->n * (size_t)A->n;
    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t p = 0; p < N; ++p) r[p] = b[p] - r[p];
}

static double l2_norm(const double *x, size_t N) {
    double s = 0.0;
    #pragma omp parallel for reduction(+:s) schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t i = 0; i < N; ++i) s += x[i] * x[i];
    return sqrt(s / (double)(N > 0 ? N : 1));
}

static double linf_error(const double *x, const double *y, size_t N) {
    double m = 0.0;
    #pragma omp parallel for reduction(max:m) schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t i = 0; i < N; ++i) {
        double e = fabs(x[i] - y[i]);
        if (e > m) m = e;
    }
    return m;
}

static double l2_error(const double *x, const double *y, size_t N) {
    double s = 0.0;
    #pragma omp parallel for reduction(+:s) schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t i = 0; i < N; ++i) {
        double e = x[i] - y[i];
        s += e * e;
    }
    return sqrt(s / (double)(N > 0 ? N : 1));
}

static void rbgs_sweep(const Op2D *A, double *x, const double *b) {
    const int n = A->n;
    for (int color = 0; color < 2; ++color) {
        #pragma omp parallel for collapse(2) schedule(static) if(((size_t)n*(size_t)n) >= OMP_MIN_WORK)
        for (int j = 0; j < n; ++j) {
            for (int i = 0; i < n; ++i) {
                if (((i + j) & 1) != color) continue;
                const size_t p = ID(i,j,n);
                double rhs = b[p];
                if (i + 1 < n) rhs += A->aE[p] * x[ID(i+1,j,n)];
                if (i > 0)     rhs += A->aW[p] * x[ID(i-1,j,n)];
                if (j + 1 < n) rhs += A->aN[p] * x[ID(i,j+1,n)];
                if (j > 0)     rhs += A->aS[p] * x[ID(i,j-1,n)];
                x[p] = rhs / A->aP[p];
            }
        }
    }
}

static void rbgs_fixed_sweeps(const Op2D *A, double *x, const double *b, int sweeps) {
    for (int s = 0; s < sweeps; ++s) rbgs_sweep(A, x, b);
}

static void jacobi_step(const Op2D *A, double *x, const double *b, double omega, double *rbuf) {
    compute_residual(A, x, b, rbuf);
    const size_t N = (size_t)A->n * (size_t)A->n;
    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t p = 0; p < N; ++p) x[p] += omega * rbuf[p] / A->aP[p];
}

static void exact_solve_dense(const Op2D *A, const double *b, double *x) {
    const int n = A->n;
    const int N = n*n;
    double *M = (double*)xcalloc((size_t)N * (size_t)N, sizeof(double), "dense matrix");
    double *rhs = (double*)xcalloc((size_t)N, sizeof(double), "dense rhs");
    for (int j=0;j<n;++j) for (int i=0;i<n;++i) {
        int row = i + n*j;
        size_t p = ID(i,j,n);
        M[(size_t)row*(size_t)N + (size_t)row] = A->aP[p];
        if (i + 1 < n) M[(size_t)row*(size_t)N + (size_t)(row+1)] = -A->aE[p];
        if (i > 0)     M[(size_t)row*(size_t)N + (size_t)(row-1)] = -A->aW[p];
        if (j + 1 < n) M[(size_t)row*(size_t)N + (size_t)(row+n)] = -A->aN[p];
        if (j > 0)     M[(size_t)row*(size_t)N + (size_t)(row-n)] = -A->aS[p];
        rhs[row] = b[p];
    }
    for (int k=0;k<N;++k) {
        int piv = k;
        double amax = fabs(M[(size_t)k*(size_t)N + (size_t)k]);
        for (int i=k+1;i<N;++i) {
            double av = fabs(M[(size_t)i*(size_t)N + (size_t)k]);
            if (av > amax) { amax = av; piv = i; }
        }
        if (amax < 1e-30) {
            fprintf(stderr, "FATAL: singular coarse matrix\n");
            exit(1);
        }
        if (piv != k) {
            for (int jcol=k;jcol<N;++jcol) {
                double tmp = M[(size_t)k*(size_t)N + (size_t)jcol];
                M[(size_t)k*(size_t)N + (size_t)jcol] = M[(size_t)piv*(size_t)N + (size_t)jcol];
                M[(size_t)piv*(size_t)N + (size_t)jcol] = tmp;
            }
            double tr = rhs[k];
            rhs[k] = rhs[piv];
            rhs[piv] = tr;
        }
        double diag = M[(size_t)k*(size_t)N + (size_t)k];
        for (int i=k+1;i<N;++i) {
            double f = M[(size_t)i*(size_t)N + (size_t)k] / diag;
            M[(size_t)i*(size_t)N + (size_t)k] = 0.0;
            if (f == 0.0) continue;
            for (int jcol=k+1;jcol<N;++jcol)
                M[(size_t)i*(size_t)N + (size_t)jcol] -= f * M[(size_t)k*(size_t)N + (size_t)jcol];
            rhs[i] -= f * rhs[k];
        }
    }
    for (int i=N-1;i>=0;--i) {
        double s = rhs[i];
        for (int jcol=i+1;jcol<N;++jcol)
            s -= M[(size_t)i*(size_t)N + (size_t)jcol] * x[jcol];
        x[i] = s / M[(size_t)i*(size_t)N + (size_t)i];
    }
    free(M);
    free(rhs);
}

static int can_coarsen_2h(int n) { return ((n + 1) % 2) == 0 && (((n + 1) / 2) - 1) >= 1; }
static int coarse_n_2h(int n) { return ((n + 1) / 2) - 1; }
static int can_coarsen_3h(int n) { return ((n + 1) % 3) == 0 && (((n + 1) / 3) - 1) >= 1; }
static int coarse_n_3h(int n) { return ((n + 1) / 3) - 1; }

static void restrict_fw_2h(const double *rf, int nf, double *rc, int nc) {
    #pragma omp parallel for collapse(2) schedule(static) if(((size_t)nc*(size_t)nc) >= OMP_MIN_WORK)
    for (int J=0;J<nc;++J) for (int I=0;I<nc;++I) {
        int jf = 2*(J+1)-1, ifi = 2*(I+1)-1;
        double s = 0.0;
        s += 4.0*rf[ID(ifi,jf,nf)];
        if (ifi>0)    s += 2.0*rf[ID(ifi-1,jf,nf)];
        if (ifi+1<nf) s += 2.0*rf[ID(ifi+1,jf,nf)];
        if (jf>0)     s += 2.0*rf[ID(ifi,jf-1,nf)];
        if (jf+1<nf)  s += 2.0*rf[ID(ifi,jf+1,nf)];
        if (ifi>0 && jf>0)       s += rf[ID(ifi-1,jf-1,nf)];
        if (ifi>0 && jf+1<nf)    s += rf[ID(ifi-1,jf+1,nf)];
        if (ifi+1<nf && jf>0)    s += rf[ID(ifi+1,jf-1,nf)];
        if (ifi+1<nf && jf+1<nf) s += rf[ID(ifi+1,jf+1,nf)];
        rc[ID(I,J,nc)] = s/16.0;
    }
}

static inline double coarse_ext_value(const double *ec, int nc, int I, int J) {
    if (I < 1 || I > nc || J < 1 || J > nc) return 0.0;
    return ec[ID(I-1,J-1,nc)];
}

static void prolong_bilinear_noalloc(const double *ec, int nc, double *ef, int nf) {
    #pragma omp parallel for collapse(2) schedule(static) if(((size_t)nf*(size_t)nf) >= OMP_MIN_WORK)
    for (int j=0;j<nf;++j) for (int i=0;i<nf;++i) {
        double y = (double)(j+1)/(double)(nf+1), sc = y*(double)(nc+1);
        int J0=(int)floor(sc); if(J0<0)J0=0; if(J0>nc)J0=nc; double ty=sc-(double)J0; int J1=J0+1;
        double x = (double)(i+1)/(double)(nf+1), tc = x*(double)(nc+1);
        int I0=(int)floor(tc); if(I0<0)I0=0; if(I0>nc)I0=nc; double tx=tc-(double)I0; int I1=I0+1;
        double c00=coarse_ext_value(ec,nc,I0,J0), c10=coarse_ext_value(ec,nc,I1,J0), c01=coarse_ext_value(ec,nc,I0,J1), c11=coarse_ext_value(ec,nc,I1,J1);
        ef[ID(i,j,nf)] = (1.0-tx)*(1.0-ty)*c00 + tx*(1.0-ty)*c10 + (1.0-tx)*ty*c01 + tx*ty*c11;
    }
}

static void restrict_avg_3h(const double *rf, int nf, double *rc, int nc) {
    #pragma omp parallel for collapse(2) schedule(static) if(((size_t)nc*(size_t)nc) >= OMP_MIN_WORK)
    for (int J=0;J<nc;++J) for (int I=0;I<nc;++I) {
        int jf = 3*(J+1)-1, ifi = 3*(I+1)-1;
        double s = 0.0;
        int cnt = 0;
        for (int dj=-1;dj<=1;++dj) {
            int jj = jf + dj;
            if (jj<0 || jj>=nf) continue;
            for (int di=-1;di<=1;++di) {
                int ii = ifi + di;
                if (ii<0 || ii>=nf) continue;
                s += rf[ID(ii,jj,nf)];
                ++cnt;
            }
        }
        rc[ID(I,J,nc)] = (cnt>0 ? s/(double)cnt : 0.0);
    }
}

static int hierarchy_next_n(int n, int stride) {
    return (stride == 2) ? coarse_n_2h(n) : coarse_n_3h(n);
}

static int hierarchy_can_coarsen(int n, int stride) {
    return (stride == 2) ? can_coarsen_2h(n) : can_coarsen_3h(n);
}

static void hierarchy_build(MGHierarchy *H, const Params *p, int nFine, CaseType c, int stride) {
    memset(H, 0, sizeof(*H));
    H->stride = stride;
    int nLevels = 1;
    int ncur = nFine;
    while (ncur > p->coarseExactN && hierarchy_can_coarsen(ncur, stride)) {
        ncur = hierarchy_next_n(ncur, stride);
        ++nLevels;
    }
    H->nLevels = nLevels;
    H->A  = (Op2D*)xcalloc((size_t)nLevels, sizeof(Op2D), "hier A");
    H->N  = (size_t*)xcalloc((size_t)nLevels, sizeof(size_t), "hier N");
    H->r  = (double**)xcalloc((size_t)nLevels, sizeof(double*), "hier r");
    H->bc = (double**)xcalloc((size_t)nLevels, sizeof(double*), "hier bc");
    H->ec = (double**)xcalloc((size_t)nLevels, sizeof(double*), "hier ec");
    H->ef = (double**)xcalloc((size_t)nLevels, sizeof(double*), "hier ef");

    ncur = nFine;
    for (int l = 0; l < nLevels; ++l) {
        build_operator(&H->A[l], p, ncur, c);
        H->N[l] = (size_t)ncur * (size_t)ncur;
        if (l + 1 < nLevels) {
            int nc = hierarchy_next_n(ncur, stride);
            size_t Nc = (size_t)nc * (size_t)nc;
            H->r[l]  = (double*)xcalloc(H->N[l], sizeof(double), "hier r level");
            H->bc[l] = (double*)xcalloc(Nc, sizeof(double), "hier bc level");
            H->ec[l] = (double*)xcalloc(Nc, sizeof(double), "hier ec level");
            H->ef[l] = (double*)xcalloc(H->N[l], sizeof(double), "hier ef level");
            ncur = nc;
        }
    }
}

static void hierarchy_free(MGHierarchy *H) {
    if (!H) return;
    if (H->A) {
        for (int l = 0; l < H->nLevels; ++l) op2d_free(&H->A[l]);
        free(H->A);
    }
    if (H->r)  { for (int l=0;l<H->nLevels;++l) free(H->r[l]);  free(H->r); }
    if (H->bc) { for (int l=0;l<H->nLevels;++l) free(H->bc[l]); free(H->bc); }
    if (H->ec) { for (int l=0;l<H->nLevels;++l) free(H->ec[l]); free(H->ec); }
    if (H->ef) { for (int l=0;l<H->nLevels;++l) free(H->ef[l]); free(H->ef); }
    free(H->N);
    memset(H, 0, sizeof(*H));
}

static void mg33_vcycle_cached(const Params *p, const MGHierarchy *H, int level, double *x, const double *b) {
    (void)p;
    const Op2D *A = &H->A[level];
    const size_t N = H->N[level];
    if (g_mg33_prof) g_mg33_prof->vcycles++;
    if (level == H->nLevels - 1) {
        if (g_mg33_prof) {
            double t0 = now_seconds();
            exact_solve_dense(A, b, x);
            g_mg33_prof->exact_solve += now_seconds() - t0;
            g_mg33_prof->exact_calls++;
        } else {
            exact_solve_dense(A, b, x);
        }
        return;
    }

    if (g_mg33_prof) {
        double t0 = now_seconds();
        for (int s=0;s<3;++s) rbgs_sweep(A, x, b);
        g_mg33_prof->pre_smooth += now_seconds() - t0;
        t0 = now_seconds();
        compute_residual(A, x, b, H->r[level]);
        g_mg33_prof->residual += now_seconds() - t0;
        t0 = now_seconds();
        restrict_fw_2h(H->r[level], A->n, H->bc[level], H->A[level+1].n);
        g_mg33_prof->restrict_t += now_seconds() - t0;
    } else {
        for (int s=0;s<3;++s) rbgs_sweep(A, x, b);
        compute_residual(A, x, b, H->r[level]);
        restrict_fw_2h(H->r[level], A->n, H->bc[level], H->A[level+1].n);
    }

    memset(H->ec[level], 0, H->N[level+1] * sizeof(double));
    mg33_vcycle_cached(p, H, level+1, H->ec[level], H->bc[level]);

    if (g_mg33_prof) {
        double t0 = now_seconds();
        prolong_bilinear_noalloc(H->ec[level], H->A[level+1].n, H->ef[level], A->n);
        g_mg33_prof->prolong_t += now_seconds() - t0;
        t0 = now_seconds();
        #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
        for (size_t q=0;q<N;++q) x[q] += H->ef[level][q];
        g_mg33_prof->correction += now_seconds() - t0;
        t0 = now_seconds();
        for (int s=0;s<3;++s) rbgs_sweep(A, x, b);
        g_mg33_prof->post_smooth += now_seconds() - t0;
    } else {
        prolong_bilinear_noalloc(H->ec[level], H->A[level+1].n, H->ef[level], A->n);
        #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
        for (size_t q=0;q<N;++q) x[q] += H->ef[level][q];
        for (int s=0;s<3;++s) rbgs_sweep(A, x, b);
    }
}

static void rmt3p6_cycle_cached(const Params *p, const MGHierarchy *H, int level, double *x, const double *b) {
    (void)p;
    const Op2D *A = &H->A[level];
    const size_t N = H->N[level];
    if (level == H->nLevels - 1) {
        exact_solve_dense(A, b, x);
        return;
    }
    compute_residual(A, x, b, H->r[level]);
    restrict_avg_3h(H->r[level], A->n, H->bc[level], H->A[level+1].n);
    memset(H->ec[level], 0, H->N[level+1] * sizeof(double));
    rmt3p6_cycle_cached(p, H, level+1, H->ec[level], H->bc[level]);
    prolong_bilinear_noalloc(H->ec[level], H->A[level+1].n, H->ef[level], A->n);
    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t q=0;q<N;++q) x[q] += H->ef[level][q];
    for (int s=0;s<6;++s) rbgs_sweep(A, x, b);
}

static void rmt3c4p6_cycle_cached(const Params *p, const MGHierarchy *H, int level, double *x, const double *b) {
    (void)p;
    const Op2D *A = &H->A[level];
    const size_t N = H->N[level];
    if (level == H->nLevels - 1) {
        exact_solve_dense(A, b, x);
        return;
    }
    if (level > 0) rbgs_fixed_sweeps(A, x, b, 4);
    compute_residual(A, x, b, H->r[level]);
    restrict_avg_3h(H->r[level], A->n, H->bc[level], H->A[level+1].n);
    memset(H->ec[level], 0, H->N[level+1] * sizeof(double));
    rmt3c4p6_cycle_cached(p, H, level+1, H->ec[level], H->bc[level]);
    if (level > 0) rbgs_fixed_sweeps(&H->A[level+1], H->ec[level], H->bc[level], 4);
    prolong_bilinear_noalloc(H->ec[level], H->A[level+1].n, H->ef[level], A->n);
    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t q=0;q<N;++q) x[q] += H->ef[level][q];
    if (level == 0) for (int s=0;s<6;++s) rbgs_sweep(A, x, b); else rbgs_fixed_sweeps(A, x, b, 4);
}

static void init_params(Params *p) {
    memset(p, 0, sizeof(*p));
    p->n = 215;
    p->tol = 1e-8;
    p->maxIter = 1000;
    p->verbose = 0;
    p->writeCSV = 1; p->writeFields = 1;
    p->runAllCases = 1;
    p->coarseExactN = 5;
    p->omegaEuler = 0.8;
    p->sigma = 6.0;
    p->q0 = 1.0;
    p->amp = 0.75;
    p->anisoKy = 0.03;
    p->PeRef = 800.0;
    p->flowAngleDeg = 30.0;
    p->problem = CASE_CONSTFLOW;
    p->meshSweep = 1;
    p->peSweep = 1;
    p->nList[0] = 107; p->nList[1] = 215; p->nList[2] = 431; p->nCount = 3;
    p->peList[0] = 200.0; p->peList[1] = 800.0; p->peList[2] = 3200.0; p->peCount = 3;
    p->maxSolveSeconds = 30.0;
    p->timingRepeats = 3;
    p->mg33Profile = 1;
    p->fairLeafMaxN = 32;
    p->includeUnfairMeshes = 0;
}

static void parse_args(int argc, char **argv, Params *p) {
    for (int i=1;i<argc;++i) {
        if (!strcmp(argv[i], "-n") && i+1<argc) p->n = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-tol") && i+1<argc) p->tol = atof(argv[++i]);
        else if (!strcmp(argv[i], "-maxIter") && i+1<argc) p->maxIter = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-verbose") && i+1<argc) p->verbose = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-writeCSV") && i+1<argc) p->writeCSV = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-writeFields") && i+1<argc) p->writeFields = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-coarseExactN") && i+1<argc) p->coarseExactN = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-sigma") && i+1<argc) p->sigma = atof(argv[++i]);
        else if (!strcmp(argv[i], "-q0") && i+1<argc) p->q0 = atof(argv[++i]);
        else if (!strcmp(argv[i], "-amp") && i+1<argc) p->amp = atof(argv[++i]);
        else if (!strcmp(argv[i], "-anisoKy") && i+1<argc) p->anisoKy = atof(argv[++i]);
        else if (!strcmp(argv[i], "-PeRef") && i+1<argc) p->PeRef = atof(argv[++i]);
        else if (!strcmp(argv[i], "-flowAngleDeg") && i+1<argc) p->flowAngleDeg = atof(argv[++i]);
        else if (!strcmp(argv[i], "-meshSweep") && i+1<argc) p->meshSweep = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-peSweep") && i+1<argc) p->peSweep = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-nList") && i+1<argc) p->nCount = parse_int_list(argv[++i], p->nList, MAX_SWEEP);
        else if (!strcmp(argv[i], "-peList") && i+1<argc) p->peCount = parse_double_list(argv[++i], p->peList, MAX_SWEEP);
        else if (!strcmp(argv[i], "-maxSolveSeconds") && i+1<argc) p->maxSolveSeconds = atof(argv[++i]);
        else if (!strcmp(argv[i], "-timingRepeats") && i+1<argc) p->timingRepeats = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-mg33Profile") && i+1<argc) p->mg33Profile = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-fairLeafMaxN") && i+1<argc) p->fairLeafMaxN = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-includeUnfairMeshes") && i+1<argc) p->includeUnfairMeshes = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-case") && i+1<argc) {
            ++i;
            p->runAllCases = 0;
            if (!strcmp(argv[i], "constFlow")) p->problem = CASE_CONSTFLOW;
            else if (!strcmp(argv[i], "advAniso")) p->problem = CASE_ADVANISO;
            else if (!strcmp(argv[i], "all")) { p->problem = CASE_ALL; p->runAllCases = 1; }
            else { fprintf(stderr, "unknown case '%s'\n", argv[i]); exit(1); }
        }
    }
}

static void set_threads(int nthreads) {
#ifdef _OPENMP
    omp_set_dynamic(0);
    omp_set_num_threads(nthreads);
#else
    (void)nthreads;
#endif
}

static Summary run_solver_once(const Params *p, const Op2D *A, const double *b, const double *uEx, double r0,
                               const MGHierarchy *H2, const MGHierarchy *H3,
                               SolverType solver, int threads, int enableMg33Profile) {
    Summary s;
    memset(&s, 0, sizeof(s));
    s.name = solver_name(solver);
    s.threads = threads;
    size_t N = (size_t)A->n * (size_t)A->n;
    double *x = (double*)xcalloc(N, sizeof(double), s.name);
    double *r = (double*)xcalloc(N, sizeof(double), "residual buffer");
    double *jbuf = NULL;
    MG33Profile localProf;
    mg33_profile_reset(&localProf);
    if (solver == SOLVER_GS) memset(x, 0, N*sizeof(double));
    set_threads(threads);
    if (enableMg33Profile && solver == SOLVER_MG33) g_mg33_prof = &localProf;
    if (solver == SOLVER_GS && p->omegaEuler != 0.0) jbuf = (double*)xcalloc(N, sizeof(double), "jacobi buffer");

    double t0 = now_seconds();
    for (int it=1; it<=p->maxIter; ++it) {
        if (solver == SOLVER_GS) {
            rbgs_sweep(A, x, b);
            if (jbuf && p->omegaEuler > 0.0) jacobi_step(A, x, b, 0.05 * p->omegaEuler, jbuf);
        }
        else if (solver == SOLVER_MG33) mg33_vcycle_cached(p, H2, 0, x, b);
        else if (solver == SOLVER_RMT3P6) rmt3p6_cycle_cached(p, H3, 0, x, b);
        else if (solver == SOLVER_RMT3C4P6) rmt3c4p6_cycle_cached(p, H3, 0, x, b);

        compute_residual(A, x, b, r);
        s.iterations = it;
        s.residual_rel = l2_norm(r, N) / r0;
        if (p->verbose && (it <= 10 || it % 50 == 0))
            printf("  %-9s thr=%d iter=%6d residual_rel=% .5e\n", s.name, threads, it, s.residual_rel);
        if (s.residual_rel < p->tol) { s.converged = 1; break; }
        if (p->maxSolveSeconds > 0.0 && (now_seconds() - t0) > p->maxSolveSeconds) { s.timed_out = 1; break; }
    }
    s.solve_seconds = now_seconds() - t0;
    if (enableMg33Profile && solver == SOLVER_MG33) {
        s.has_mg33_profile = 1;
        s.mg33_profile = localProf;
        g_mg33_prof = NULL;
    }
    if (!(enableMg33Profile && solver == SOLVER_MG33)) g_mg33_prof = NULL;
    s.error_inf = linf_error(x, uEx, N);
    s.error_l2  = l2_error(x, uEx, N);
    s.x = x;
    free(jbuf);
    free(r);
    return s;
}

static Summary run_solver(const Params *p, const Op2D *A, const double *b, const double *uEx, double r0,
                          const MGHierarchy *H2, const MGHierarchy *H3,
                          SolverType solver, int threads) {
    int reps = p->timingRepeats > 0 ? p->timingRepeats : 1;
    double *times = (double*)xcalloc((size_t)reps, sizeof(double), "timing repeats");

    Summary out = run_solver_once(p, A, b, uEx, r0, H2, H3, solver, threads, 0);
    out.timing_repeats = reps;
    times[0] = out.solve_seconds;

    for (int rep = 1; rep < reps; ++rep) {
        Summary tmp = run_solver_once(p, A, b, uEx, r0, H2, H3, solver, threads, 0);
        times[rep] = tmp.solve_seconds;
        free(tmp.x);
    }

    double tmin = times[0], tmax = times[0];
    for (int i = 1; i < reps; ++i) {
        if (times[i] < tmin) tmin = times[i];
        if (times[i] > tmax) tmax = times[i];
    }
    double *tsorted = (double*)xcalloc((size_t)reps, sizeof(double), "sorted timing repeats");
    memcpy(tsorted, times, (size_t)reps * sizeof(double));
    out.solve_seconds = median_of(tsorted, reps);
    out.solve_seconds_min = tmin;
    out.solve_seconds_max = tmax;
    free(tsorted);
    free(times);

    if (solver == SOLVER_MG33 && p->mg33Profile) {
        Summary prof = run_solver_once(p, A, b, uEx, r0, H2, H3, solver, threads, 1);
        out.has_mg33_profile = 1;
        out.mg33_profile = prof.mg33_profile;
        free(prof.x);
    }

    return out;
}

static void write_csv_solution(const char *path, const Op2D *A, const double *u, const double *uEx, const double *b,
                               const char *caseLabel, const char *solverLabel, int threads,
                               const char *stiffLabel, double stiffVal) {
    FILE *fp = fopen(path, "w");
    if (!fp) { fprintf(stderr, "warning: could not open %s\n", path); return; }
    int n = A->n;
    double h = A->h;
    fprintf(fp, "# case,%s\n# solver,%s\n# threads,%d\n# n,%d\n# h,%.16e\n# %s,%.16e\n", caseLabel, solverLabel, threads, n, h, stiffLabel, stiffVal);
    fprintf(fp, "i,j,x,y,u,u_exact,error,rhs,kx_cell,ky_cell,q_cell,bx_cell,by_cell,cell_Pe\n");
    for (int j=0;j<n;++j) for (int i=0;i<n;++i) {
        size_t idx = ID(i,j,n);
        double x = (double)(i+1) * h;
        double y = (double)(j+1) * h;
        double uu = u ? u[idx] : uEx[idx];
        double ue = uEx[idx];
        fprintf(fp, "%d,%d,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e\n",
                i, j, x, y, uu, ue, uu-ue, b[idx],
                A->kxCell[idx], A->kyCell[idx], A->qCell[idx], A->bxCell[idx], A->byCell[idx], A->peCell[idx]);
    }
    fclose(fp);
}

static void write_summary_csv(const char *path, const Summary *S, int m, const Params *p, const Op2D *A,
                              const char *stiffLabel, double stiffVal) {
    FILE *fp = fopen(path, "w");
    if (!fp) { fprintf(stderr, "warning: could not open %s\n", path); return; }
    fprintf(fp, "problem,stiff_name,stiff_value,n,h,tol,maxIter,sigma,amp,q0,flowAngleDeg,solver,threads,converged,timed_out,iterations,residual_rel,error_inf,error_l2,solve_s_median,solve_s_min,solve_s_max,timing_repeats,speedup\n");
    for (int i=0;i<m;++i) fprintf(fp,
            "%s,%s,%.16e,%d,%.16e,%.16e,%d,%.16e,%.16e,%.16e,%.16e,%s,%d,%d,%d,%d,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%d,%.16e\n",
            case_name(p->problem), stiffLabel, stiffVal, p->n, A->h, p->tol, p->maxIter, p->sigma,
            p->amp, p->q0, p->flowAngleDeg,
            S[i].name, S[i].threads, S[i].converged, S[i].timed_out, S[i].iterations,
            S[i].residual_rel, S[i].error_inf, S[i].error_l2,
            S[i].solve_seconds, S[i].solve_seconds_min, S[i].solve_seconds_max,
            S[i].timing_repeats, S[i].speedup_vs_serial);
    fclose(fp);
}

static void append_global_summary(FILE *fp, const Summary *S, int m, const Params *p, const Op2D *A,
                                  const char *stiffLabel, double stiffVal) {
    for (int i=0;i<m;++i) fprintf(fp,
            "%s,%s,%.16e,%d,%.16e,%.16e,%d,%.16e,%.16e,%.16e,%.16e,%s,%d,%d,%d,%d,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%d,%.16e\n",
            case_name(p->problem), stiffLabel, stiffVal, p->n, A->h, p->tol, p->maxIter, p->sigma,
            p->amp, p->q0, p->flowAngleDeg,
            S[i].name, S[i].threads, S[i].converged, S[i].timed_out, S[i].iterations,
            S[i].residual_rel, S[i].error_inf, S[i].error_l2,
            S[i].solve_seconds, S[i].solve_seconds_min, S[i].solve_seconds_max,
            S[i].timing_repeats, S[i].speedup_vs_serial);
}

static void free_summaries(Summary *S, int m) {
    for (int i=0;i<m;++i) {
        free(S[i].x);
        S[i].x = NULL;
    }
}

static void print_summary(const Summary *S, int m) {
    printf("solver      threads status    iterations residual_rel      error_inf         error_l2          med_s    min_s    max_s   speedup\n");
    printf("----------  ------- --------- ---------- ------------      ---------         --------          ------   ------   ------  -------\n");
    for(int i=0;i<m;++i) {
        const char *status = S[i].converged ? "yes" : (S[i].timed_out ? "timeout" : "no");
        printf("%-10s  %7d %-9s %10d % .5e   % .5e   % .5e   %7.3f  %7.3f  %7.3f   %6.2f\n",
            S[i].name,S[i].threads,status,S[i].iterations,S[i].residual_rel,S[i].error_inf,S[i].error_l2,S[i].solve_seconds,S[i].solve_seconds_min,S[i].solve_seconds_max,S[i].speedup_vs_serial);
    }
}

static void print_mg33_profiles(const Summary *S, int m) {
    for (int i = 0; i < m; ++i) {
        if (!S[i].has_mg33_profile) continue;
        const MG33Profile *p = &S[i].mg33_profile;
        double total = p->pre_smooth + p->residual + p->coarse_setup + p->restrict_t + p->coarse_cycle + p->prolong_t + p->correction + p->post_smooth + p->exact_solve;
        double denom = total > 0.0 ? total : 1.0;
        printf("MG33 cached profile (thr=%d): total=%.3f s | pre=%.1f%% residual=%.1f%% setup=%.1f%% restrict=%.1f%% coarse=%.1f%% prolong=%.1f%% corr=%.1f%% post=%.1f%% exact=%.1f%% | vcycles=%lld exactCalls=%lld\n",
               S[i].threads, total,
               100.0*p->pre_smooth/denom, 100.0*p->residual/denom, 100.0*p->coarse_setup/denom,
               100.0*p->restrict_t/denom, 100.0*p->coarse_cycle/denom, 100.0*p->prolong_t/denom,
               100.0*p->correction/denom, 100.0*p->post_smooth/denom, 100.0*p->exact_solve/denom,
               p->vcycles, p->exact_calls);
    }
}

static void write_mg33_profile_csv(const char *path, const Summary *s) {
    if (!s->has_mg33_profile) return;
    FILE *fp = fopen(path, "w");
    if (!fp) { fprintf(stderr, "warning: could not open %s\n", path); return; }
    const MG33Profile *p = &s->mg33_profile;
    fprintf(fp, "solver,threads,total_s,pre_smooth_s,residual_s,coarse_setup_s,restrict_s,coarse_cycle_s,prolong_s,correction_s,post_smooth_s,exact_solve_s,vcycles,exact_calls\n");
    fprintf(fp, "%s,%d,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%lld,%lld\n",
            s->name, s->threads, p->total, p->pre_smooth, p->residual, p->coarse_setup, p->restrict_t,
            p->coarse_cycle, p->prolong_t, p->correction, p->post_smooth, p->exact_solve, p->vcycles, p->exact_calls);
    fclose(fp);
}

static void print_winners(const Summary *S, int m) {
    int bestSerial=-1, bestParallel=-1, bestErr=-1;
    for (int i=0;i<m;++i) {
        if (!S[i].converged) continue;
        if (S[i].threads==1 && (bestSerial<0 || S[i].solve_seconds < S[bestSerial].solve_seconds)) bestSerial=i;
        if (S[i].threads==4 && (bestParallel<0 || S[i].solve_seconds < S[bestParallel].solve_seconds)) bestParallel=i;
        if (bestErr<0 || S[i].error_inf < S[bestErr].error_inf) bestErr=i;
    }
    printf("Quick takeaways:\n");
    if (bestSerial>=0)  printf("  fastest serial   : %s in %.3f s (%d iterations)\n", S[bestSerial].name, S[bestSerial].solve_seconds, S[bestSerial].iterations);
    if (bestParallel>=0)printf("  fastest 4-thread : %s in %.3f s (speedup %.2f)\n", S[bestParallel].name, S[bestParallel].solve_seconds, S[bestParallel].speedup_vs_serial);
    if (bestErr>=0)     printf("  lowest error_inf : %s (thr=%d) with %.5e\n", S[bestErr].name, S[bestErr].threads, S[bestErr].error_inf);
}

static void describe_stiffness(const Params *p, char *buf, size_t nbuf) {
    double bx = 0.0, by = 0.0;
    advection_components(p, &bx, &by);
    if (p->problem == CASE_ADVANISO) {
        snprintf(buf, nbuf,
                 "kx=1+amp*sin(2*pi*x), ky=anisoKy*(1+amp*cos(2*pi*y)), amp=%g, anisoKy=%g, q0=%g, |b|=%g, bx=%g, by=%g",
                 p->amp, p->anisoKy, p->q0, p->PeRef, bx, by);
    } else {
        snprintf(buf, nbuf,
                 "kx=1+amp*sin(2*pi*x), ky=1+amp*cos(2*pi*y), amp=%g, q0=%g, |b|=%g, bx=%g, by=%g",
                 p->amp, p->q0, p->PeRef, bx, by);
    }
}

static double current_stiff_value(const Params *p) {
    return p->PeRef;
}

static void set_stiff_value(Params *p, double v) {
    p->PeRef = v;
}

static const double *stiff_list_for_case(const Params *p, CaseType c, int *count) {
    (void)c;
    *count = p->peCount;
    return p->peList;
}

static int mg33_terminal_n(int n, int coarseExactN) {
    int ncur = n;
    while (ncur > coarseExactN && can_coarsen_2h(ncur)) ncur = coarse_n_2h(ncur);
    return ncur;
}

static int mg33_mesh_is_fair(const Params *p, int n) {
    int leaf = mg33_terminal_n(n, p->coarseExactN);
    return leaf <= p->fairLeafMaxN;
}

static int pruned_keep_config(const Params *p, CaseType c, int n, double stiffVal) {
    (void)c; (void)stiffVal;
    if (!p->includeUnfairMeshes && !mg33_mesh_is_fair(p, n)) return 0;
    return 1;
}

static int pruned_total_configs(const Params *p, int caseStart, int caseEnd, const CaseType *cases) {
    int total = 0;
    for (int ci=caseStart; ci<caseEnd; ++ci) {
        int stiffCount = 1;
        const double *stiffList = NULL;
        if (p->peSweep) stiffList = stiff_list_for_case(p, cases[ci], &stiffCount);
        int meshCount = p->meshSweep ? p->nCount : 1;
        for (int si=0; si<stiffCount; ++si) {
            double sval = p->peSweep ? stiffList[si] : 0.0;
            for (int mi=0; mi<meshCount; ++mi) {
                int n = p->meshSweep ? p->nList[mi] : p->n;
                if (pruned_keep_config(p, cases[ci], n, sval)) ++total;
            }
        }
    }
    return total;
}

static void run_case_config(const Params *pIn, FILE *globalCsv) {
    Params p = *pIn;
    Op2D A;
    build_operator(&A, &p, p.n, p.problem);
    size_t N = (size_t)p.n * (size_t)p.n;
    MGHierarchy H2, H3;
    hierarchy_build(&H2, &p, p.n, p.problem, 2);
    hierarchy_build(&H3, &p, p.n, p.problem, 3);
    double *uEx  = (double*)xcalloc(N, sizeof(double), "uEx");
    double *b    = (double*)xcalloc(N, sizeof(double), "b");
    double *r0v  = (double*)xcalloc(N, sizeof(double), "r0v");
    build_u_exact(&A, p.sigma, uEx);
    build_rhs(&A, uEx, b);
    memcpy(r0v, b, N*sizeof(double));
    set_threads(1);
    double r0 = l2_norm(r0v, N);
    char stiffBuf[192];
    describe_stiffness(&p, stiffBuf, sizeof(stiffBuf));
    printf("\n------------------------------------------------------------\n");
    printf("case=%s | n=%d | h=%e | %s | tol=%g | maxIter=%d\n", case_name(p.problem), p.n, A.h, stiffBuf, p.tol, p.maxIter);
    printf("exact solution: u_ij = exp(sigma*(x_i + y_j)), sigma=%g\n", p.sigma);
    printf("cached multilevel setup: mg33 levels=%d, rmt3 levels=%d (hierarchy construction excluded from solve time)\n", H2.nLevels, H3.nLevels);
    if (!mg33_mesh_is_fair(&p, p.n))
        printf("fairness warning: mg33 terminal 2h leaf n=%d exceeds fairLeafMaxN=%d; this mesh is excluded by default unless -includeUnfairMeshes 1 is used.\n", mg33_terminal_n(p.n, p.coarseExactN), p.fairLeafMaxN);
    if (!can_coarsen_2h(p.n)) printf("warning: mg33 falls back to exact solve immediately because n is not perfectly 2h-nested\n");
    if (!can_coarsen_3h(p.n)) printf("warning: rmt3 falls back to exact solve immediately because n is not perfectly 3h-nested\n");

    Summary S[8];
    SolverType solvers[4] = {SOLVER_GS, SOLVER_MG33, SOLVER_RMT3P6, SOLVER_RMT3C4P6};
    int idx = 0;
    for (int si=0; si<4; ++si) {
        S[idx++] = run_solver(&p, &A, b, uEx, r0, &H2, &H3, solvers[si], 1);
        S[idx++] = run_solver(&p, &A, b, uEx, r0, &H2, &H3, solvers[si], 4);
    }
    for (int si=0; si<4; ++si) {
        double t1 = S[2*si].solve_seconds, t4 = S[2*si+1].solve_seconds;
        S[2*si].speedup_vs_serial = 1.0;
        S[2*si+1].speedup_vs_serial = (t4 > 0.0 ? t1 / t4 : 0.0);
    }
    print_summary(S, 8);
    print_winners(S, 8);
    if (p.mg33Profile) print_mg33_profiles(S, 8);

    if (p.writeCSV) {
        ensure_dir("csv_benchmarkC_v2_rmtstress");
        char path[512];
        double sval = current_stiff_value(&p);
        const char *sname = stiff_name(p.problem);
        snprintf(path,sizeof(path),"csv_benchmarkC_v2_rmtstress/%s_n%d_%s%.3e_summary.csv",case_name(p.problem),p.n,sname,sval);
        write_summary_csv(path,S,8,&p,&A,sname,sval);
        if (p.writeFields) {
            snprintf(path,sizeof(path),"csv_benchmarkC_v2_rmtstress/%s_n%d_%s%.3e_exact.csv",case_name(p.problem),p.n,sname,sval);
            write_csv_solution(path,&A,NULL,uEx,b,case_name(p.problem),"exact",0,sname,sval);
            for (int i=0;i<8;++i) {
                snprintf(path,sizeof(path),"csv_benchmarkC_v2_rmtstress/%s_n%d_%s%.3e_%s_t%d.csv",case_name(p.problem),p.n,sname,sval,S[i].name,S[i].threads);
                write_csv_solution(path,&A,S[i].x,uEx,b,case_name(p.problem),S[i].name,S[i].threads,sname,sval);
                if (S[i].has_mg33_profile) {
                    snprintf(path,sizeof(path),"csv_benchmarkC_v2_rmtstress/%s_n%d_%s%.3e_%s_t%d_profile.csv",case_name(p.problem),p.n,sname,sval,S[i].name,S[i].threads);
                    write_mg33_profile_csv(path, &S[i]);
                }
            }
        }
        if (globalCsv) append_global_summary(globalCsv,S,8,&p,&A,sname,sval);
        printf("CSV written for this configuration.\n");
    }

    free_summaries(S,8);
    free(uEx); free(b); free(r0v);
    hierarchy_free(&H2); hierarchy_free(&H3); op2d_free(&A);
}

static void run_sweeps(const Params *pBase) {
    ensure_dir("csv_benchmarkC_v2_rmtstress");
    FILE *global = NULL;
    if (pBase->writeCSV) {
        global = fopen("csv_benchmarkC_v2_rmtstress/all_runs_summary.csv", "w");
        if (global) fprintf(global, "problem,stiff_name,stiff_value,n,h,tol,maxIter,sigma,amp,q0,flowAngleDeg,solver,threads,converged,timed_out,iterations,residual_rel,error_inf,error_l2,solve_s_median,solve_s_min,solve_s_max,timing_repeats,speedup\n");
    }

    CaseType cases[2] = {CASE_CONSTFLOW, CASE_ADVANISO};
    int caseStart = 0, caseEnd = 2;
    if (!pBase->runAllCases && pBase->problem != CASE_ALL) {
        caseStart = 0;
        caseEnd   = 1;
        cases[0]  = pBase->problem;
    }

    int totalConfigs = pruned_total_configs(pBase, caseStart, caseEnd, cases);
    int cfg = 0;
    for (int ci=caseStart; ci<caseEnd; ++ci) {
        CaseType c = cases[ci];
        int stiffCount = 1;
        const double *stiffList = NULL;
        if (pBase->peSweep) stiffList = stiff_list_for_case(pBase, c, &stiffCount);
        double oneStiff = 0.0;
        if (!pBase->peSweep) {
            Params tmp = *pBase;
            tmp.problem = c;
            oneStiff = current_stiff_value(&tmp);
        }
        int meshCount = pBase->meshSweep ? pBase->nCount : 1;

        printf("\n============================================================\n");
        printf("Starting case family: %s | mesh sweep=%s | Pe sweep=%s\n", case_name(c), pBase->meshSweep?"on":"off", pBase->peSweep?"on":"off");
        printf("============================================================\n");
        for (int si=0; si<stiffCount; ++si) {
            for (int mi=0; mi<meshCount; ++mi) {
                int nThis = pBase->meshSweep ? pBase->nList[mi] : pBase->n;
                double sval = pBase->peSweep ? stiffList[si] : oneStiff;
                if (!pruned_keep_config(pBase, c, nThis, sval)) continue;
                Params p = *pBase;
                p.problem = c;
                p.runAllCases = 0;
                p.n = nThis;
                set_stiff_value(&p, sval);
                ++cfg;
                printf("\n>>> Configuration %d / %d\n", cfg, totalConfigs);
                run_case_config(&p, global);
            }
        }
    }
    if (global) fclose(global);
    if (pBase->writeCSV) printf("\nGlobal CSV summary written to csv_benchmarkC_v2_rmtstress/all_runs_summary.csv\n");
}

int main(int argc, char **argv) {
    Params p;
    init_params(&p);
    parse_args(argc, argv, &p);
    printf("Compile note: use -fopenmp for 4-core parallel runs.\n");
#ifdef _OPENMP
    printf("OpenMP detected. Max available threads reported by runtime: %d\n", omp_get_max_threads());
#else
    printf("OpenMP not enabled at compile time. Parallel cases will behave like serial.\n");
#endif
    printf("Frozen solver set: gsRB, mg33, rmt3p6, rmt3c4p6\n");
    printf("Benchmark C V2 defaults (harder convection-diffusion families for clearer RMT separation):\n");
    printf("  constFlow : kx=1+amp*sin(2*pi*x), ky=1+amp*cos(2*pi*y)\n");
    printf("  advAniso  : kx=1+amp*sin(2*pi*x), ky=anisoKy*(1+amp*cos(2*pi*y))\n");
    printf("  q0        = %g\n", p.q0);
    printf("  amp       = %g\n", p.amp);
    printf("  anisoKy   = %g (used in advAniso)\n", p.anisoKy);
    printf("  PeRef     = %g\n", p.PeRef);
    printf("  angle     = %g deg\n", p.flowAngleDeg);
    printf("  sigma     = %g\n", p.sigma);
    printf("Mesh sweep: %s\n", p.meshSweep ? "on" : "off");
    if (p.meshSweep) {
        printf("  nList = ");
        for (int i=0;i<p.nCount;++i) printf("%d%s", p.nList[i], (i+1<p.nCount? ",":"\n"));
    } else {
        printf("  single n = %d\n", p.n);
    }
    printf("Pe sweep: %s\n", p.peSweep ? "on" : "off");
    if (p.peSweep) {
        printf("  Pe list = ");
        for (int i=0;i<p.peCount;++i) printf("%g%s", p.peList[i], (i+1<p.peCount? ",":"\n"));
    } else {
        printf("  fixed PeRef = %g\n", p.PeRef);
    }
    printf("Timing repeats per solver: %d (reported solve_s is median; min/max also stored)\n", p.timingRepeats > 0 ? p.timingRepeats : 1);
    printf("MG33 profiling: %s\n", p.mg33Profile ? "on (extra profiled run per thread count)" : "off");
    printf("CSV writing is NOT included in solve time.\n");
    printf("Per-solver wall-time guard: %.1f s (set 0 to disable)\n", p.maxSolveSeconds);
    printf("CSV folder: csv_benchmarkC_v2_rmtstress/\n");
    printf("Design note: V2 drops the tiny easy cases and adds a convection+anisotropy family because V1 was too mild to show practical RMT advantages clearly.\n");
    printf("Note: rmt3c4p6 uses combined coarse 4-sweep smoothing here because the upwind convection operator is nonsymmetric.\n");
    run_sweeps(&p);
    return 0;
}
