#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>

#define OMP_MIN_WORK 6000
#define MAX_SWEEP 16

#ifdef _OPENMP
#include <omp.h>
#endif

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/*
   Benchmark D V2: nonlinear Arrhenius MMS reaction benchmark
   -----------------------------------------------------------
   Frozen solver set (same family used in Benchmarks A-C):
     1) gsRB       : red-black Gauss-Seidel baseline
     2) mg33       : classical geometric MG, pre=3 post=3
     3) rmt3p6     : RMT-style triple-coarsening, post=6
     4) rmt3c4p6   : RMT-style + combined coarse 4-sweep smoothing, post=6

   Runs for each configuration:
     - serial (threads=1)
     - 4-core OpenMP (threads=4)

   Benchmark D V2 model:
      -d/dx( kx(x,y) dT/dx ) - d/dy( ky(x,y) dT/dy )
      + bx dT/dx + by dT/dy + q0 T + Da * A * T^beta * exp(-Ta/T) = f(x,y)

   This is a genuinely nonlinear Arrhenius-type reaction equation.
   The forcing term f(x,y) is manufactured from a prescribed analytical solution.

   Two operator families are provided:
      reactFlow  : smooth variable diffusion + diagonal advection + nonlinear Arrhenius reaction
      reactAniso : same, but with strong y-anisotropy in ky

   Manufactured exact field:
      T_exact(x,y) = Tshift + Tscale * exp(sigmaT*(x+y))

   The forcing term is assembled from the continuous operator so that T_exact is an
   exact analytical solution of the continuous benchmark problem.

   Discretization notes:
      - diffusion is finite-volume flux form
      - advection is first-order upwind for robustness
      - therefore the advective continuous-MMS study has formal global spatial order p=1
      - with PeRef=0, the diffusion-reaction continuous-MMS study isolates the second-order spatial discretization (p=2)
      - Dirichlet boundary values are imposed from the analytical solution
      - nonlinearity is solved by Picard / fixed-point outer iterations
      - each outer iteration applies one chosen linear solver update to the linearized subproblem

   CSV outputs:
     csv_benchmarkD_v2_arrhenius_mms/
       - all_runs_summary.csv
       - one summary CSV per (case, n, stiff)
       - one exact CSV per (case, n, stiff)
       - one field CSV per (case, n, stiff, solver, threads)

   Compile:
     gcc -O2 -std=c11 -fopenmp benchmarkD_v2_arrhenius_mms_parallel_csv.c -lm -o benchmarkD_v2_arrhenius_mms_parallel_csv

   Run defaults:
     ./benchmarkD_v2_arrhenius_mms_parallel_csv

   Run one fixed configuration only:
     ./benchmarkD_v2_arrhenius_mms_parallel_csv -case reactAniso -meshSweep 0 -stiffSweep 0 -n 107 -reactRef 1e3

   Custom mesh list:
     ./benchmarkD_v2_arrhenius_mms_parallel_csv -nList 53,107,215

   Optional stiffness sweep:
     ./benchmarkD_v2_arrhenius_mms_parallel_csv -stiffSweep 1 -reactList 1e2,1e3,1e4
*/


/* TRUBA/Ubuntu rerun package update (2026-09):
   -writeFields 0 suppresses large exact/field CSV files while retaining summary CSVs.
   This changes output control only; numerical operators and solver algorithms are unchanged.
*/
#define ID(i,j,nx) ((size_t)(i) + (size_t)(nx) * (size_t)(j))

typedef enum {
    CASE_REACTFLOW = 0,
    CASE_REACTANISO = 1,
    CASE_ALL = 2
} CaseType;

typedef struct {
    int n;
    double h;
    double *aP, *aE, *aW, *aN, *aS;
    double *kxCell, *kyCell, *qCell;
    double *bxCell, *byCell, *peCell;
} Op2D;

typedef struct {
    int n;
    double h;
    double tol;
    int maxIter;
    int verbose;
    int writeCSV;
    int writeFields; /* write exact/field CSVs; summaries still controlled by writeCSV */
    int runAllCases;
    int coarseExactN;
    double omegaEuler;

    double sigmaT;
    double Tshift;
    double Tscale;
    double TminClamp;

    double q0;
    double amp;
    double anisoKy;
    double PeRef;
    double flowAngleDeg;

    double reactRef;
    double arrA;
    double arrBeta;
    double arrTa;
    double picardRelax;

    CaseType problem;
    int meshSweep;
    int stiffSweep;
    int nList[MAX_SWEEP];
    int nCount;
    double reactList[MAX_SWEEP];
    int reactCount;
    double maxSolveSeconds;
    int timingRepeats;
    int fairLeafMaxN;
    int includeUnfairMeshes;
    int verificationMode; /* if 1, run one solver/thread only for mesh-order verification */
    int verificationSolver; /* 0=gsRB,1=mg33,2=rmt3p6,3=rmt3c4p6 */
    int verificationThreads;
} Params;

typedef enum {
    SOLVER_GS = 0,
    SOLVER_MG33,
    SOLVER_RMT3P6,
    SOLVER_RMT3C4P6
} SolverType;

typedef struct {
    const char *name;
    int threads;
    int converged;
    int iterations;
    double residual_rel;
    double error_inf;
    double error_l2;
    double solve_seconds;
    double solve_seconds_min;
    double solve_seconds_max;
    int timing_repeats;
    double speedup_vs_serial;
    int timed_out;
    double *x;
} Summary;

typedef struct {
    int nLevels;
    int stride;
    Op2D *A;
    size_t *N;
    double **r;
    double **bc;
    double **ec;
    double **ef;
} MGHierarchy;

static double now_seconds(void) {
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (double)ts.tv_sec + 1.0e-9 * (double)ts.tv_nsec;
}

static void *xcalloc(size_t n, size_t sz, const char *what) {
    void *p = calloc(n, sz);
    if (!p) {
        fprintf(stderr, "FATAL: allocation failed for %s\n", what);
        exit(1);
    }
    return p;
}

static int ensure_dir(const char *path) {
    if (mkdir(path, 0777) == 0) return 0;
    if (errno == EEXIST) return 0;
    return -1;
}

static int cmp_double_asc(const void *a, const void *b) {
    const double da = *(const double*)a;
    const double db = *(const double*)b;
    return (da > db) - (da < db);
}

static double median_of(double *vals, int n) {
    if (n <= 0) return 0.0;
    qsort(vals, (size_t)n, sizeof(double), cmp_double_asc);
    if (n & 1) return vals[n/2];
    return 0.5 * (vals[n/2 - 1] + vals[n/2]);
}

static const char *case_name(CaseType c) {
    switch (c) {
        case CASE_REACTFLOW: return "reactFlow";
        case CASE_REACTANISO: return "reactAniso";
        case CASE_ALL: return "all";
        default: return "unknown";
    }
}

static const char *stiff_name(CaseType c) {
    (void)c;
    return "react";
}

static const char *solver_name(SolverType s) {
    switch (s) {
        case SOLVER_GS:       return "gsRB";
        case SOLVER_MG33:     return "mg33";
        case SOLVER_RMT3P6:   return "rmt3p6";
        case SOLVER_RMT3C4P6: return "rmt3c4p6";
        default: return "unknown";
    }
}

static int parse_int_list(const char *txt, int *out, int maxn) {
    char buf[512];
    strncpy(buf, txt, sizeof(buf)-1);
    buf[sizeof(buf)-1] = '\0';
    int cnt = 0;
    char *tok = strtok(buf, ",");
    while (tok && cnt < maxn) {
        out[cnt++] = atoi(tok);
        tok = strtok(NULL, ",");
    }
    return cnt;
}

static int parse_double_list(const char *txt, double *out, int maxn) {
    char buf[512];
    strncpy(buf, txt, sizeof(buf)-1);
    buf[sizeof(buf)-1] = '\0';
    int cnt = 0;
    char *tok = strtok(buf, ",");
    while (tok && cnt < maxn) {
        out[cnt++] = atof(tok);
        tok = strtok(NULL, ",");
    }
    return cnt;
}

static double exact_func(double x, double y, const Params *p) {
    return p->Tshift + p->Tscale * exp(p->sigmaT * (x + y));
}

static double exact_dx(double x, double y, const Params *p) {
    (void)x; (void)y;
    return p->Tscale * p->sigmaT * exp(p->sigmaT * (x + y));
}

static double exact_dy(double x, double y, const Params *p) {
    return exact_dx(x, y, p);
}

static double exact_dxx(double x, double y, const Params *p) {
    return p->Tscale * p->sigmaT * p->sigmaT * exp(p->sigmaT * (x + y));
}

static double exact_dyy(double x, double y, const Params *p) {
    return exact_dxx(x, y, p);
}

static double kx_case(const Params *p, CaseType c, double x, double y) {
    (void)c; (void)y;
    return 1.0 + p->amp * sin(2.0 * M_PI * x);
}

static double ky_case(const Params *p, CaseType c, double x, double y) {
    (void)x;
    if (c == CASE_REACTANISO) return p->anisoKy * (1.0 + p->amp * cos(2.0 * M_PI * y));
    return 1.0 + p->amp * cos(2.0 * M_PI * y);
}

static double dkx_dx_case(const Params *p, CaseType c, double x, double y) {
    (void)c; (void)y;
    return 2.0 * M_PI * p->amp * cos(2.0 * M_PI * x);
}

static double dky_dy_case(const Params *p, CaseType c, double x, double y) {
    (void)x;
    if (c == CASE_REACTANISO) return -2.0 * M_PI * p->anisoKy * p->amp * sin(2.0 * M_PI * y);
    return -2.0 * M_PI * p->amp * sin(2.0 * M_PI * y);
}

static double q_case(const Params *p, CaseType c, double x, double y) {
    (void)c; (void)x; (void)y;
    return p->q0;
}

static void advection_components(const Params *p, double *bx, double *by) {
    const double ang = p->flowAngleDeg * (M_PI / 180.0);
    *bx = p->PeRef * cos(ang);
    *by = p->PeRef * sin(ang);
}

static double bx_case(const Params *p, CaseType c, double x, double y) {
    (void)c; (void)x; (void)y;
    double bx = 0.0, by = 0.0;
    advection_components(p, &bx, &by);
    return bx;
}

static double by_case(const Params *p, CaseType c, double x, double y) {
    (void)c; (void)x; (void)y;
    double bx = 0.0, by = 0.0;
    advection_components(p, &bx, &by);
    return by;
}

static double arrhenius_rate_eval(const Params *p, double T) {
    if (T < p->TminClamp) T = p->TminClamp;
    if (T <= 0.0) T = p->TminClamp;
    double logTerm = -p->arrTa / T;
    if (logTerm < -700.0) return 0.0;
    if (logTerm > 700.0) logTerm = 700.0;
    double powTerm = 1.0;
    if (fabs(p->arrBeta) > 0.0) powTerm = pow(T, p->arrBeta);
    return p->arrA * powTerm * exp(logTerm);
}

static void op2d_alloc(Op2D *A, int n) {
    const size_t N = (size_t)n * (size_t)n;
    A->n = n;
    A->h = 1.0 / (double)(n + 1);
    A->aP = (double*)xcalloc(N, sizeof(double), "aP");
    A->aE = (double*)xcalloc(N, sizeof(double), "aE");
    A->aW = (double*)xcalloc(N, sizeof(double), "aW");
    A->aN = (double*)xcalloc(N, sizeof(double), "aN");
    A->aS = (double*)xcalloc(N, sizeof(double), "aS");
    A->kxCell = (double*)xcalloc(N, sizeof(double), "kxCell");
    A->kyCell = (double*)xcalloc(N, sizeof(double), "kyCell");
    A->qCell  = (double*)xcalloc(N, sizeof(double), "qCell");
    A->bxCell = (double*)xcalloc(N, sizeof(double), "bxCell");
    A->byCell = (double*)xcalloc(N, sizeof(double), "byCell");
    A->peCell = (double*)xcalloc(N, sizeof(double), "peCell");
}

static void op2d_free(Op2D *A) {
    free(A->aP); free(A->aE); free(A->aW); free(A->aN); free(A->aS);
    free(A->kxCell); free(A->kyCell); free(A->qCell);
    free(A->bxCell); free(A->byCell); free(A->peCell);
    memset(A, 0, sizeof(*A));
}

static void build_operator(Op2D *A, const Params *p, int n, CaseType c) {
    op2d_alloc(A, n);
    const double h = A->h;
    const double h2 = h * h;
    for (int j = 0; j < n; ++j) {
        for (int i = 0; i < n; ++i) {
            const double x = (double)(i + 1) * h;
            const double y = (double)(j + 1) * h;
            const double ke = kx_case(p, c, x + 0.5*h, y) / h2;
            const double kw = kx_case(p, c, x - 0.5*h, y) / h2;
            const double kn = ky_case(p, c, x, y + 0.5*h) / h2;
            const double ks = ky_case(p, c, x, y - 0.5*h) / h2;
            const double qv = q_case(p, c, x, y);
            const double bx = bx_case(p, c, x, y);
            const double by = by_case(p, c, x, y);

            const double aEadv = (bx < 0.0) ? (-bx) / h : 0.0;
            const double aWadv = (bx > 0.0) ? ( bx) / h : 0.0;
            const double aNadv = (by < 0.0) ? (-by) / h : 0.0;
            const double aSadv = (by > 0.0) ? ( by) / h : 0.0;

            const double aE = ke + aEadv;
            const double aW = kw + aWadv;
            const double aN = kn + aNadv;
            const double aS = ks + aSadv;

            const size_t idx = ID(i,j,n);
            A->aE[idx] = aE;
            A->aW[idx] = aW;
            A->aN[idx] = aN;
            A->aS[idx] = aS;
            A->aP[idx] = aE + aW + aN + aS + qv;
            A->kxCell[idx] = kx_case(p, c, x, y);
            A->kyCell[idx] = ky_case(p, c, x, y);
            A->qCell[idx]  = qv;
            A->bxCell[idx] = bx;
            A->byCell[idx] = by;
            {
                const double km = 0.5 * (A->kxCell[idx] + A->kyCell[idx]);
                const double bmag = sqrt(bx*bx + by*by);
                A->peCell[idx] = (km > 0.0) ? (bmag * h / (2.0 * km)) : 0.0;
            }
        }
    }
}

static void build_exact_field(const Op2D *A, const Params *p, double *xEx) {
    const int n = A->n;
    const double h = A->h;
    #pragma omp parallel for collapse(2) schedule(static) if(((size_t)n*(size_t)n) >= OMP_MIN_WORK)
    for (int j = 0; j < n; ++j)
        for (int i = 0; i < n; ++i) {
            const double x = (double)(i + 1) * h;
            const double y = (double)(j + 1) * h;
            xEx[ID(i,j,n)] = exact_func(x, y, p);
        }
}

static void build_boundary_rhs(const Op2D *A, const Params *p, double *bBc) {
    const int n = A->n;
    const double h = A->h;
    #pragma omp parallel for collapse(2) schedule(static) if(((size_t)n*(size_t)n) >= OMP_MIN_WORK)
    for (int j = 0; j < n; ++j) {
        for (int i = 0; i < n; ++i) {
            const size_t idx = ID(i,j,n);
            const double x = (double)(i + 1) * h;
            const double y = (double)(j + 1) * h;
            double rhs = 0.0;
            if (i == 0)     rhs += A->aW[idx] * exact_func(0.0, y, p);
            if (i == n-1)   rhs += A->aE[idx] * exact_func(1.0, y, p);
            if (j == 0)     rhs += A->aS[idx] * exact_func(x, 0.0, p);
            if (j == n-1)   rhs += A->aN[idx] * exact_func(x, 1.0, p);
            bBc[idx] = rhs;
        }
    }
}

static double forcing_continuous(const Params *p, CaseType c, double x, double y) {
    const double T = exact_func(x, y, p);
    const double Tx = exact_dx(x, y, p);
    const double Ty = exact_dy(x, y, p);
    const double Txx = exact_dxx(x, y, p);
    const double Tyy = exact_dyy(x, y, p);
    const double kx = kx_case(p, c, x, y);
    const double ky = ky_case(p, c, x, y);
    const double kxx = dkx_dx_case(p, c, x, y);
    const double kyy = dky_dy_case(p, c, x, y);
    const double bx = bx_case(p, c, x, y);
    const double by = by_case(p, c, x, y);
    const double qv = q_case(p, c, x, y);
    const double reaction = p->reactRef * arrhenius_rate_eval(p, T);
    return -(kxx * Tx + kx * Txx) - (kyy * Ty + ky * Tyy) + bx * Tx + by * Ty + qv * T + reaction;
}

static void build_forcing_field(const Op2D *A, const Params *p, CaseType c, double *f) {
    const int n = A->n;
    const double h = A->h;
    #pragma omp parallel for collapse(2) schedule(static) if(((size_t)n*(size_t)n) >= OMP_MIN_WORK)
    for (int j = 0; j < n; ++j) {
        for (int i = 0; i < n; ++i) {
            const double x = (double)(i + 1) * h;
            const double y = (double)(j + 1) * h;
            f[ID(i,j,n)] = forcing_continuous(p, c, x, y);
        }
    }
}

static void build_rhs_linear(const Op2D *A, const double *f, const double *bBc, double *bLin) {
    const size_t N = (size_t)A->n * (size_t)A->n;
    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t q = 0; q < N; ++q) bLin[q] = f[q] + bBc[q];
}

static void apply_A(const Op2D *A, const double *x, double *y) {
    const int n = A->n;
    #pragma omp parallel for collapse(2) schedule(static) if(((size_t)n*(size_t)n) >= OMP_MIN_WORK)
    for (int j = 0; j < n; ++j) {
        for (int i = 0; i < n; ++i) {
            const size_t p = ID(i,j,n);
            double v = A->aP[p] * x[p];
            if (i + 1 < n) v -= A->aE[p] * x[ID(i+1,j,n)];
            if (i > 0)     v -= A->aW[p] * x[ID(i-1,j,n)];
            if (j + 1 < n) v -= A->aN[p] * x[ID(i,j+1,n)];
            if (j > 0)     v -= A->aS[p] * x[ID(i,j-1,n)];
            y[p] = v;
        }
    }
}

static void compute_residual_scalar_linear(const Op2D *A, const double *x, const double *b, double *r) {
    apply_A(A, x, r);
    const size_t N = (size_t)A->n * (size_t)A->n;
    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t p = 0; p < N; ++p) r[p] = b[p] - r[p];
}

static void compute_residual_nonlinear(const Op2D *A, const Params *p,
                                       const double *x, const double *bLinear, double *r) {
    apply_A(A, x, r);
    const size_t N = (size_t)A->n * (size_t)A->n;
    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t q = 0; q < N; ++q) {
        const double reaction = p->reactRef * arrhenius_rate_eval(p, x[q]);
        r[q] = bLinear[q] - r[q] - reaction;
    }
}

static double l2_norm(const double *x, size_t N) {
    double s = 0.0;
    #pragma omp parallel for reduction(+:s) schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t i = 0; i < N; ++i) s += x[i] * x[i];
    return sqrt(s / (double)(N > 0 ? N : 1));
}

static double linf_error(const double *x, const double *xEx, size_t N) {
    double m = 0.0;
    #pragma omp parallel for reduction(max:m) schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t i = 0; i < N; ++i) {
        double e = fabs(x[i] - xEx[i]);
        if (e > m) m = e;
    }
    return m;
}

static double l2_error(const double *x, const double *xEx, size_t N) {
    double s = 0.0;
    #pragma omp parallel for reduction(+:s) schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t i = 0; i < N; ++i) {
        double e = x[i] - xEx[i];
        s += e * e;
    }
    return sqrt(s / (double)(N > 0 ? N : 1));
}

static void rbgs_sweep(const Op2D *A, double *x, const double *b) {
    const int n = A->n;
    for (int color = 0; color < 2; ++color) {
        #pragma omp parallel for collapse(2) schedule(static) if(((size_t)n*(size_t)n) >= OMP_MIN_WORK)
        for (int j = 0; j < n; ++j) {
            for (int i = 0; i < n; ++i) {
                if (((i + j) & 1) != color) continue;
                const size_t p = ID(i,j,n);
                double rhs = b[p];
                if (i + 1 < n) rhs += A->aE[p] * x[ID(i+1,j,n)];
                if (i > 0)     rhs += A->aW[p] * x[ID(i-1,j,n)];
                if (j + 1 < n) rhs += A->aN[p] * x[ID(i,j+1,n)];
                if (j > 0)     rhs += A->aS[p] * x[ID(i,j-1,n)];
                x[p] = rhs / A->aP[p];
            }
        }
    }
}

static void rbgs_fixed_sweeps(const Op2D *A, double *x, const double *b, int sweeps) {
    for (int s = 0; s < sweeps; ++s) rbgs_sweep(A, x, b);
}

static void jacobi_step(const Op2D *A, double *x, const double *b, double omega, double *rbuf) {
    compute_residual_scalar_linear(A, x, b, rbuf);
    const size_t N = (size_t)A->n * (size_t)A->n;
    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t p = 0; p < N; ++p) x[p] += omega * rbuf[p] / A->aP[p];
}

static void exact_solve_dense(const Op2D *A, const double *b, double *x) {
    const int n = A->n;
    const int N = n*n;
    double *M = (double*)xcalloc((size_t)N * (size_t)N, sizeof(double), "dense matrix");
    double *rhs = (double*)xcalloc((size_t)N, sizeof(double), "dense rhs");
    for (int j=0;j<n;++j) for (int i=0;i<n;++i) {
        int row = i + n*j;
        size_t p = ID(i,j,n);
        M[(size_t)row*(size_t)N + (size_t)row] = A->aP[p];
        if (i + 1 < n) M[(size_t)row*(size_t)N + (size_t)(row+1)] = -A->aE[p];
        if (i > 0)     M[(size_t)row*(size_t)N + (size_t)(row-1)] = -A->aW[p];
        if (j + 1 < n) M[(size_t)row*(size_t)N + (size_t)(row+n)] = -A->aN[p];
        if (j > 0)     M[(size_t)row*(size_t)N + (size_t)(row-n)] = -A->aS[p];
        rhs[row] = b[p];
    }
    for (int k=0;k<N;++k) {
        int piv = k;
        double amax = fabs(M[(size_t)k*(size_t)N + (size_t)k]);
        for (int i=k+1;i<N;++i) {
            double av = fabs(M[(size_t)i*(size_t)N + (size_t)k]);
            if (av > amax) { amax = av; piv = i; }
        }
        if (amax < 1e-30) {
            fprintf(stderr, "FATAL: singular coarse matrix\n");
            exit(1);
        }
        if (piv != k) {
            for (int jcol=k;jcol<N;++jcol) {
                double tmp = M[(size_t)k*(size_t)N + (size_t)jcol];
                M[(size_t)k*(size_t)N + (size_t)jcol] = M[(size_t)piv*(size_t)N + (size_t)jcol];
                M[(size_t)piv*(size_t)N + (size_t)jcol] = tmp;
            }
            double tr = rhs[k];
            rhs[k] = rhs[piv];
            rhs[piv] = tr;
        }
        double diag = M[(size_t)k*(size_t)N + (size_t)k];
        for (int i=k+1;i<N;++i) {
            double f = M[(size_t)i*(size_t)N + (size_t)k] / diag;
            M[(size_t)i*(size_t)N + (size_t)k] = 0.0;
            if (f == 0.0) continue;
            for (int jcol=k+1;jcol<N;++jcol)
                M[(size_t)i*(size_t)N + (size_t)jcol] -= f * M[(size_t)k*(size_t)N + (size_t)jcol];
            rhs[i] -= f * rhs[k];
        }
    }
    for (int i=N-1;i>=0;--i) {
        double s = rhs[i];
        for (int jcol=i+1;jcol<N;++jcol)
            s -= M[(size_t)i*(size_t)N + (size_t)jcol] * x[jcol];
        x[i] = s / M[(size_t)i*(size_t)N + (size_t)i];
    }
    free(M);
    free(rhs);
}

static int can_coarsen_2h(int n) { return ((n + 1) % 2) == 0 && (((n + 1) / 2) - 1) >= 1; }
static int coarse_n_2h(int n) { return ((n + 1) / 2) - 1; }
static int can_coarsen_3h(int n) { return ((n + 1) % 3) == 0 && (((n + 1) / 3) - 1) >= 1; }
static int coarse_n_3h(int n) { return ((n + 1) / 3) - 1; }

static void restrict_fw_2h(const double *rf, int nf, double *rc, int nc) {
    #pragma omp parallel for collapse(2) schedule(static) if(((size_t)nc*(size_t)nc) >= OMP_MIN_WORK)
    for (int J=0;J<nc;++J) for (int I=0;I<nc;++I) {
        int jf = 2*(J+1)-1, ifi = 2*(I+1)-1;
        double s = 0.0;
        s += 4.0*rf[ID(ifi,jf,nf)];
        if (ifi>0)    s += 2.0*rf[ID(ifi-1,jf,nf)];
        if (ifi+1<nf) s += 2.0*rf[ID(ifi+1,jf,nf)];
        if (jf>0)     s += 2.0*rf[ID(ifi,jf-1,nf)];
        if (jf+1<nf)  s += 2.0*rf[ID(ifi,jf+1,nf)];
        if (ifi>0 && jf>0)       s += rf[ID(ifi-1,jf-1,nf)];
        if (ifi>0 && jf+1<nf)    s += rf[ID(ifi-1,jf+1,nf)];
        if (ifi+1<nf && jf>0)    s += rf[ID(ifi+1,jf-1,nf)];
        if (ifi+1<nf && jf+1<nf) s += rf[ID(ifi+1,jf+1,nf)];
        rc[ID(I,J,nc)] = s/16.0;
    }
}

static inline double coarse_ext_value(const double *ec, int nc, int I, int J) {
    if (I < 1 || I > nc || J < 1 || J > nc) return 0.0;
    return ec[ID(I-1,J-1,nc)];
}

static void prolong_bilinear_noalloc(const double *ec, int nc, double *ef, int nf) {
    #pragma omp parallel for collapse(2) schedule(static) if(((size_t)nf*(size_t)nf) >= OMP_MIN_WORK)
    for (int j=0;j<nf;++j) for (int i=0;i<nf;++i) {
        double y = (double)(j+1)/(double)(nf+1), sc = y*(double)(nc+1);
        int J0=(int)floor(sc); if(J0<0)J0=0; if(J0>nc)J0=nc; double ty=sc-(double)J0; int J1=J0+1;
        double x = (double)(i+1)/(double)(nf+1), tc = x*(double)(nc+1);
        int I0=(int)floor(tc); if(I0<0)I0=0; if(I0>nc)I0=nc; double tx=tc-(double)I0; int I1=I0+1;
        double c00=coarse_ext_value(ec,nc,I0,J0), c10=coarse_ext_value(ec,nc,I1,J0), c01=coarse_ext_value(ec,nc,I0,J1), c11=coarse_ext_value(ec,nc,I1,J1);
        ef[ID(i,j,nf)] = (1.0-tx)*(1.0-ty)*c00 + tx*(1.0-ty)*c10 + (1.0-tx)*ty*c01 + tx*ty*c11;
    }
}

static void restrict_avg_3h(const double *rf, int nf, double *rc, int nc) {
    #pragma omp parallel for collapse(2) schedule(static) if(((size_t)nc*(size_t)nc) >= OMP_MIN_WORK)
    for (int J=0;J<nc;++J) for (int I=0;I<nc;++I) {
        int jf = 3*(J+1)-1, ifi = 3*(I+1)-1;
        double s = 0.0;
        int cnt = 0;
        for (int dj=-1;dj<=1;++dj) {
            int jj = jf + dj;
            if (jj<0 || jj>=nf) continue;
            for (int di=-1;di<=1;++di) {
                int ii = ifi + di;
                if (ii<0 || ii>=nf) continue;
                s += rf[ID(ii,jj,nf)];
                ++cnt;
            }
        }
        rc[ID(I,J,nc)] = (cnt>0 ? s/(double)cnt : 0.0);
    }
}

static int hierarchy_next_n(int n, int stride) {
    return (stride == 2) ? coarse_n_2h(n) : coarse_n_3h(n);
}

static int hierarchy_can_coarsen(int n, int stride) {
    return (stride == 2) ? can_coarsen_2h(n) : can_coarsen_3h(n);
}

static void hierarchy_build(MGHierarchy *H, const Params *p, int nFine, CaseType c, int stride) {
    memset(H, 0, sizeof(*H));
    H->stride = stride;
    int nLevels = 1;
    int ncur = nFine;
    while (ncur > p->coarseExactN && hierarchy_can_coarsen(ncur, stride)) {
        ncur = hierarchy_next_n(ncur, stride);
        ++nLevels;
    }
    H->nLevels = nLevels;
    H->A  = (Op2D*)xcalloc((size_t)nLevels, sizeof(Op2D), "hier A");
    H->N  = (size_t*)xcalloc((size_t)nLevels, sizeof(size_t), "hier N");
    H->r  = (double**)xcalloc((size_t)nLevels, sizeof(double*), "hier r");
    H->bc = (double**)xcalloc((size_t)nLevels, sizeof(double*), "hier bc");
    H->ec = (double**)xcalloc((size_t)nLevels, sizeof(double*), "hier ec");
    H->ef = (double**)xcalloc((size_t)nLevels, sizeof(double*), "hier ef");

    ncur = nFine;
    for (int l = 0; l < nLevels; ++l) {
        build_operator(&H->A[l], p, ncur, c);
        H->N[l] = (size_t)ncur * (size_t)ncur;
        if (l + 1 < nLevels) {
            int nc = hierarchy_next_n(ncur, stride);
            size_t Nc = (size_t)nc * (size_t)nc;
            H->r[l]  = (double*)xcalloc(H->N[l], sizeof(double), "hier r level");
            H->bc[l] = (double*)xcalloc(Nc, sizeof(double), "hier bc level");
            H->ec[l] = (double*)xcalloc(Nc, sizeof(double), "hier ec level");
            H->ef[l] = (double*)xcalloc(H->N[l], sizeof(double), "hier ef level");
            ncur = nc;
        }
    }
}

static void hierarchy_free(MGHierarchy *H) {
    if (!H) return;
    for (int l = 0; l < H->nLevels; ++l) {
        op2d_free(&H->A[l]);
        free(H->r[l]);
        free(H->bc[l]);
        free(H->ec[l]);
        free(H->ef[l]);
    }
    free(H->A); free(H->N); free(H->r); free(H->bc); free(H->ec); free(H->ef);
    memset(H, 0, sizeof(*H));
}

static void mg33_vcycle_cached(const Params *p, const MGHierarchy *H, int level, double *x, const double *b) {
    const Op2D *A = &H->A[level];
    const size_t N = H->N[level];
    if (level == H->nLevels - 1 || A->n <= p->coarseExactN) {
        exact_solve_dense(A, b, x);
        return;
    }
    rbgs_fixed_sweeps(A, x, b, 3);
    compute_residual_scalar_linear(A, x, b, H->r[level]);
    restrict_fw_2h(H->r[level], A->n, H->bc[level], H->A[level+1].n);
    memset(H->ec[level], 0, ((size_t)H->A[level+1].n * (size_t)H->A[level+1].n) * sizeof(double));
    mg33_vcycle_cached(p, H, level + 1, H->ec[level], H->bc[level]);
    prolong_bilinear_noalloc(H->ec[level], H->A[level+1].n, H->ef[level], A->n);
    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t q=0;q<N;++q) x[q] += H->ef[level][q];
    rbgs_fixed_sweeps(A, x, b, 3);
}

static void rmt3p6_cycle_cached(const Params *p, const MGHierarchy *H, int level, double *x, const double *b) {
    const Op2D *A = &H->A[level];
    const size_t N = H->N[level];
    if (level == H->nLevels - 1 || A->n <= p->coarseExactN) {
        exact_solve_dense(A, b, x);
        return;
    }
    compute_residual_scalar_linear(A, x, b, H->r[level]);
    restrict_avg_3h(H->r[level], A->n, H->bc[level], H->A[level+1].n);
    memset(H->ec[level], 0, ((size_t)H->A[level+1].n * (size_t)H->A[level+1].n) * sizeof(double));
    rmt3p6_cycle_cached(p, H, level + 1, H->ec[level], H->bc[level]);
    prolong_bilinear_noalloc(H->ec[level], H->A[level+1].n, H->ef[level], A->n);
    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t q=0;q<N;++q) x[q] += H->ef[level][q];
    rbgs_fixed_sweeps(A, x, b, 6);
}

static void rmt3c4p6_cycle_cached(const Params *p, const MGHierarchy *H, int level, double *x, const double *b) {
    const Op2D *A = &H->A[level];
    const size_t N = H->N[level];
    if (level == H->nLevels - 1 || A->n <= p->coarseExactN) {
        exact_solve_dense(A, b, x);
        return;
    }
    compute_residual_scalar_linear(A, x, b, H->r[level]);
    restrict_avg_3h(H->r[level], A->n, H->bc[level], H->A[level+1].n);
    memset(H->ec[level], 0, ((size_t)H->A[level+1].n * (size_t)H->A[level+1].n) * sizeof(double));
    rmt3c4p6_cycle_cached(p, H, level + 1, H->ec[level], H->bc[level]);
    if (level > 0) rbgs_fixed_sweeps(&H->A[level+1], H->ec[level], H->bc[level], 4);
    prolong_bilinear_noalloc(H->ec[level], H->A[level+1].n, H->ef[level], A->n);
    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t q=0;q<N;++q) x[q] += H->ef[level][q];
    if (level == 0) rbgs_fixed_sweeps(A, x, b, 6); else rbgs_fixed_sweeps(A, x, b, 4);
}

static void init_params(Params *p) {
    memset(p, 0, sizeof(*p));
    p->n = 215;
    p->tol = 1e-8;
    p->maxIter = 600;
    p->verbose = 0;
    p->writeCSV = 1; p->writeFields = 1;
    p->runAllCases = 1;
    p->coarseExactN = 5;
    p->omegaEuler = 0.15;

    p->sigmaT = 1.20;
    p->Tshift = 1.20;
    p->Tscale = 0.12;
    p->TminClamp = 0.25;

    p->q0 = 1.0;
    p->amp = 0.75;
    p->anisoKy = 0.03;
    p->PeRef = 800.0;
    p->flowAngleDeg = 30.0;

    p->reactRef = 1.0e3;
    p->arrA = 1.0;
    p->arrBeta = 1.0;
    p->arrTa = 6.0;
    p->picardRelax = 0.60;

    p->problem = CASE_REACTFLOW;
    p->meshSweep = 1;
    p->stiffSweep = 1;
    p->nList[0] = 53; p->nList[1] = 107; p->nList[2] = 215; p->nCount = 3;
    p->reactList[0] = 1.0e2; p->reactList[1] = 1.0e3; p->reactList[2] = 1.0e4; p->reactCount = 3;
    p->maxSolveSeconds = 30.0;
    p->timingRepeats = 3;
    p->fairLeafMaxN = 32;
    p->includeUnfairMeshes = 0;
    p->verificationMode = 0;
    p->verificationSolver = 1;
    p->verificationThreads = 1;
}

static void parse_args(int argc, char **argv, Params *p) {
    for (int i=1;i<argc;++i) {
        if (!strcmp(argv[i], "-n") && i+1<argc) p->n = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-tol") && i+1<argc) p->tol = atof(argv[++i]);
        else if (!strcmp(argv[i], "-maxIter") && i+1<argc) p->maxIter = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-verbose") && i+1<argc) p->verbose = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-writeCSV") && i+1<argc) p->writeCSV = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-writeFields") && i+1<argc) p->writeFields = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-coarseExactN") && i+1<argc) p->coarseExactN = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-sigmaT") && i+1<argc) p->sigmaT = atof(argv[++i]);
        else if (!strcmp(argv[i], "-Tshift") && i+1<argc) p->Tshift = atof(argv[++i]);
        else if (!strcmp(argv[i], "-Tscale") && i+1<argc) p->Tscale = atof(argv[++i]);
        else if (!strcmp(argv[i], "-TminClamp") && i+1<argc) p->TminClamp = atof(argv[++i]);
        else if (!strcmp(argv[i], "-q0") && i+1<argc) p->q0 = atof(argv[++i]);
        else if (!strcmp(argv[i], "-amp") && i+1<argc) p->amp = atof(argv[++i]);
        else if (!strcmp(argv[i], "-anisoKy") && i+1<argc) p->anisoKy = atof(argv[++i]);
        else if (!strcmp(argv[i], "-PeRef") && i+1<argc) p->PeRef = atof(argv[++i]);
        else if (!strcmp(argv[i], "-flowAngleDeg") && i+1<argc) p->flowAngleDeg = atof(argv[++i]);
        else if (!strcmp(argv[i], "-reactRef") && i+1<argc) p->reactRef = atof(argv[++i]);
        else if (!strcmp(argv[i], "-arrA") && i+1<argc) p->arrA = atof(argv[++i]);
        else if (!strcmp(argv[i], "-arrBeta") && i+1<argc) p->arrBeta = atof(argv[++i]);
        else if (!strcmp(argv[i], "-arrTa") && i+1<argc) p->arrTa = atof(argv[++i]);
        else if (!strcmp(argv[i], "-picardRelax") && i+1<argc) p->picardRelax = atof(argv[++i]);
        else if (!strcmp(argv[i], "-meshSweep") && i+1<argc) p->meshSweep = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-stiffSweep") && i+1<argc) p->stiffSweep = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-nList") && i+1<argc) p->nCount = parse_int_list(argv[++i], p->nList, MAX_SWEEP);
        else if (!strcmp(argv[i], "-reactList") && i+1<argc) p->reactCount = parse_double_list(argv[++i], p->reactList, MAX_SWEEP);
        else if (!strcmp(argv[i], "-maxSolveSeconds") && i+1<argc) p->maxSolveSeconds = atof(argv[++i]);
        else if (!strcmp(argv[i], "-timingRepeats") && i+1<argc) p->timingRepeats = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-fairLeafMaxN") && i+1<argc) p->fairLeafMaxN = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-includeUnfairMeshes") && i+1<argc) p->includeUnfairMeshes = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-verificationMode") && i+1<argc) p->verificationMode = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-verificationThreads") && i+1<argc) p->verificationThreads = atoi(argv[++i]);
        else if (!strcmp(argv[i], "-verificationSolver") && i+1<argc) {
            ++i;
            if (!strcmp(argv[i], "gsRB")) p->verificationSolver = 0;
            else if (!strcmp(argv[i], "mg33")) p->verificationSolver = 1;
            else if (!strcmp(argv[i], "rmt3p6")) p->verificationSolver = 2;
            else if (!strcmp(argv[i], "rmt3c4p6")) p->verificationSolver = 3;
            else { fprintf(stderr, "unknown verification solver '%s'\n", argv[i]); exit(1); }
        }
        else if (!strcmp(argv[i], "-case") && i+1<argc) {
            ++i;
            p->runAllCases = 0;
            if (!strcmp(argv[i], "reactFlow")) p->problem = CASE_REACTFLOW;
            else if (!strcmp(argv[i], "reactAniso")) p->problem = CASE_REACTANISO;
            else if (!strcmp(argv[i], "all")) { p->problem = CASE_ALL; p->runAllCases = 1; }
            else { fprintf(stderr, "unknown case '%s'\n", argv[i]); exit(1); }
        }
    }
}

static void set_threads(int nthreads) {
#ifdef _OPENMP
    omp_set_dynamic(0);
    omp_set_num_threads(nthreads);
#else
    (void)nthreads;
#endif
}

static void apply_scalar_iteration(const Params *p, const Op2D *A, SolverType solver,
                                   const MGHierarchy *H2, const MGHierarchy *H3,
                                   double *x, const double *b, double *jbuf) {
    if (solver == SOLVER_GS) {
        rbgs_sweep(A, x, b);
        if (jbuf && p->omegaEuler > 0.0) jacobi_step(A, x, b, 0.05 * p->omegaEuler, jbuf);
    } else if (solver == SOLVER_MG33) {
        mg33_vcycle_cached(p, H2, 0, x, b);
    } else if (solver == SOLVER_RMT3P6) {
        rmt3p6_cycle_cached(p, H3, 0, x, b);
    } else if (solver == SOLVER_RMT3C4P6) {
        rmt3c4p6_cycle_cached(p, H3, 0, x, b);
    }
}

static Summary run_solver_once(const Params *p, const Op2D *A,
                               const double *bLinear, const double *xEx,
                               double r0,
                               const MGHierarchy *H2, const MGHierarchy *H3,
                               SolverType solver, int threads) {
    Summary s;
    memset(&s, 0, sizeof(s));
    s.name = solver_name(solver);
    s.threads = threads;
    const size_t N = (size_t)A->n * (size_t)A->n;

    double *x = (double*)xcalloc(N, sizeof(double), "x solver state");
    double *xOld = (double*)xcalloc(N, sizeof(double), "xOld");
    double *r = (double*)xcalloc(N, sizeof(double), "r");
    double *rhsEff = (double*)xcalloc(N, sizeof(double), "rhsEff");
    double *jbuf = NULL;
    if (solver == SOLVER_GS && p->omegaEuler != 0.0)
        jbuf = (double*)xcalloc(N, sizeof(double), "jbuf");

    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t q = 0; q < N; ++q) x[q] = p->Tshift;

    set_threads(threads);
    double t0 = now_seconds();
    for (int it = 1; it <= p->maxIter; ++it) {
        memcpy(xOld, x, N * sizeof(double));

        #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
        for (size_t q = 0; q < N; ++q)
            rhsEff[q] = bLinear[q] - p->reactRef * arrhenius_rate_eval(p, xOld[q]);

        apply_scalar_iteration(p, A, solver, H2, H3, x, rhsEff, jbuf);

        if (p->picardRelax < 1.0) {
            const double om = p->picardRelax;
            #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
            for (size_t q = 0; q < N; ++q) x[q] = xOld[q] + om * (x[q] - xOld[q]);
        }

        #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
        for (size_t q = 0; q < N; ++q)
            if (x[q] < p->TminClamp) x[q] = p->TminClamp;

        compute_residual_nonlinear(A, p, x, bLinear, r);
        s.iterations = it;
        s.residual_rel = l2_norm(r, N) / r0;
        if (p->verbose && (it <= 10 || it % 25 == 0))
            printf("  %-9s thr=%d outer=%6d residual_rel=% .5e\n", s.name, threads, it, s.residual_rel);
        if (s.residual_rel < p->tol) { s.converged = 1; break; }
        if (p->maxSolveSeconds > 0.0 && (now_seconds() - t0) > p->maxSolveSeconds) { s.timed_out = 1; break; }
    }

    s.solve_seconds = now_seconds() - t0;
    s.error_inf = linf_error(x, xEx, N);
    s.error_l2  = l2_error(x, xEx, N);
    s.x = x;

    free(xOld); free(r); free(rhsEff); free(jbuf);
    return s;
}

static Summary run_solver(const Params *p, const Op2D *A,
                          const double *bLinear, const double *xEx,
                          double r0,
                          const MGHierarchy *H2, const MGHierarchy *H3,
                          SolverType solver, int threads) {
    int reps = p->timingRepeats > 0 ? p->timingRepeats : 1;
    double *times = (double*)xcalloc((size_t)reps, sizeof(double), "timing repeats");

    Summary out = run_solver_once(p, A, bLinear, xEx, r0, H2, H3, solver, threads);
    out.timing_repeats = reps;
    times[0] = out.solve_seconds;

    for (int rep = 1; rep < reps; ++rep) {
        Summary tmp = run_solver_once(p, A, bLinear, xEx, r0, H2, H3, solver, threads);
        times[rep] = tmp.solve_seconds;
        free(tmp.x);
    }

    double tmin = times[0], tmax = times[0];
    for (int i = 1; i < reps; ++i) {
        if (times[i] < tmin) tmin = times[i];
        if (times[i] > tmax) tmax = times[i];
    }
    double *tsorted = (double*)xcalloc((size_t)reps, sizeof(double), "sorted timing repeats");
    memcpy(tsorted, times, (size_t)reps * sizeof(double));
    out.solve_seconds = median_of(tsorted, reps);
    out.solve_seconds_min = tmin;
    out.solve_seconds_max = tmax;
    free(tsorted);
    free(times);
    return out;
}

static void write_csv_solution(const char *path, const Op2D *A,
                               const Params *p,
                               const double *x, const double *xEx,
                               const double *forcing, const double *bLinear,
                               const char *caseLabel, const char *solverLabel, int threads,
                               const char *stiffLabel, double stiffVal) {
    FILE *fp = fopen(path, "w");
    if (!fp) { fprintf(stderr, "warning: could not open %s\n", path); return; }
    int n = A->n;
    double h = A->h;
    fprintf(fp, "# case,%s\n# solver,%s\n# threads,%d\n# n,%d\n# h,%.16e\n# %s,%.16e\n", caseLabel, solverLabel, threads, n, h, stiffLabel, stiffVal);
    fprintf(fp, "i,j,x,y,T,T_exact,error_T,forcing_continuous,rhs_linear,arrhenius_exact,reaction_exact,kx_cell,ky_cell,q_cell,bx_cell,by_cell,cell_Pe\n");
    for (int j=0;j<n;++j) for (int i=0;i<n;++i) {
        size_t idx = ID(i,j,n);
        double xx = (double)(i+1) * h;
        double yy = (double)(j+1) * h;
        double TT = x ? x[idx] : xEx[idx];
        double arrExact = arrhenius_rate_eval(p, xEx[idx]);
        fprintf(fp, "%d,%d,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e\n",
                i, j, xx, yy, TT, xEx[idx], TT - xEx[idx], forcing[idx], bLinear[idx],
                arrExact, p->reactRef * arrExact,
                A->kxCell[idx], A->kyCell[idx], A->qCell[idx], A->bxCell[idx], A->byCell[idx], A->peCell[idx]);
    }
    fclose(fp);
}

static void write_summary_csv(const char *path, const Summary *S, int m, const Params *p, const Op2D *A,
                              const char *stiffLabel, double stiffVal) {
    FILE *fp = fopen(path, "w");
    if (!fp) { fprintf(stderr, "warning: could not open %s\n", path); return; }
    fprintf(fp, "problem,stiff_name,stiff_value,n,h,tol,maxIter,sigmaT,Tshift,Tscale,amp,q0,PeRef,flowAngleDeg,anisoKy,arrA,arrBeta,arrTa,picardRelax,solver,threads,converged,timed_out,outer_iterations,residual_rel,error_inf,error_l2,solve_s_median,solve_s_min,solve_s_max,timing_repeats,speedup\n");
    for (int i=0;i<m;++i) fprintf(fp,
            "%s,%s,%.16e,%d,%.16e,%.16e,%d,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%s,%d,%d,%d,%d,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%d,%.16e\n",
            case_name(p->problem), stiffLabel, stiffVal, p->n, A->h, p->tol, p->maxIter, p->sigmaT, p->Tshift, p->Tscale,
            p->amp, p->q0, p->PeRef, p->flowAngleDeg, p->anisoKy,
            p->arrA, p->arrBeta, p->arrTa, p->picardRelax,
            S[i].name, S[i].threads, S[i].converged, S[i].timed_out, S[i].iterations,
            S[i].residual_rel, S[i].error_inf, S[i].error_l2,
            S[i].solve_seconds, S[i].solve_seconds_min, S[i].solve_seconds_max,
            S[i].timing_repeats, S[i].speedup_vs_serial);
    fclose(fp);
}

static void append_global_summary(FILE *fp, const Summary *S, int m, const Params *p, const Op2D *A,
                                  const char *stiffLabel, double stiffVal) {
    for (int i=0;i<m;++i) fprintf(fp,
            "%s,%s,%.16e,%d,%.16e,%.16e,%d,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%s,%d,%d,%d,%d,%.16e,%.16e,%.16e,%.16e,%.16e,%.16e,%d,%.16e\n",
            case_name(p->problem), stiffLabel, stiffVal, p->n, A->h, p->tol, p->maxIter, p->sigmaT, p->Tshift, p->Tscale,
            p->amp, p->q0, p->PeRef, p->flowAngleDeg, p->anisoKy,
            p->arrA, p->arrBeta, p->arrTa, p->picardRelax,
            S[i].name, S[i].threads, S[i].converged, S[i].timed_out, S[i].iterations,
            S[i].residual_rel, S[i].error_inf, S[i].error_l2,
            S[i].solve_seconds, S[i].solve_seconds_min, S[i].solve_seconds_max,
            S[i].timing_repeats, S[i].speedup_vs_serial);
}

static void free_summaries(Summary *S, int m) {
    for (int i=0;i<m;++i) free(S[i].x);
}

static void print_summary(const Summary *S, int m) {
    printf("\n%-10s %-4s %-5s %-5s %-12s %-12s %-11s %-11s\n",
           "solver", "thr", "conv", "iter", "residual_rel", "error_inf", "solve_s", "speedup");
    for (int i=0;i<m;++i) {
        printf("%-10s %-4d %-5s %-5d % .5e % .5e % .5e % .4f\n",
               S[i].name, S[i].threads, S[i].converged?"yes":"no", S[i].iterations,
               S[i].residual_rel, S[i].error_inf, S[i].solve_seconds, S[i].speedup_vs_serial);
    }
}

static void print_winners(const Summary *S, int m) {
    int bestIter = -1, bestErr = -1, bestT1 = -1, bestT4 = -1;
    for (int i=0;i<m;++i) if (S[i].converged) {
        if (bestIter < 0 || S[i].iterations < S[bestIter].iterations) bestIter = i;
        if (bestErr  < 0 || S[i].error_inf < S[bestErr].error_inf) bestErr = i;
        if (S[i].threads == 1 && (bestT1 < 0 || S[i].solve_seconds < S[bestT1].solve_seconds)) bestT1 = i;
        if (S[i].threads == 4 && (bestT4 < 0 || S[i].solve_seconds < S[bestT4].solve_seconds)) bestT4 = i;
    }
    printf("\nWinners among converged runs:\n");
    if (bestIter >= 0) printf("  fewest outer iterations : %s thr=%d iter=%d\n", S[bestIter].name, S[bestIter].threads, S[bestIter].iterations);
    if (bestErr  >= 0) printf("  lowest error_inf        : %s thr=%d err=% .5e\n", S[bestErr].name, S[bestErr].threads, S[bestErr].error_inf);
    if (bestT1   >= 0) printf("  fastest serial          : %s time=% .5e s\n", S[bestT1].name, S[bestT1].solve_seconds);
    if (bestT4   >= 0) printf("  fastest 4-thread        : %s time=% .5e s speedup=% .4f\n", S[bestT4].name, S[bestT4].solve_seconds, S[bestT4].speedup_vs_serial);
}

static double current_stiff_value(const Params *p) { return p->reactRef; }
static void set_stiff_value(Params *p, double v) { p->reactRef = v; }

static void describe_stiffness(const Params *p, char *buf, size_t nbuf) {
    snprintf(buf, nbuf, "reactRef=%g", p->reactRef);
}

static const double *stiff_list_for_case(const Params *p, CaseType c, int *count) {
    (void)c;
    *count = p->reactCount;
    return p->reactList;
}

static int mg33_terminal_n(int n, int coarseExactN) {
    int ncur = n;
    while (ncur > coarseExactN && can_coarsen_2h(ncur)) ncur = coarse_n_2h(ncur);
    return ncur;
}

static int mg33_mesh_is_fair(const Params *p, int n) {
    int leaf = mg33_terminal_n(n, p->coarseExactN);
    return leaf <= p->fairLeafMaxN;
}

static int pruned_keep_config(const Params *p, CaseType c, int n, double stiffVal) {
    (void)c; (void)stiffVal;
    if (!p->includeUnfairMeshes && !mg33_mesh_is_fair(p, n)) return 0;
    return 1;
}

static int pruned_total_configs(const Params *p, int caseStart, int caseEnd, const CaseType *cases) {
    int total = 0;
    for (int ci=caseStart; ci<caseEnd; ++ci) {
        int stiffCount = 1;
        const double *stiffList = NULL;
        if (p->stiffSweep) stiffList = stiff_list_for_case(p, cases[ci], &stiffCount);
        int meshCount = p->meshSweep ? p->nCount : 1;
        for (int si=0; si<stiffCount; ++si) {
            double sval = p->stiffSweep ? stiffList[si] : 0.0;
            for (int mi=0; mi<meshCount; ++mi) {
                int n = p->meshSweep ? p->nList[mi] : p->n;
                if (pruned_keep_config(p, cases[ci], n, sval)) ++total;
            }
        }
    }
    return total;
}

static void run_case_config(const Params *pIn, FILE *globalCsv) {
    Params p = *pIn;
    Op2D A;
    build_operator(&A, &p, p.n, p.problem);
    size_t N = (size_t)p.n * (size_t)p.n;
    MGHierarchy H2, H3;
    hierarchy_build(&H2, &p, p.n, p.problem, 2);
    hierarchy_build(&H3, &p, p.n, p.problem, 3);

    double *xEx = (double*)xcalloc(N, sizeof(double), "xEx");
    double *f = (double*)xcalloc(N, sizeof(double), "forcing");
    double *bBc = (double*)xcalloc(N, sizeof(double), "bBc");
    double *bLinear = (double*)xcalloc(N, sizeof(double), "bLinear");
    double *r0buf = (double*)xcalloc(N, sizeof(double), "r0buf");
    double *x0 = (double*)xcalloc(N, sizeof(double), "x0");

    build_exact_field(&A, &p, xEx);
    build_forcing_field(&A, &p, p.problem, f);
    build_boundary_rhs(&A, &p, bBc);
    build_rhs_linear(&A, f, bBc, bLinear);

    #pragma omp parallel for schedule(static) if(N >= OMP_MIN_WORK)
    for (size_t q = 0; q < N; ++q) x0[q] = p.Tshift;
    compute_residual_nonlinear(&A, &p, x0, bLinear, r0buf);
    double r0 = l2_norm(r0buf, N);
    if (r0 <= 0.0) r0 = 1.0;

    char stiffBuf[256];
    describe_stiffness(&p, stiffBuf, sizeof(stiffBuf));
    printf("\n------------------------------------------------------------\n");
    printf("case=%s | n=%d | h=%e | %s | tol=%g | maxOuter=%d\n", case_name(p.problem), p.n, A.h, stiffBuf, p.tol, p.maxIter);
    printf("exact field: T = Tshift + Tscale*exp(sigmaT*(x+y)); sigmaT=%g Tshift=%g Tscale=%g\n", p.sigmaT, p.Tshift, p.Tscale);
    printf("Arrhenius source: Da*A*T^beta*exp(-Ta/T) with A=%g beta=%g Ta=%g\n", p.arrA, p.arrBeta, p.arrTa);
    printf("cached multilevel setup: mg33 levels=%d, rmt3 levels=%d (hierarchy construction excluded from solve time)\n", H2.nLevels, H3.nLevels);
    if (!mg33_mesh_is_fair(&p, p.n))
        printf("fairness warning: mg33 terminal 2h leaf n=%d exceeds fairLeafMaxN=%d; this mesh is excluded by default unless -includeUnfairMeshes 1 is used.\n", mg33_terminal_n(p.n, p.coarseExactN), p.fairLeafMaxN);
    if (!can_coarsen_2h(p.n)) printf("warning: mg33 falls back to exact solve immediately because n is not perfectly 2h-nested\n");
    if (!can_coarsen_3h(p.n)) printf("warning: rmt3 falls back to exact solve immediately because n is not perfectly 3h-nested\n");

    Summary S[8];
    SolverType solvers[4] = {SOLVER_GS, SOLVER_MG33, SOLVER_RMT3P6, SOLVER_RMT3C4P6};
    int m = 0;
    if (p.verificationMode) {
        int vsi = p.verificationSolver;
        if (vsi < 0 || vsi > 3) vsi = 1;
        int vthr = (p.verificationThreads > 0) ? p.verificationThreads : 1;
        S[m++] = run_solver(&p, &A, bLinear, xEx, r0, &H2, &H3, solvers[vsi], vthr);
        S[0].speedup_vs_serial = 1.0;
        printf("verification mode: solver=%s threads=%d (single solver avoids GS cost on the n=431 order grid)\n", S[0].name, S[0].threads);
    } else {
        int idx = 0;
        for (int si=0; si<4; ++si) {
            S[idx++] = run_solver(&p, &A, bLinear, xEx, r0, &H2, &H3, solvers[si], 1);
            S[idx++] = run_solver(&p, &A, bLinear, xEx, r0, &H2, &H3, solvers[si], 4);
        }
        m = idx;
        for (int si=0; si<4; ++si) {
            double t1 = S[2*si].solve_seconds, t4 = S[2*si+1].solve_seconds;
            S[2*si].speedup_vs_serial = 1.0;
            S[2*si+1].speedup_vs_serial = (t4 > 0.0 ? t1 / t4 : 0.0);
        }
    }
    print_summary(S, m);
    print_winners(S, m);

    if (p.writeCSV) {
        ensure_dir("csv_benchmarkD_v2_arrhenius_mms");
        char path[512];
        double sval = current_stiff_value(&p);
        const char *sname = stiff_name(p.problem);
        snprintf(path,sizeof(path),"csv_benchmarkD_v2_arrhenius_mms/%s_n%d_%s%.3e_summary.csv",case_name(p.problem),p.n,sname,sval);
        write_summary_csv(path,S,m,&p,&A,sname,sval);
        if (p.writeFields) {
            snprintf(path,sizeof(path),"csv_benchmarkD_v2_arrhenius_mms/%s_n%d_%s%.3e_exact.csv",case_name(p.problem),p.n,sname,sval);
            write_csv_solution(path,&A,&p,NULL,xEx,f,bLinear,case_name(p.problem),"exact",0,sname,sval);
            for (int i=0;i<m;++i) {
                snprintf(path,sizeof(path),"csv_benchmarkD_v2_arrhenius_mms/%s_n%d_%s%.3e_%s_t%d.csv",case_name(p.problem),p.n,sname,sval,S[i].name,S[i].threads);
                write_csv_solution(path,&A,&p,S[i].x,xEx,f,bLinear,case_name(p.problem),S[i].name,S[i].threads,sname,sval);
            }
        }
        if (globalCsv) append_global_summary(globalCsv,S,m,&p,&A,sname,sval);
        printf("CSV written for this configuration.\n");
    }

    free_summaries(S,m);
    free(xEx); free(f); free(bBc); free(bLinear); free(r0buf); free(x0);
    hierarchy_free(&H2); hierarchy_free(&H3); op2d_free(&A);
}

static void run_sweeps(const Params *pBase) {
    ensure_dir("csv_benchmarkD_v2_arrhenius_mms");
    FILE *global = NULL;
    if (pBase->writeCSV) {
        global = fopen("csv_benchmarkD_v2_arrhenius_mms/all_runs_summary.csv", "w");
        if (global) fprintf(global, "problem,stiff_name,stiff_value,n,h,tol,maxIter,sigmaT,Tshift,Tscale,amp,q0,PeRef,flowAngleDeg,anisoKy,arrA,arrBeta,arrTa,picardRelax,solver,threads,converged,timed_out,outer_iterations,residual_rel,error_inf,error_l2,solve_s_median,solve_s_min,solve_s_max,timing_repeats,speedup\n");
    }

    CaseType cases[2] = {CASE_REACTFLOW, CASE_REACTANISO};
    int caseStart = 0, caseEnd = 2;
    if (!pBase->runAllCases && pBase->problem != CASE_ALL) {
        caseStart = 0;
        caseEnd   = 1;
        cases[0]  = pBase->problem;
    }

    int totalConfigs = pruned_total_configs(pBase, caseStart, caseEnd, cases);
    int cfg = 0;
    for (int ci=caseStart; ci<caseEnd; ++ci) {
        CaseType c = cases[ci];
        int stiffCount = 1;
        const double *stiffList = NULL;
        if (pBase->stiffSweep) stiffList = stiff_list_for_case(pBase, c, &stiffCount);
        double oneStiff = 0.0;
        if (!pBase->stiffSweep) {
            Params tmp = *pBase;
            tmp.problem = c;
            oneStiff = current_stiff_value(&tmp);
        }
        int meshCount = pBase->meshSweep ? pBase->nCount : 1;

        printf("\n============================================================\n");
        printf("Starting case family: %s | mesh sweep=%s | stiffness sweep=%s\n", case_name(c), pBase->meshSweep?"on":"off", pBase->stiffSweep?"on":"off");
        printf("============================================================\n");
        for (int si=0; si<stiffCount; ++si) {
            for (int mi=0; mi<meshCount; ++mi) {
                int nThis = pBase->meshSweep ? pBase->nList[mi] : pBase->n;
                double sval = pBase->stiffSweep ? stiffList[si] : oneStiff;
                if (!pruned_keep_config(pBase, c, nThis, sval)) continue;
                Params p = *pBase;
                p.problem = c;
                p.runAllCases = 0;
                p.n = nThis;
                set_stiff_value(&p, sval);
                ++cfg;
                printf("\n>>> Configuration %d / %d\n", cfg, totalConfigs);
                run_case_config(&p, global);
            }
        }
    }
    if (global) fclose(global);
    if (pBase->writeCSV) printf("\nGlobal CSV summary written to csv_benchmarkD_v2_arrhenius_mms/all_runs_summary.csv\n");
}

int main(int argc, char **argv) {
    Params p;
    init_params(&p);
    parse_args(argc, argv, &p);
    printf("Compile note: use -fopenmp for 4-core parallel runs.\n");
#ifdef _OPENMP
    printf("OpenMP detected. Max available threads reported by runtime: %d\n", omp_get_max_threads());
#else
    printf("OpenMP not enabled at compile time. Parallel cases will behave like serial.\n");
#endif
    printf("Frozen solver set: gsRB, mg33, rmt3p6, rmt3c4p6\n");
    printf("Benchmark D V2 defaults (nonlinear Arrhenius MMS reaction benchmark):\n");
    printf("  reactFlow  : kx=1+amp*sin(2*pi*x), ky=1+amp*cos(2*pi*y)\n");
    printf("  reactAniso : kx=1+amp*sin(2*pi*x), ky=anisoKy*(1+amp*cos(2*pi*y))\n");
    printf("  PDE        : -div(k grad T) + b.grad(T) + q0*T + Da*A*T^beta*exp(-Ta/T) = f\n");
    printf("  exact      : T = Tshift + Tscale*exp(sigmaT*(x+y))\n");
    printf("  q0         = %g\n", p.q0);
    printf("  amp        = %g\n", p.amp);
    printf("  anisoKy    = %g (used in reactAniso)\n", p.anisoKy);
    printf("  PeRef      = %g\n", p.PeRef);
    printf("  angle      = %g deg\n", p.flowAngleDeg);
    printf("  reactRef   = %g\n", p.reactRef);
    printf("  Arrhenius A= %g, beta=%g, Ta=%g\n", p.arrA, p.arrBeta, p.arrTa);
    printf("  Picard relax = %g\n", p.picardRelax);
    printf("  sigmaT     = %g\n", p.sigmaT);
    printf("  Tshift     = %g\n", p.Tshift);
    printf("  Tscale     = %g\n", p.Tscale);
    printf("Mesh sweep: %s\n", p.meshSweep ? "on" : "off");
    if (p.meshSweep) {
        printf("  nList = ");
        for (int i=0;i<p.nCount;++i) printf("%d%s", p.nList[i], (i+1<p.nCount? ",":"\n"));
    } else {
        printf("  single n = %d\n", p.n);
    }
    printf("Stiffness sweep: %s\n", p.stiffSweep ? "on" : "off");
    if (p.stiffSweep) {
        printf("  react list = ");
        for (int i=0;i<p.reactCount;++i) printf("%g%s", p.reactList[i], (i+1<p.reactCount? ",":"\n"));
    } else {
        printf("  fixed reactRef = %g\n", p.reactRef);
    }
    printf("Timing repeats per solver: %d (reported solve_s is median; min/max also stored)\n", p.timingRepeats > 0 ? p.timingRepeats : 1);
    printf("CSV writing is NOT included in solve time.\n");
    printf("Per-solver wall-time guard: %.1f s (set 0 to disable)\n", p.maxSolveSeconds);
    printf("CSV folder: csv_benchmarkD_v2_arrhenius_mms/\n");
    printf("Design note: D now solves a genuinely nonlinear Arrhenius-type reaction equation with an analytical manufactured solution, while keeping the frozen A-C solver set.\n");
    run_sweeps(&p);
    return 0;
}
