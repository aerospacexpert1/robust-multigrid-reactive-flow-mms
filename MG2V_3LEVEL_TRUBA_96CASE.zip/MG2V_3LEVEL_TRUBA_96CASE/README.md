# MG2V-3LEVEL opposed-flow reacting-flow campaign

Complete ready-to-run TRUBA campaign for the classical **twofold-coarsening V-cycle** pressure solver.

The reacting-flow formulation is frozen relative to the matched V95 campaign. Only the pressure-solution strategy is changed/identified as MG2-V.

## Pressure hierarchy

- L0: `h`
- L1: `2h`
- L2: `4h`
- cycle: V-cycle (`gamma=1`)
- smoother: RBGS
- default pre/post sweeps: 3 / 3
- coarsest-grid sweeps: 40
- restriction: conservative 2x2 averaging
- prolongation: cell-centred bilinear interpolation

## Campaign matrix

- FLOW_INTENSITY: 0.05, 0.10, 0.20 m/s
- REACTION_STIFFNESS: low/intermediate/high chemistry cases
- meshes: 108x36, 216x72, 432x144, 864x288
- threads: 1, 2, 4, 16
- final physical time: 2.0 s
- total: 96 runs

## TRUBA quick start

```bash
chmod +x *.sh *.slurm *.py tests/*.sh
./verify_campaign.sh
./submit_task0.sh
```

After task 0 is confirmed:

```bash
./submit_all.sh
```

Monitor:

```bash
squeue -u "$USER"
./check_campaign_status.sh
```

Collect after completion:

```bash
python3 collect_summary.py
wc -l MG2V_campaign_summary.csv
python3 analyze_scaling.py
```

A complete campaign produces 97 lines in `MG2V_campaign_summary.csv` (header + 96 cases).
