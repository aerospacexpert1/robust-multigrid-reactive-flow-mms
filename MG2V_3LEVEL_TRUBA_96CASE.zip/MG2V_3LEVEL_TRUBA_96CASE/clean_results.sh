#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
rm -rf results
rm -f slurm-MG2V_96_*.out slurm-MG2V_96_*.err
rm -f slurm-MG2V_BUILD_*.out slurm-MG2V_BUILD_*.err
rm -f summary_all_96.csv scaling.csv
