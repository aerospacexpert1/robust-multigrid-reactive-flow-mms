# MG2V-3LEVEL numerical method

This executable preserves the frozen V95 opposed-flow reacting-flow formulation and changes the pressure Poisson solver only.

`MG2V` denotes **factor-two geometric coarsening with a V-cycle**. The pressure hierarchy contains exactly three geometric levels:

- L0: `Nx x Ny`, spacing `h`
- L1: `Nx/2 x Ny/2`, spacing `2h`
- L2: `Nx/4 x Ny/4`, spacing `4h`

Thus the hierarchy is `h -> 2h -> 4h`. All four campaign meshes are divisible by four, so no padding or irregular coarsening is used.

## One pressure V-cycle (gamma = 1)

1. Apply 3 RBGS pre-smoothing sweeps on L0.
2. Compute the L0 residual and restrict it to L1 by conservative 2x2 cell averaging.
3. Apply 3 RBGS pre-smoothing sweeps to the L1 correction equation.
4. Compute the L1 residual and restrict it to L2.
5. Approximately solve the L2 correction equation with 40 RBGS sweeps.
6. Bilinearly prolong the L2 correction to L1 and correct L1.
7. Apply 3 RBGS post-smoothing sweeps on L1.
8. Bilinearly prolong the L1 correction to L0 and correct pressure.
9. Apply 3 RBGS post-smoothing sweeps on L0.
10. Recompute the pressure residual and test the absolute/relative stopping criteria.

The cycle index is `gamma = 1`: each next-coarser branch is visited once per cycle.

## Transfer operators

Restriction is conservative 2x2 cell averaging. Prolongation is cell-centred bilinear interpolation using 3/4-1/4 one-dimensional weights (tensor product in 2-D).

## Reported metrics

Each run reports total V-cycles, average and maximum V-cycles per pressure solve, pressure residuals, observed per-cycle convergence factor, restriction/prolongation counts, smoothing work at each level, and equivalent-fine-grid smoothing work. The work accounting weights L0/L1/L2 smoothing by 1, 1/4 and 1/16 respectively.
