# Output layout and timing rules

Each run writes to:

`results/<FLOW-or-STIFFNESS>/<physical-case>/<mesh>/<C1|C2|C4|C16>/`

The important files are:

- `run.log` - solver console log.
- `parameters.txt` - exact case, mesh, physics, solver, thread, Slurm and node settings.
- `launcher_timing.txt` - external wall time including `srun` and output.
- `output/summary.csv` - one-row numerical/performance summary.
- `output/fields.pvd` - ParaView collection file.
- `output/vtk/*.vti` - VTK XML ImageData fields (initial and final by default).
- `output/csv/centerline_*.csv` - centreline profiles.
- `output/performance/pressure_step_history.csv` - pressure solve history for every physical time step.
- `output/performance/final_pressure_cycle_history.csv` - cycle-by-cycle residual reduction for the final pressure solve.

The C code measures `compute_time_s` around numerical work only. VTK/PVD/CSV and performance-file writing is deliberately outside that timer. `pressure_time_s` is a subset of compute time. The launcher wall time is retained separately so I/O and launch overhead can be audited instead of silently mixed into solver compute time.

`collect_summary.py` gathers all run summaries into `summary_all_96.csv`. `analyze_scaling.py` calculates 1/2/4/16-thread speedup and efficiency from compute time and pressure time.
