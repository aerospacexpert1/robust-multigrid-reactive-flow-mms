# Code provenance

The reacting-flow formulation in `src/opposedflow_mg2v.c` is derived from the frozen V95 OpenFOAM-matched in-house source used in the thesis campaign:

`opposedflowV95_openfoamMatchCampaign.c`

Frozen V95 SHA-256:

`08f29cd9520b3230582fe99b4e66b5bcf9f053cec9fd9babe28b55d69288099e`

The MG2V branch intentionally changes the pressure solver and performance instrumentation while retaining the matched physical model, transport/scalar treatment, chemistry treatment, adaptive time stepping, domain, boundary conditions and campaign constants. This separation is deliberate so the classical multigrid result can be interpreted as an internal solver-method comparison rather than a different reacting-flow model.
