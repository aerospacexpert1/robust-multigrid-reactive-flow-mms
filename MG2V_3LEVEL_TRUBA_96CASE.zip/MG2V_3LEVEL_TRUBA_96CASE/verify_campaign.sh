#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PY'
import csv
from pathlib import Path
root=Path('.')
with open(root/'campaign_manifest.csv', newline='', encoding='utf-8') as f:
    rows=list(csv.DictReader(f))
assert len(rows)==96, f"expected 96 manifest rows, found {len(rows)}"
assert {int(r['threads']) for r in rows} == {1,2,4,16}
assert len({(r['study_family'],r['physical_case'],r['mesh_name']) for r in rows}) == 24
for r in rows:
    nx,ny=int(r['Nx']),int(r['Ny'])
    assert nx%4==0 and ny%4==0, f"mesh not compatible with h/2h/4h hierarchy: {nx}x{ny}"
for p in root.rglob('*'):
    if p.is_file() and p.name != 'SHA256SUMS':
        b=p.read_bytes()
        assert b'\r' not in b, f"carriage-return contamination: {p}"
source=(root/'src/opposedflow_mg2v.c').read_text()
required=['MG2V-3LEVEL','MG2V_3LEVEL','mg_level1_vcycle','mg_restrict_2x2','mg_prolong_bilinear_add',
          'write_pressure_step_history','write_case_summary_csv']
for token in required:
    assert token in source, f"source verification missing {token}"
assert source.count('mg_level1_vcycle(c, work);') == 1, 'MG2-V must make one level-1 recursive V visit per fine cycle'
assert 'MG3V' not in source and 'mg3v' not in source, 'old MG3V public identifiers remain in source'
print('Verified: MG2-V factor-two hierarchy h->2h->4h, gamma=1 V-cycle, 96 cases, 1/2/4/16 threads, LF-only files, and output instrumentation.')
PY
