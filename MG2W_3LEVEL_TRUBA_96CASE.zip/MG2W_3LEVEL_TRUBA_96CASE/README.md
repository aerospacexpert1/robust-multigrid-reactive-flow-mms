# MG2W-3LEVEL opposed-flow reacting-flow campaign

Ready-to-run TRUBA package for the classical **MG2-W** pressure solver: factor-two geometric coarsening (`h -> 2h -> 4h`) with a three-level W-cycle (`gamma=2`).

The reacting-flow formulation and 96-case matrix are matched to the completed MG3-V/OpenFOAM comparison campaign:

- flow intensity: 0.05, 0.10, 0.20 m/s;
- reaction-stiffness family: A/Ta = 1e7/1000, 1e8/500, 1e9/100 at fixed 0.10 m/s;
- meshes: 108x36, 216x72, 432x144, 864x288;
- threads: 1, 2, 4, 16;
- final physical time: 2.0 s;
- 24 physical/mesh configurations x 4 thread counts = **96 runs**.

## Numerical change relative to MG3-V

Only the pressure multigrid cycle topology is intentionally changed. MG3-V makes one recursive L1 visit per fine-grid cycle; MG2-W makes two (`gamma=2`). The factor-two hierarchy, RBGS smoothing, 2x2 restriction, bilinear prolongation, pressure tolerances and reacting-flow formulation remain matched.

Defaults: 3 pre-sweeps, 3 post-sweeps and 40 coarsest-grid RBGS sweeps.

## TRUBA quick start

```bash
cd /arf/scratch/ozayifoglu/MG2W_3LEVEL_TRUBA_96CASE
chmod +x *.sh *.slurm *.py tests/*.sh
./verify_campaign.sh
```

Recommended: first build and run task 0 only:

```bash
./submit_task0.sh
squeue -u "$USER"
```

After task 0 finishes:

```bash
./check_campaign_status.sh
```

If task 0 is complete and clean, launch the campaign:

```bash
./submit_all.sh
```

`submit_all.sh` submits a fresh build followed by the 96-case array with an `afterok` dependency. Completed cases are skipped automatically by `run_case.sh`, so task 0 will not be recomputed if already complete.

Monitor:

```bash
squeue -u "$USER"
./check_campaign_status.sh
./list_unfinished.sh
```

Final collection:

```bash
python3 collect_summary.py
python3 analyze_scaling.py
wc -l MG2W_campaign_summary.csv
```

A complete campaign produces 97 lines in `MG2W_campaign_summary.csv` (header + 96 cases).

See `docs/NUMERICAL_METHOD.md` for the W-cycle definition.
