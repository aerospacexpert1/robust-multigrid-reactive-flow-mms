#!/usr/bin/env python3
import csv, math
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "MG2W_campaign_summary.csv"
OUT = ROOT / "scaling.csv"
if not SRC.exists():
    raise SystemExit("Run ./collect_summary.py first")
with SRC.open(newline="", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))

groups = defaultdict(list)
for r in rows:
    key = (r["study_family"], r["physical_case"], r["mesh_name"])
    groups[key].append(r)

out = []
for key, grp in sorted(groups.items()):
    by_t = {int(r["threads"]): r for r in grp}
    if 1 not in by_t:
        continue
    base = by_t[1]
    t1 = float(base["compute_time_s"])
    p1 = float(base["pressure_time_s"])
    for threads in (1, 2, 4, 16):
        if threads not in by_t:
            continue
        r = by_t[threads]
        tc = float(r["compute_time_s"]); pc = float(r["pressure_time_s"])
        speed = t1/tc if tc > 0 else math.nan
        pspeed = p1/pc if pc > 0 else math.nan
        out.append({
            "study_family": key[0], "physical_case": key[1], "mesh_name": key[2],
            "threads": threads, "compute_time_s": tc,
            "speedup_vs_1thread": speed, "parallel_efficiency": speed/threads,
            "pressure_time_s": pc, "pressure_speedup_vs_1thread": pspeed,
            "pressure_parallel_efficiency": pspeed/threads,
            "total_wcycles": r["total_wcycles"],
            "avg_wcycles_per_pressure_solve": r["avg_wcycles_per_pressure_solve"],
            "mean_pressure_convergence_factor": r["mean_pressure_convergence_factor"],
            "equivalent_fine_grid_smoothing_sweeps": r["equivalent_fine_grid_smoothing_sweeps"],
            "Tmax_K": r["Tmax_K"], "YPmax": r["YPmax"],
            "Tmax_abs_diff_vs_1thread": abs(float(r["Tmax_K"])-float(base["Tmax_K"])),
            "YPmax_abs_diff_vs_1thread": abs(float(r["YPmax"])-float(base["YPmax"])),
        })
if not out:
    raise SystemExit("No scaling groups with a 1-thread result were found")
with OUT.open("w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(out[0]))
    w.writeheader(); w.writerows(out)
print(f"Wrote {OUT} with {len(out)} rows")
