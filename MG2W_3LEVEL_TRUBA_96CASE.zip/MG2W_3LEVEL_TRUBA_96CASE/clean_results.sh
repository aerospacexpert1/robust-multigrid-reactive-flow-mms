#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
rm -rf results
rm -f slurm-MG2W_96_*.out slurm-MG2W_96_*.err
rm -f slurm-MG2W_BUILD_*.out slurm-MG2W_BUILD_*.err
rm -f MG2W_campaign_summary.csv scaling.csv
