# MG2W-3LEVEL numerical method

This executable preserves the frozen V95 opposed-flow reacting-flow formulation and changes the pressure Poisson solver only.

`MG2W` denotes **factor-two geometric coarsening with a W-cycle**. The pressure hierarchy contains exactly three geometric levels:

- L0: `Nx x Ny`, spacing `h`
- L1: `Nx/2 x Ny/2`, spacing `2h`
- L2: `Nx/4 x Ny/4`, spacing `4h`

All campaign meshes are divisible by four; no padding or irregular coarsening is used.

## One pressure W-cycle (gamma = 2)

1. Apply 3 RBGS pre-smoothing sweeps on L0.
2. Compute the L0 residual and restrict it to L1 by 2x2 cell-volume averaging.
3. Initialize the L1 correction to zero.
4. Perform the first L1 coarse-correction pass: 3 L1 pre-sweeps, residual restriction to L2, 40 RBGS coarsest sweeps, bilinear prolongation to L1, and 3 L1 post-sweeps.
5. Perform the **second** L1 coarse-correction pass on the updated L1 correction. This recomputes the L1 residual and revisits L2. This second recursive visit is the defining `gamma=2` W-cycle operation.
6. Bilinearly prolong the resulting L1 correction to L0 and correct pressure.
7. Apply 3 RBGS post-smoothing sweeps on L0.
8. Recompute the pressure residual and test the absolute/relative stopping criteria.

Thus, compared with the matched MG3-V campaign, the intended algorithmic change is the cycle topology: each fine-grid pressure cycle visits the L1 branch twice instead of once. Transfer operators, smoothers, tolerances, physical equations and campaign settings are otherwise retained.

## Transfer operators

Restriction is conservative 2x2 cell averaging. Prolongation is cell-centred bilinear interpolation using 3/4-1/4 one-dimensional weights (tensor product in 2-D).

## Reported metrics

Each run reports total W-cycles, average and maximum W-cycles per pressure solve, pressure residuals, observed per-cycle convergence factor, restriction/prolongation counts, smoothing work at each level, and equivalent-fine-grid smoothing work. The work accounting weights L0/L1/L2 smoothing by 1, 1/4 and 1/16 respectively.
