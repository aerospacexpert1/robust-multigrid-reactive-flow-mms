# Output layout and timing rules

Each run writes to:

`results/<FLOW-or-STIFFNESS>/<physical-case>/<mesh>/<C1|C2|C4|C16>/`

Important files:

- `run.log` - solver console log.
- `parameters.txt` - exact case, mesh, physics, solver, thread, Slurm and node settings.
- `launcher_timing.txt` - external wall time including `srun` and output.
- `output/summary.csv` - one-row numerical/performance summary.
- `output/fields.pvd` - ParaView collection file.
- `output/vtk/*.vti` - VTK XML ImageData fields.
- `output/csv/centerline_*.csv` - centreline profiles.
- `output/performance/pressure_step_history.csv` - pressure solve history for every physical time step.
- `output/performance/final_pressure_cycle_history.csv` - cycle-by-cycle residual reduction for the final pressure solve.

`compute_time_s` excludes VTK/PVD/CSV/performance-file I/O. `pressure_time_s` is a subset of compute time. Launcher wall time is retained separately.

`collect_summary.py` gathers available run summaries into `MG2W_campaign_summary.csv`. `analyze_scaling.py` calculates 1/2/4/16-thread speedup and efficiency from compute and pressure time.
