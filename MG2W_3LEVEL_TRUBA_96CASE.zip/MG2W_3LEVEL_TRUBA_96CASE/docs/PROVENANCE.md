# Code provenance

The MG2-W campaign was generated directly from the completed `MG3V_3LEVEL_TRUBA_96CASE` production package supplied by the project.

The reacting-flow formulation remains the frozen V95 OpenFOAM-matched in-house formulation. The intended numerical-method change relative to MG3-V is confined to the pressure multigrid cycle topology:

- MG3-V: factor-two hierarchy, one recursive L1 visit per fine cycle (`gamma=1`).
- MG2-W: same factor-two hierarchy and operators, two recursive L1 visits per fine cycle (`gamma=2`).

The campaign matrix, physical constants, scalar/chemistry treatment, adaptive time stepping, boundary conditions, output definitions and thread counts are retained. Manifest files are normalized to Unix LF line endings to prevent hidden carriage-return characters in result directory names.
