#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PY'
import csv
from pathlib import Path
root = Path('.')

# Line endings must be Unix-safe; this prevents hidden C4\r-style directories.
for p in [root/'campaign_manifest.csv', root/'physical_configuration_matrix.csv', root/'openfoam_case_matrix_reference.csv']:
    b = p.read_bytes()
    assert b'\r' not in b, f"CR/CRLF detected in {p}"

with open(root/'campaign_manifest.csv', newline='', encoding='utf-8') as f:
    rows = [{k.strip(): v.strip() for k,v in r.items()} for r in csv.DictReader(f)]
assert len(rows) == 96, f"expected 96 manifest rows, found {len(rows)}"
assert {int(r['threads']) for r in rows} == {1,2,4,16}
assert len({(r['study_family'],r['physical_case'],r['mesh_name']) for r in rows}) == 24
assert len({r['case_id'] for r in rows}) == 96
for r in rows:
    nx, ny = int(r['Nx']), int(r['Ny'])
    assert nx % 4 == 0 and ny % 4 == 0, f"mesh not compatible with h/2h/4h: {nx}x{ny}"

source = (root/'src/opposedflow_mg2w.c').read_text(encoding='utf-8')
required = [
    'MG2W-3LEVEL', 'MG2W_3LEVEL', 'MG_W_GAMMA = 2',
    'for (int gamma=0; gamma<MG_W_GAMMA; ++gamma)',
    'mg_level1_cycle', 'mg_restrict_2x2', 'mg_prolong_bilinear_add',
    'total_wcycles', 'avg_wcycles_per_pressure_solve',
    'write_pressure_step_history', 'write_case_summary_csv'
]
for token in required:
    assert token in source, f"source verification missing: {token}"
for forbidden in ['MG3V_3LEVEL', 'MG3V-3LEVEL', 'mg_level1_vcycle', 'total_vcycles']:
    assert forbidden not in source, f"stale MG3V token remains in source: {forbidden}"

print('Verified MG2-W package:')
print('  96 cases / 24 physical-mesh configurations / 1,2,4,16 threads')
print('  h -> 2h -> 4h hierarchy')
print('  classical W-cycle with gamma=2')
print('  3 pre + 3 post RBGS sweeps; 40 coarsest sweeps')
print('  Unix LF manifests (no hidden carriage returns)')
PY
