#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
src=src/opposedflow_mg3v.c

echo "MG3-V hierarchy audit"
echo "======================"
grep -nF 'coarse.Nx = fine->Nx / 3;' "$src"
grep -nF 'coarse.Ny = fine->Ny / 3;' "$src"
grep -nF 'coarse.dx = fine->dx * 3.0;' "$src"
grep -nF 'coarse.dy = fine->dy * 3.0;' "$src"
grep -nF 'static void mg_restrict_3x3' "$src"
grep -nF 'static void mg_prolong_bilinear_3to1_add' "$src"

echo
echo "Expected campaign hierarchies:"
echo "M1: 108x36  -> 36x12  -> 12x4"
echo "M2: 216x72  -> 72x24  -> 24x8"
echo "M3: 432x144 -> 144x48 -> 48x16"
echo "M4: 864x288 -> 288x96 -> 96x32"
echo
echo "PASS: source uses factor-three h->3h->9h coarsening."
