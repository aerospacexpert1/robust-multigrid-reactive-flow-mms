#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
rm -rf results
rm -f slurm-MG3V_96_*.out slurm-MG3V_96_*.err
rm -f slurm-MG3V_BUILD_*.out slurm-MG3V_BUILD_*.err
rm -f MG3V_campaign_summary.csv scaling.csv
