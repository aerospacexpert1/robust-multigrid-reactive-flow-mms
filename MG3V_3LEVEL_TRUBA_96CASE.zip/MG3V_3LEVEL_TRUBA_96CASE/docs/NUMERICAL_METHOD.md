# MG3V-3LEVEL numerical method

This executable preserves the frozen V95 opposed-flow reacting-flow formulation and changes the pressure Poisson solver only.

`MG3V` denotes **factor-three geometric coarsening with a V-cycle**. The pressure hierarchy contains exactly three geometric levels:

- L0: `Nx x Ny`, spacing `h`
- L1: `Nx/3 x Ny/3`, spacing `3h`
- L2: `Nx/9 x Ny/9`, spacing `9h`

Thus the hierarchy is `h -> 3h -> 9h`. All four campaign meshes are divisible by nine, so no padding or irregular coarsening is used.

## One pressure V-cycle (gamma = 1)

1. Apply 3 RBGS pre-smoothing sweeps on L0.
2. Compute the L0 residual and restrict it to L1 by conservative 3x3 cell averaging.
3. Apply 3 RBGS pre-smoothing sweeps to the L1 correction equation.
4. Compute the L1 residual and restrict it to L2.
5. Approximately solve the L2 correction equation with 40 RBGS sweeps.
6. Bilinearly prolong the L2 correction to L1 and correct L1.
7. Apply 3 RBGS post-smoothing sweeps on L1.
8. Bilinearly prolong the L1 correction to L0 and correct pressure.
9. Apply 3 RBGS post-smoothing sweeps on L0.
10. Recompute the pressure residual and test the absolute/relative stopping criteria.

The cycle index is `gamma = 1`: each next-coarser branch is visited once per cycle.

## Transfer operators

Restriction is conservative 3x3 cell averaging. Prolongation is cell-centred bilinear interpolation using 2/3-1/3 one-dimensional weights (tensor product in 2-D).

## Reported metrics

Each run reports total V-cycles, average and maximum V-cycles per pressure solve, pressure residuals, observed per-cycle convergence factor, restriction/prolongation counts, smoothing work at each level, and equivalent-fine-grid smoothing work. The work accounting weights L0/L1/L2 smoothing by 1, 1/9 and 1/81 respectively.
