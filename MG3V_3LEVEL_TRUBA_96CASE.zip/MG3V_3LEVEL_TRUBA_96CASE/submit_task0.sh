#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
./verify_campaign.sh
build_job=$(sbatch --parsable build_mg3v.slurm)
run_job=$(sbatch --parsable --dependency=afterok:${build_job} --array=0 mg3v_96_array.slurm)
echo "Build job: $build_job"
echo "Task-0 job: $run_job"
