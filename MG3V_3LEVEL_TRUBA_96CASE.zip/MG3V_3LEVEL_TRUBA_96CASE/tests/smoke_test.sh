#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
make
rm -rf tests/_smoke_output
OMP_NUM_THREADS=2 build/opposedflow_mg3v \
    -Nx 108 -Ny 36 -end 0.0001 -dt 1e-7 -dtMax 1e-4 \
    -vFuel 0.05 -vOx -0.05 -threads 2 -caseId LOCAL_SMOKE \
    -A 1e7 -beta 5 -Ta 1000 \
    -perfectGas 0 -variableCp 0 -sutherland 0 -rhoRelax 1 \
    -rho 1 -mu 2e-5 -cp 1000 -Pr 0.7 -Sc 1 -HfF 3.571428571e6 \
    -writeOutput 1 -write 0.0001 -outputDir tests/_smoke_output -progressEvery 0

test -s tests/_smoke_output/summary.csv
test -s tests/_smoke_output/fields.pvd
test -s tests/_smoke_output/performance/pressure_step_history.csv
echo "Smoke test passed."
