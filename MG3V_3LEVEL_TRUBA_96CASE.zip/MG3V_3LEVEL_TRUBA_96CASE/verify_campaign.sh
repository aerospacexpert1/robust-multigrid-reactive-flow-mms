#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PY'
import csv
from pathlib import Path
root=Path('.')
with open(root/'campaign_manifest.csv', newline='', encoding='utf-8') as f:
    rows=list(csv.DictReader(f))
assert len(rows)==96, f"expected 96 manifest rows, found {len(rows)}"
assert {int(r['threads']) for r in rows} == {1,2,4,16}
assert len({(r['study_family'],r['physical_case'],r['mesh_name']) for r in rows}) == 24
for r in rows:
    nx,ny=int(r['Nx']),int(r['Ny'])
    assert nx%9==0 and ny%9==0, f"mesh not compatible with h/3h/9h hierarchy: {nx}x{ny}"
text_suffixes={'.c','.h','.sh','.slurm','.py','.md','.txt','.csv'}
for p in root.rglob('*'):
    if not p.is_file() or p.name == 'SHA256SUMS':
        continue
    if any(part in {'build','results','_smoke_output'} for part in p.parts):
        continue
    if p.suffix.lower() in text_suffixes or p.name in {'Makefile'}:
        b=p.read_bytes()
        assert b'\r' not in b, f"carriage-return contamination: {p}"
source=(root/'src/opposedflow_mg3v.c').read_text()
required=['MG3V-3LEVEL','MG3V_3LEVEL','mg_level1_vcycle','mg_restrict_3x3','mg_prolong_bilinear_3to1_add',
          'write_pressure_step_history','write_case_summary_csv']
for token in required:
    assert token in source, f"source verification missing {token}"
assert source.count('mg_level1_vcycle(c, work);') == 1, 'MG3-V must make one level-1 recursive V visit per fine cycle'
assert 'coarse.Nx = fine->Nx / 3;' in source and 'coarse.Ny = fine->Ny / 3;' in source
assert 'coarse.dx = fine->dx * 3.0;' in source and 'coarse.dy = fine->dy * 3.0;' in source
assert 'sum / 9.0' in source, '3x3 conservative restriction weight missing'
assert 'g->Nx/3, g->Ny/3, g->Nx/9, g->Ny/9' in source, 'summary hierarchy is not h->3h->9h'
assert '(1.0/9.0)' in source and '(1.0/81.0)' in source, 'equivalent-work weights are not factor-three'
old_upper='MG2'+'V'; old_lower='mg2'+'v'; assert old_upper not in source and old_lower not in source, 'old public identifiers remain in source'
print('Verified: MG3-V factor-three hierarchy h->3h->9h, gamma=1 V-cycle, 96 cases, 1/2/4/16 threads, 3x3 restriction, 3:1 cell-centred bilinear prolongation, LF-only files, and output instrumentation.')
PY
