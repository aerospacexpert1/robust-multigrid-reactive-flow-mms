# Clean OpenFOAM v2312 / TRUBA Orfoz validation campaign

This is a clean, self-contained reset package for the opposed-flow validation campaign.
It contains **96 production runs** and all Slurm/runtime/summary scripts needed to execute them on TRUBA Orfoz.

## Confirmed TRUBA runtime

The environment already verified on an Orfoz compute node is:

```bash
module purge
module load apps/openfoam/v2312
```

The module provides `rhoReactingFoam`, `blockMesh`, `checkMesh`, `decomposePar`, `reconstructPar`, and Intel MPI 2021.11 (`WM_MPLIB=INTELMPI`).
The production scripts validate `WM_PROJECT_VERSION=v2312` and required executables directly. They do **not** depend on the `foamVersion` shell helper.

`orfoz359` is excluded in the supplied Slurm files because prior batch launches on that node terminated with signal 53 before the user script started. All other Orfoz nodes remain eligible.

## Production matrix: 96 runs

### Flow-intensity validation: 48 runs

Chemistry is fixed at `A=1.0e7`, `beta=5`, `Ta=1000 K`.

- BC1 low: `Vj=0.05 m/s`
- BC2 nominal: `Vj=0.10 m/s`
- BC3 high: `Vj=0.20 m/s`

Each is run on four meshes and four MPI process counts.

### Reaction/thermal-coupling stiffness: 48 runs

Flow is fixed at `Vj=0.10 m/s`.

- S1 low: `A=1.0e7`, `beta=5`, `Ta=1000 K`
- S2 intermediate: `A=1.0e8`, `beta=5`, `Ta=500 K`
- S3 high: `A=1.0e9`, `beta=5`, `Ta=100 K`

This family changes the reaction/thermal-coupling timescale. Density, viscosity, Cp, Pr, geometry and the heat-release model remain fixed.

### Meshes

- M1: 108 x 36 = 3,888 cells
- M2: 216 x 72 = 15,552 cells
- M3: 432 x 144 = 62,208 cells
- M4: 864 x 288 = 248,832 cells

### MPI sizes

- C1 = 1 rank
- C2 = 2 ranks
- C4 = 4 ranks
- C16 = 16 ranks

The four rank cases belonging to one physical configuration run sequentially on the same exclusively allocated Orfoz node. The job reserves 56 tasks because of the Orfoz allocation policy, but `rhoReactingFoam` uses only 1/2/4/16 ranks for the corresponding case.

## Fixed physical/numerical parameters

- rho = 1 kg/m3
- mu = 2.0e-5 Pa s
- Cp = 1000 J/(kg K)
- Pr = 0.7
- fuel formation enthalpy = 3.571428571e6 J/kg
- physical end time = 2.0 s
- initial deltaT = 1e-7 s
- maxCo = 0.05
- maxDeltaT = 1e-4 s
- production output = final-time field only

## Directory structure

```text
cases/FLOW/<flow-case>/<mesh>/C1|C2|C4|C16
cases/STIFFNESS/<stiffness-case>/<mesh>/C1|C2|C4|C16
```

`campaign_manifest.csv` contains all 96 runs. `physical_configurations.txt` contains the 24 Slurm array tasks.

## Start from the campaign root

Always `cd` into the extracted folder before submitting. The production script deliberately refuses to run if `cases/` is not below `SLURM_SUBMIT_DIR`.

### Verify package

```bash
chmod +x *.sh *.slurm *.py
./verify_campaign.sh
```

Expected:

```text
Verified: 96 cases, 24 physical configurations, ranks 1/2/4/16, reaction matrix, matched Hf, and clean v2312 batch scripts.
```

### Optional diagnostic jobs

Basic Slurm/Orfoz:

```bash
sbatch 00_orfoz_basic_test.slurm
```

OpenFOAM environment:

```bash
sbatch 01_openfoam_env_test.slurm
```

Actual short OpenFOAM smoke test:

```bash
sbatch openfoam_smoke_orfoz.slurm
```

### Production task 0 only

```bash
./submit_task0.sh
```

### Submit all 96 runs directly

```bash
./submit_all.sh
```

Equivalent direct command:

```bash
sbatch openfoam96_orfoz_array.slurm
```

The array is `0-23%3`: 24 physical configurations, at most 3 active array tasks, 4 rank cases executed sequentially per task.

## Monitor

```bash
squeue -u "$USER"
./check_campaign_status.sh
```

Continuous:

```bash
watch -n 30 ./check_campaign_status.sh
```

Expected final state:

```text
Completed : 96 / 96
Failed    : 0
Timing    : 96 / 96
```

## Timing methodology

`solver_wall_s` is the wall time of the `rhoReactingFoam` invocation only. `blockMesh`, `checkMesh`, decomposition, reconstruction and post-processing are outside this timing boundary. `ORFOZ_TIMING.txt` also records setup, reconstruction and complete-case wall time for diagnostics.

## Collect results

```bash
python3 collect_summary.py
python3 analyze_scaling.py
```

Outputs:

- `campaign_summary.csv`
- `scaling_summary.csv`

## Cleanup helpers

Delete root Slurm `.out/.err` files only:

```bash
./clean_slurm_logs.sh
```

Reset generated results inside all 96 cases while preserving the input cases:

```bash
./clean_all.sh
```
