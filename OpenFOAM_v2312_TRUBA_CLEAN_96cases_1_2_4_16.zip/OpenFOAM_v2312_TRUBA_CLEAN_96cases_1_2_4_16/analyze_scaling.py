#!/usr/bin/env python3
from pathlib import Path
import csv
root=Path(__file__).resolve().parent
inp=root/'campaign_summary.csv'
if not inp.exists(): raise SystemExit('Run collect_summary.py first')
with inp.open() as f: rows=list(csv.DictReader(f))
groups={}
for r in rows:
    key=(r['study_family'],r['physical_case'],r['mesh_name'])
    groups.setdefault(key,[]).append(r)
out=[]
for key,rs in groups.items():
    serial=next((r for r in rs if r['nprocs']=='1' and r.get('solver_wall_s')),None)
    if not serial: continue
    t1=float(serial['solver_wall_s'])
    for r in sorted(rs,key=lambda x:int(x['nprocs'])):
        if not r.get('solver_wall_s'): continue
        p=int(r['nprocs']); tp=float(r['solver_wall_s']); speed=t1/tp; eff=speed/p
        out.append({
            'study_family':r['study_family'],'physical_case':r['physical_case'],'mesh_name':r['mesh_name'],
            'cells':r['cells'],'nprocs':p,'solver_wall_s':f'{tp:.9f}','speedup_vs_1core':f'{speed:.6f}',
            'parallel_efficiency':f'{eff:.6f}','node':r.get('node','')})
fields=list(out[0]) if out else ['study_family','physical_case','mesh_name','cells','nprocs','solver_wall_s','speedup_vs_1core','parallel_efficiency','node']
with (root/'scaling_summary.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(out)
print(root/'scaling_summary.csv')
