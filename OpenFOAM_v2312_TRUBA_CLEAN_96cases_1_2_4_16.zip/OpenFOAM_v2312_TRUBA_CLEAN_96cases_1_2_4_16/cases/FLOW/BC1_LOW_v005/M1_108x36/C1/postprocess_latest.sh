#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v postProcess >/dev/null 2>&1 || {
    echo "ERROR: postProcess not found. Load apps/openfoam/v2312 first." >&2
    exit 127
}
postProcess -func sample -latestTime > log.sample 2>&1
printf 'Centerline data written under postProcessing/sets/\n'
