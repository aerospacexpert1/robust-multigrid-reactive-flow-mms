#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

complete=$(find cases -type f -name RUN_COMPLETE | wc -l)
failed=$(find cases -type f -name RUN_FAILED | wc -l)
timing=$(find cases -type f -name ORFOZ_TIMING.txt | wc -l)

echo "Completed : $complete / 96"
echo "Failed    : $failed"
echo "Timing    : $timing / 96"

if (( failed > 0 )); then
    echo
    echo "Failed cases:"
    find cases -type f -name RUN_FAILED -printf '%h\n' | sort
fi
