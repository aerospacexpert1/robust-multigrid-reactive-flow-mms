#!/usr/bin/env bash
set -eo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
while IFS= read -r rel; do
    [[ -z "$rel" ]] && continue
    bash "$ROOT/$rel/Allclean"
done < <(tail -n +2 "$ROOT/campaign_manifest.csv" | cut -d, -f2)
rm -f "$ROOT/campaign_summary.csv" "$ROOT/scaling_summary.csv"
rm -rf "$ROOT"/_v2312_campaign_smoke_*
echo "All generated case results removed; input cases preserved."
