#!/usr/bin/env bash
set -eo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
find . -maxdepth 1 -type f \( \
    -name 'slurm-OF2312_96_*.out' -o -name 'slurm-OF2312_96_*.err' -o \
    -name 'slurm-OF2312_smoke_*.out' -o -name 'slurm-OF2312_smoke_*.err' -o \
    -name 'orfoz_basic_*.out' -o -name 'orfoz_basic_*.err' -o \
    -name 'of_env_test_*.out' -o -name 'of_env_test_*.err' \) -delete
echo "Root-level Slurm/test .out/.err files removed. Case files were not touched."
