#!/usr/bin/env python3
from pathlib import Path
import csv,re
root=Path(__file__).resolve().parent
with (root/'campaign_manifest.csv').open() as f: manifest=list(csv.DictReader(f))
rows=[]
for m in manifest:
    d=root/m['relative_path']; log=d/'log.rhoReactingFoam'; timing=d/'ORFOZ_TIMING.txt'
    status='complete' if (d/'RUN_COMPLETE').exists() else ('failed' if (d/'RUN_FAILED').exists() else 'not_run')
    execution=clock=final_time=maxCo=''
    if log.exists():
        txt=log.read_text(errors='replace')
        vals=re.findall(r'ExecutionTime\s*=\s*([0-9.eE+-]+)\s*s\s+ClockTime\s*=\s*([0-9.eE+-]+)\s*s',txt)
        if vals: execution,clock=vals[-1]
        times=re.findall(r'^Time\s*=\s*([0-9.eE+-]+)',txt,re.M)
        if times: final_time=times[-1]
        cos=re.findall(r'Courant Number mean:\s*([0-9.eE+-]+)\s+max:\s*([0-9.eE+-]+)',txt)
        if cos: maxCo=cos[-1][1]
    tvals={}
    if timing.exists():
        for line in timing.read_text(errors='replace').splitlines():
            if '=' in line:
                k,v=line.split('=',1); tvals[k]=v
    rows.append({**m,'status':status,'node':tvals.get('node',''),'solver_exit_code':tvals.get('solver_exit_code',''),
                 'openfoam_version':tvals.get('openfoam_version',''),'mpi_library':tvals.get('mpi_library',''),
                 'solver_wall_s':tvals.get('solver_wall_s',''),'setup_wall_s':tvals.get('setup_wall_s',''),
                 'reconstruct_wall_s':tvals.get('reconstruct_wall_s',''),'total_case_wall_s':tvals.get('total_case_wall_s',''),
                 'final_time':final_time,'foam_execution_s':execution,'foam_clock_s':clock,'final_maxCo':maxCo})
fields=list(rows[0]) if rows else []
with (root/'campaign_summary.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
print(root/'campaign_summary.csv')
