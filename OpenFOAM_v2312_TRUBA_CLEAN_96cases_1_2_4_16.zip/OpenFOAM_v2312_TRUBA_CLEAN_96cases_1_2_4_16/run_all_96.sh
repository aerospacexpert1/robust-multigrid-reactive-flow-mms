#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; resume="${RESUME:-1}"
while IFS=, read -r id rel rest; do
  [[ "$id" == "case_id" ]] && continue
  d="$ROOT/$rel"
  [[ "$resume" == 1 && -f "$d/RUN_COMPLETE" ]] && { echo "SKIP $rel"; continue; }
  "$ROOT/run_case_orfoz.sh" "$d" || { [[ "${STOP_ON_FAILURE:-0}" == 1 ]] && exit 1 || true; }
done < "$ROOT/campaign_manifest.csv"
