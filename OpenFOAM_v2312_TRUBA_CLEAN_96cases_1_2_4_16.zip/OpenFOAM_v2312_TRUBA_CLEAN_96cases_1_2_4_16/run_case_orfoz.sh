#!/usr/bin/env bash
set -eo pipefail

if [[ $# -ne 1 ]]; then
    echo "Usage: $0 <case-directory>" >&2
    exit 2
fi

CASE_DIR="$(cd "$1" && pwd)"
cd "$CASE_DIR"

if [[ ! -f caseInfo.env ]]; then
    echo "ERROR: caseInfo.env not found in $CASE_DIR" >&2
    exit 2
fi

# shellcheck disable=SC1091
source ./caseInfo.env

if [[ -z "${CASE_ID:-}" || -z "${NPROCS:-}" ]]; then
    echo "ERROR: CASE_ID or NPROCS missing from caseInfo.env in $CASE_DIR" >&2
    exit 2
fi

mark_failed() {
    local status=$?
    touch RUN_FAILED
    echo "FAILED (${status}): ${CASE_ID:-unknown case}" >&2
    exit "$status"
}
trap mark_failed ERR

if [[ "${WM_PROJECT_VERSION:-}" != "v2312" ]]; then
    echo "ERROR: OpenFOAM v2312 environment is not active (WM_PROJECT_VERSION='${WM_PROJECT_VERSION:-unset}')." >&2
    exit 3
fi

for cmd in blockMesh checkMesh rhoReactingFoam; do
    command -v "$cmd" >/dev/null 2>&1 || {
        echo "ERROR: $cmd not found. Load apps/openfoam/v2312 first." >&2
        exit 127
    }
done

if [[ "$NPROCS" -gt 1 ]]; then
    for cmd in decomposePar reconstructPar mpirun; do
        command -v "$cmd" >/dev/null 2>&1 || {
            echo "ERROR: $cmd not found." >&2
            exit 127
        }
    done
fi

# Remove generated results only. Preserve 0/, constant/, system/ and metadata.
rm -f RUN_COMPLETE RUN_FAILED ORFOZ_TIMING.txt log.*
rm -rf processor* constant/polyMesh postProcessing
find . -mindepth 1 -maxdepth 1 -type d \
    -regextype posix-extended -regex './[0-9]+([.][0-9]+)?' \
    ! -name 0 -exec rm -rf {} +

HOST="$(hostname)"
CASE_START_NS="$(date +%s%N)"
START_ISO="$(date --iso-8601=seconds)"

{
    echo "case_id=$CASE_ID"
    echo "study_family=${STUDY_FAMILY:-unknown}"
    echo "physical_case=${PHYSICAL_CASE:-unknown}"
    echo "mesh_name=${MESH_NAME:-unknown}"
    echo "node=$HOST"
    echo "nprocs=$NPROCS"
    echo "start=$START_ISO"
    echo "openfoam_version=${WM_PROJECT_VERSION:-unknown}"
    echo "openfoam_build=${WM_OPTIONS:-unknown}"
    echo "mpi_library=${WM_MPLIB:-unknown}"
    echo "slurm_job_id=${SLURM_JOB_ID:-interactive}"
    echo "slurm_array_task_id=${SLURM_ARRAY_TASK_ID:-none}"
} > ORFOZ_TIMING.txt

SETUP_START_NS="$(date +%s%N)"
blockMesh > log.blockMesh 2>&1
checkMesh > log.checkMesh 2>&1

if [[ "$NPROCS" -gt 1 ]]; then
    decomposePar -force > log.decomposePar 2>&1
fi
SETUP_END_NS="$(date +%s%N)"

SOLVER_START_NS="$(date +%s%N)"
set +e
if [[ "$NPROCS" -eq 1 ]]; then
    rhoReactingFoam > log.rhoReactingFoam 2>&1
    STATUS=$?
else
    mpirun -np "$NPROCS" rhoReactingFoam -parallel > log.rhoReactingFoam 2>&1
    STATUS=$?
fi
set -e
SOLVER_END_NS="$(date +%s%N)"

SETUP_WALL="$(awk -v a="$SETUP_START_NS" -v b="$SETUP_END_NS" 'BEGIN {printf "%.9f", (b-a)/1e9}')"
SOLVER_WALL="$(awk -v a="$SOLVER_START_NS" -v b="$SOLVER_END_NS" 'BEGIN {printf "%.9f", (b-a)/1e9}')"

{
    echo "solver_exit_code=$STATUS"
    echo "setup_wall_s=$SETUP_WALL"
    echo "solver_wall_s=$SOLVER_WALL"
} >> ORFOZ_TIMING.txt

if [[ "$STATUS" -ne 0 ]]; then
    touch RUN_FAILED
    echo "FAILED ($STATUS): $CASE_ID" >&2
    exit "$STATUS"
fi

if ! grep -Eq '^[[:space:]]*End[[:space:]]*$' log.rhoReactingFoam; then
    touch RUN_FAILED
    echo "ERROR: solver exited without the OpenFOAM End marker: $CASE_ID" >&2
    exit 20
fi

RECON_START_NS="$(date +%s%N)"
if [[ "$NPROCS" -gt 1 ]]; then
    reconstructPar -latestTime > log.reconstructPar 2>&1
    [[ "${REMOVE_PROCESSORS_AFTER_RECONSTRUCT:-1}" == "1" ]] && rm -rf processor*
fi
RECON_END_NS="$(date +%s%N)"
CASE_END_NS="$(date +%s%N)"

RECON_WALL="$(awk -v a="$RECON_START_NS" -v b="$RECON_END_NS" 'BEGIN {printf "%.9f", (b-a)/1e9}')"
TOTAL_WALL="$(awk -v a="$CASE_START_NS" -v b="$CASE_END_NS" 'BEGIN {printf "%.9f", (b-a)/1e9}')"

{
    echo "reconstruct_wall_s=$RECON_WALL"
    echo "total_case_wall_s=$TOTAL_WALL"
    echo "end=$(date --iso-8601=seconds)"
} >> ORFOZ_TIMING.txt

touch RUN_COMPLETE
rm -f RUN_FAILED
trap - ERR

echo "COMPLETED: $CASE_ID solver_wall=${SOLVER_WALL}s total_case_wall=${TOTAL_WALL}s"
