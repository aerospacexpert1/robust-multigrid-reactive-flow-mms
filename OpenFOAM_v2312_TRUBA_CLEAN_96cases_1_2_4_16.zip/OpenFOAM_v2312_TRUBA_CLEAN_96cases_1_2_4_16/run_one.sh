#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
[[ $# -eq 1 ]] || { echo "Usage: $0 <case-id-or-relative-path>" >&2; exit 2; }
arg="$1"; case_dir=""
if [[ -d "$ROOT/$arg" ]]; then case_dir="$ROOT/$arg"; else
  rel=$(awk -F, -v id="$arg" 'NR>1 && $1==id {print $2; exit}' "$ROOT/campaign_manifest.csv")
  [[ -n "$rel" ]] && case_dir="$ROOT/$rel"
fi
[[ -n "$case_dir" && -d "$case_dir" ]] || { echo "Case not found: $arg" >&2; exit 2; }
exec "$ROOT/run_case_orfoz.sh" "$case_dir"
