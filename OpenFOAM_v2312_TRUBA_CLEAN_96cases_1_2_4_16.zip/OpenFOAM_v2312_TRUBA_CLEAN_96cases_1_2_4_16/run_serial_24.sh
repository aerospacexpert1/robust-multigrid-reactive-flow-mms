#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
awk -F, 'NR>1 && $16==1 {print $2}' "$ROOT/campaign_manifest.csv" | while read -r rel; do
  d="$ROOT/$rel"; [[ "${RESUME:-1}" == 1 && -f "$d/RUN_COMPLETE" ]] && { echo "SKIP $rel"; continue; }
  "$ROOT/run_case_orfoz.sh" "$d"
done
