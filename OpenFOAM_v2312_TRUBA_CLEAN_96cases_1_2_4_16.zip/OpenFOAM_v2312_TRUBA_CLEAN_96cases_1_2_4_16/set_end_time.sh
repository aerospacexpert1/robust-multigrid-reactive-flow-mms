#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; [[ $# -ge 1 && $# -le 2 ]] || { echo "Usage: $0 <endTime> [writeInterval]" >&2; exit 2; }
end="$1"; write="${2:-$1}"
tail -n +2 "$ROOT/campaign_manifest.csv" | cut -d, -f2 | while read -r rel; do
 f="$ROOT/$rel/system/controlDict"; sed -Ei "s/^(endTime[[:space:]]+)[^;]+;/\\1${end};/; s/^(writeInterval[[:space:]]+)[^;]+;/\\1${write};/" "$f"; done
echo "Updated 96 cases: endTime=$end writeInterval=$write"
