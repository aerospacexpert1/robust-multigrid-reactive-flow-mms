#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
tail -n +2 "$ROOT/campaign_manifest.csv" | cut -d, -f2 | while read -r rel; do f="$ROOT/$rel/system/controlDict"; end=$(awk '$1=="endTime" {gsub(";","",$2); print $2; exit}' "$f"); sed -Ei "s/^(writeInterval[[:space:]]+)[^;]+;/\\1${end};/" "$f"; done
