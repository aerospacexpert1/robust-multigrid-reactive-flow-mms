#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; interval="${1:-0.1}"
tail -n +2 "$ROOT/campaign_manifest.csv" | cut -d, -f2 | while read -r rel; do sed -Ei "s/^(writeInterval[[:space:]]+)[^;]+;/\\1${interval};/" "$ROOT/$rel/system/controlDict"; done
