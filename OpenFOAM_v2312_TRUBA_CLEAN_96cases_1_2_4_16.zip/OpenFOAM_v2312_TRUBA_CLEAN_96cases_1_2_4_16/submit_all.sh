#!/usr/bin/env bash
set -eo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
./verify_campaign.sh
job="$(sbatch --parsable openfoam96_orfoz_array.slurm)"
echo "Submitted full 96-run OpenFOAM campaign: $job"
echo "Monitor: squeue -j $job"
echo "Status:  ./check_campaign_status.sh"
