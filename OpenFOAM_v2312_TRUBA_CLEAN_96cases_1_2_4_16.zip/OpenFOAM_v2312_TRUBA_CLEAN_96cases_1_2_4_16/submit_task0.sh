#!/usr/bin/env bash
set -eo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
./verify_campaign.sh
job="$(sbatch --parsable --array=0 openfoam96_orfoz_array.slurm)"
echo "Submitted production task-0 test: $job"
echo "Monitor: squeue -j $job"
echo "Output:  tail -f slurm-OF2312_96_${job}_0.out"
