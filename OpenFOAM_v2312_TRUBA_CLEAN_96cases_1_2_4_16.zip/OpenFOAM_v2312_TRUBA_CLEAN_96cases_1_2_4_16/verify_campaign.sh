#!/usr/bin/env bash
set -eo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"

rows=$(($(wc -l < "$ROOT/campaign_manifest.csv")-1))
[[ "$rows" -eq 96 ]] || { echo "Expected 96 manifest rows, found $rows" >&2; exit 1; }
phys=$(wc -l < "$ROOT/physical_configurations.txt")
[[ "$phys" -eq 24 ]] || { echo "Expected 24 physical configurations, found $phys" >&2; exit 1; }
[[ $(find "$ROOT/cases" -type d -name C1 | wc -l) -eq 24 ]] || { echo "Expected 24 C1 directories" >&2; exit 1; }
[[ $(find "$ROOT/cases" -type d -name C2 | wc -l) -eq 24 ]] || { echo "Expected 24 C2 directories" >&2; exit 1; }
[[ $(find "$ROOT/cases" -type d -name C4 | wc -l) -eq 24 ]] || { echo "Expected 24 C4 directories" >&2; exit 1; }
[[ $(find "$ROOT/cases" -type d -name C16 | wc -l) -eq 24 ]] || { echo "Expected 24 C16 directories" >&2; exit 1; }
[[ $(find "$ROOT/cases" -type d -name C6 | wc -l) -eq 0 ]] || { echo "Unexpected C6 directories remain" >&2; exit 1; }

missing=0
while IFS=, read -r id rel family physical label vel stiff A beta Ta Hf mesh Nx Ny cells nprocs xl slot xr; do
  [[ "$id" == case_id ]] && continue
  d="$ROOT/$rel"
  for f in 0/U 0/p 0/P constant/reactions constant/thermo.compressibleGas system/blockMeshDict system/controlDict system/decomposeParDict caseInfo.env Allrun Allclean; do
    [[ -f "$d/$f" ]] || { echo "Missing $rel/$f"; missing=$((missing+1)); }
  done
  gotN=$(awk '$1=="numberOfSubdomains" {gsub(";","",$2); print $2}' "$d/system/decomposeParDict")
  [[ "$gotN" == "$nprocs" ]] || { echo "Bad subdomain count: $rel ($gotN != $nprocs)"; missing=$((missing+1)); }
  gotA=$(awk '$1=="A" {gsub(";","",$2); print $2}' "$d/constant/reactions")
  gotB=$(awk '$1=="beta" {gsub(";","",$2); print $2}' "$d/constant/reactions")
  gotT=$(awk '$1=="Ta" {gsub(";","",$2); print $2}' "$d/constant/reactions")
  [[ "$gotA" == "$A" && "$gotB" == "$beta" && "$gotT" == "$Ta" ]] || { echo "Reaction mismatch: $rel"; missing=$((missing+1)); }
  gotH=$(awk '$1=="Hf" {gsub(";","",$2); print $2; exit}' "$d/constant/thermo.compressibleGas")
  [[ "$gotH" == "$Hf" ]] || { echo "Hf mismatch: $rel ($gotH)"; missing=$((missing+1)); }
done < "$ROOT/campaign_manifest.csv"
[[ "$missing" -eq 0 ]] || exit 1

# Batch scripts must not depend on foamVersion or nounset.
if grep -Eq '^[[:space:]]*foamVersion([[:space:]]|$)' "$ROOT/openfoam96_orfoz_array.slurm" "$ROOT/run_case_orfoz.sh"; then
    echo "ERROR: production scripts contain an executable foamVersion call" >&2
    exit 1
fi
if grep -q 'set -euo' "$ROOT/openfoam96_orfoz_array.slurm" "$ROOT/run_case_orfoz.sh"; then
    echo "ERROR: production scripts still use set -euo" >&2
    exit 1
fi

for f in "$ROOT"/*.sh "$ROOT"/*.slurm; do
    bash -n "$f" || exit 1
done

python3 -m py_compile "$ROOT/collect_summary.py" "$ROOT/analyze_scaling.py"

echo "Verified: 96 cases, 24 physical configurations, ranks 1/2/4/16, reaction matrix, matched Hf, and clean v2312 batch scripts."
