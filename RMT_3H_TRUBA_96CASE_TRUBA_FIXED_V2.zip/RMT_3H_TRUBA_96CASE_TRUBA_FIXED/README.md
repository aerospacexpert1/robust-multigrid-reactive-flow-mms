# RMT 3h / 9-shift Reacting-Flow TRUBA Campaign — Orfoz Fixed

This is the directly usable TRUBA/Orfoz campaign for the pressure-block
RMT reacting-flow solver.

## Solver architecture — unchanged

Pressure:
- Robust Multigrid Technique (RMT)
- factor-three hierarchy
- 2D 3 x 3 shifted coarse-grid family
- 9 shifted multiple coarse-grid corrections
- recursive multiple coarse-grid correction
- safeguarded correction amplitude / line search
- fine-grid RBGS post smoothing

Species and enthalpy retain the existing stable variable-coefficient RBGS
implementation. The solver physics/numerical model in `src/opposedflow_rmt3h.c`
is unchanged by the TRUBA scheduler fix.

## Campaign — unchanged

Families:
- FLOW: 48 cases
- STIFFNESS: 48 cases

Meshes:
- M1 = 108 x 36
- M2 = 216 x 72
- M3 = 432 x 144
- M4 = 864 x 288

Actual OpenMP benchmark thread levels:
- T1  -> `OMP_NUM_THREADS=1`
- T2  -> `OMP_NUM_THREADS=2`
- T4  -> `OMP_NUM_THREADS=4`
- T16 -> `OMP_NUM_THREADS=16`

Total: 96 cases.

The FLOW and REACTION_STIFFNESS values are read from `config/campaign.env`.
Final physical time remains 2.0 s.

## Important Orfoz scheduler rule

Orfoz requires jobs to request 56 or 112 CPUs per node. This package uses:

    --nodes=1
    --ntasks=1
    --cpus-per-task=56

for campaign array jobs, single-index submissions, task-0 submissions, and the
optional Slurm build job.

**The 56-CPU Slurm allocation is not the benchmark thread count.**
`run_case.sh` reads the selected manifest row and sets `OMP_NUM_THREADS` and
`OMP_THREAD_LIMIT` to the real benchmark value 1, 2, 4, or 16.

The full campaign is submitted as four clean thread groups:
- T1 indices  `0-92:4`
- T2 indices  `1-93:4`
- T4 indices  `2-94:4`
- T16 indices `3-95:4`

Each group contains 24 cases. Array concurrency is limited to 3 jobs at a time,
and the four thread groups are chained sequentially to avoid flooding the QOS
with 56-CPU jobs.

## Normal TRUBA use

After copying and unzipping the package in scratch:

    cd RMT_3H_TRUBA_96CASE_TRUBA_FIXED
    ./submit_all.sh

`submit_all.sh` performs:
1. manifest rebuild,
2. local GCC/OpenMP build,
3. campaign verification,
4. submission of the T1/T2/T4/T16 arrays.

Monitor jobs with:

    squeue -u $USER

Check campaign progress with:

    ./check_campaign_status.sh

## Single-case submission

Submit manifest index 0:

    ./submit_task0.sh

Submit any index 0..95:

    ./submit_index.sh INDEX

These entry points also request the Orfoz-compatible 56-CPU allocation, while
the selected case still runs at its manifest thread count.

## Optional batch build

If a Slurm build job is preferred instead of `./build.sh`:

    sbatch build_rmt.slurm

The build job also requests 56 CPUs to satisfy the Orfoz allocation policy;
GCC itself remains a normal compiler process.

## Timing and result collection — unchanged

The 96-case timing campaign runs with:

    -fieldOutput 0

so field writing is excluded from the timed benchmark. Total solver wall time
and pressure/RMT wall time remain separately reported.

Collect results:

    python3 collect_summary.py

Expected summary size:

    97 campaign_summary.csv lines

(1 header + 96 cases.)

Analyze scaling:

    python3 analyze_scaling.py

Representative field output can still be generated outside the timing campaign:

    ./run_physical_case.sh TASK_ID

## Validation

The package includes `verify_campaign.sh`, which checks the 96-case manifest,
48/48 family split, meshes, 1/2/4/16 thread levels, RMT architecture markers,
field-output timing setting, separate RMT timing instrumentation, and the
56-CPU Orfoz allocation versus manifest-controlled OpenMP execution.
