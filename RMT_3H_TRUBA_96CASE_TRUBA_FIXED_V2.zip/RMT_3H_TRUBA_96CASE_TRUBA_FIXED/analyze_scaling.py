#!/usr/bin/env python3

import csv
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
src = ROOT / "campaign_summary.csv"

if not src.exists():
    raise SystemExit(
        "campaign_summary.csv not found. "
        "Run python3 collect_summary.py first."
    )

rows = []

with src.open(newline="") as f:
    rows = list(csv.DictReader(f))

groups = defaultdict(dict)

for r in rows:
    key = (
        r["family"],
        r["level"],
        r["mesh"],
        r["Nx"],
        r["Ny"],
    )

    groups[key][int(r["threads"])] = r

out_rows = []

for key in sorted(groups):
    fam, level, mesh, nx, ny = key
    data = groups[key]

    if 1 not in data:
        continue

    total1 = float(data[1]["total_wall_s"])
    p1 = float(data[1]["pressure_wall_s"])

    row = {
        "family": fam,
        "level": level,
        "mesh": mesh,
        "Nx": nx,
        "Ny": ny,
    }

    for nth in [1, 2, 4, 16]:

        rr = data.get(nth)

        if rr is None:
            row[f"total_T{nth}_s"] = ""
            row[f"total_S{nth}"] = ""
            row[f"total_E{nth}"] = ""

            row[f"pressure_T{nth}_s"] = ""
            row[f"pressure_S{nth}"] = ""
            row[f"pressure_E{nth}"] = ""

            continue

        total = float(rr["total_wall_s"])
        pressure = float(rr["pressure_wall_s"])

        St = total1 / total if total > 0 else 0.0
        Et = St / nth

        Sp = p1 / pressure if pressure > 0 else 0.0
        Ep = Sp / nth

        row[f"total_T{nth}_s"] = f"{total:.17g}"
        row[f"total_S{nth}"] = f"{St:.17g}"
        row[f"total_E{nth}"] = f"{Et:.17g}"

        row[f"pressure_T{nth}_s"] = f"{pressure:.17g}"
        row[f"pressure_S{nth}"] = f"{Sp:.17g}"
        row[f"pressure_E{nth}"] = f"{Ep:.17g}"

    out_rows.append(row)

if not out_rows:
    raise SystemExit(
        "No complete thread groups found."
    )

dest = ROOT / "scaling_summary.csv"

fieldnames = list(out_rows[0].keys())

with dest.open("w", newline="") as f:
    writer = csv.DictWriter(
        f,
        fieldnames=fieldnames,
    )

    writer.writeheader()
    writer.writerows(out_rows)

print(dest)
print("Scaling groups:", len(out_rows))
