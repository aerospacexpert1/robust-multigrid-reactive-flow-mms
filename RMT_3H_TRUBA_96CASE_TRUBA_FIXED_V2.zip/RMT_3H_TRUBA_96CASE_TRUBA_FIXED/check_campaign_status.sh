#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

completed="$(find "${ROOT}/results" -name RUN_COMPLETE -type f | wc -l)"
failed="$(find "${ROOT}/results" -name RUN_FAILED -type f | wc -l)"
started="$(find "${ROOT}/results" -name metadata.txt -type f | wc -l)"
summaries="$(find "${ROOT}/results" -name case_summary.csv -type f | wc -l)"

echo "Completed : ${completed} / 96"
echo "Failed    : ${failed}"
echo "Started   : ${started} / 96"
echo "Summaries : ${summaries} / 96"

echo
echo "Slurm queue:"
squeue -u "${USER}" || true
