#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "This removes RMT campaign result directories and campaign summary files."
echo "Source and configuration files are preserved."

read -r -p "Type DELETE to continue: " answer

if [[ "${answer}" != "DELETE" ]]; then
    echo "Cancelled."
    exit 0
fi

rm -rf "${ROOT}/results/FLOW"
rm -rf "${ROOT}/results/STIFFNESS"

mkdir -p "${ROOT}/results/FLOW"
mkdir -p "${ROOT}/results/STIFFNESS"

rm -f \
    "${ROOT}/campaign_summary.csv" \
    "${ROOT}/scaling_summary.csv"

echo "Cleaned."
