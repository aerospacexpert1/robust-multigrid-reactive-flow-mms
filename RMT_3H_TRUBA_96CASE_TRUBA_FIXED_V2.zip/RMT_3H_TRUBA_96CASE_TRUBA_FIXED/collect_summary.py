#!/usr/bin/env python3

import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent

files = sorted(
    (ROOT / "results").rglob("case_summary.csv")
)

if not files:
    raise SystemExit(
        "No case_summary.csv files found under results/"
    )

rows = []

for file in files:
    with file.open(newline="") as f:
        reader = csv.DictReader(f)

        for row in reader:
            rows.append(row)

rows.sort(
    key=lambda r: int(r["task_id"])
)

out = ROOT / "campaign_summary.csv"

fieldnames = list(rows[0].keys())

with out.open("w", newline="") as f:
    writer = csv.DictWriter(
        f,
        fieldnames=fieldnames,
    )

    writer.writeheader()
    writer.writerows(rows)

print(out)
print("Completed summaries:", len(rows))
