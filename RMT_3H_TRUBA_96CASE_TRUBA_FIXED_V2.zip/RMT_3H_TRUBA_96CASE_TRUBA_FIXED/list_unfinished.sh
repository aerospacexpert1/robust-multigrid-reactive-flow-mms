#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MANIFEST="${ROOT}/campaign_manifest.csv"

python3 - "${ROOT}" "${MANIFEST}" <<'PY'
import csv
import sys
from pathlib import Path

root = Path(sys.argv[1])
manifest = Path(sys.argv[2])

with manifest.open(newline="") as f:
    rows = list(csv.DictReader(f))

for r in rows:
    d = (
        root /
        "results" /
        r["family"] /
        r["level"] /
        r["mesh"] /
        f"T{r['threads']}"
    )

    if not (d / "RUN_COMPLETE").exists():
        print(
            r["task_id"],
            r["case_id"],
            str(d)
        )
PY
