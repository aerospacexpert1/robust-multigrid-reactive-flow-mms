#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${ROOT}"

find \
    src tools config \
    -type f \
    -print0 \
    | sort -z \
    | xargs -0 sha256sum \
    > SHA256SUMS

echo "${ROOT}/SHA256SUMS"
