#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

python3 "${ROOT}/tools/make_manifest.py"

echo
echo "Manifest line count:"
wc -l "${ROOT}/campaign_manifest.csv"

echo
echo "Family counts:"
awk -F, '
NR>1 {
    count[$3]++
}
END {
    for (k in count)
        print k, count[k]
}
' "${ROOT}/campaign_manifest.csv"
