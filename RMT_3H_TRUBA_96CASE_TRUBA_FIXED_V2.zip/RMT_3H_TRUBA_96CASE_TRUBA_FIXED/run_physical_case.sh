#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN="${ROOT}/build/opposedflow_rmt3h"

TASK_ID="${1:-0}"

ROW="$(sed -n "$((TASK_ID + 2))p" "${ROOT}/campaign_manifest.csv")"

IFS=',' read -r \
    task_id \
    case_id \
    family \
    level \
    mesh \
    Nx \
    Ny \
    threads \
    vIn \
    arrA \
    arrBeta \
    arrTa \
    endTime \
    <<< "${ROW}"

OUT="${ROOT}/physical_outputs/${case_id}"

mkdir -p "${OUT}"
cd "${OUT}"

export OMP_NUM_THREADS="${threads}"
export OMP_DYNAMIC=FALSE
export OMP_PROC_BIND=close
export OMP_PLACES=cores

"${BIN}" \
    -Nx "${Nx}" \
    -Ny "${Ny}" \
    -end "${endTime}" \
    -dt 1.0e-7 \
    -maxCo 0.05 \
    -vIn "${vIn}" \
    -arrA "${arrA}" \
    -arrBeta "${arrBeta}" \
    -arrTa "${arrTa}" \
    -pCycles 4 \
    -sCycles 4 \
    -rmtLevels 4 \
    -rmtPost 3 \
    -rmtCoarseSweeps 48 \
    -rmtCoarseRepeats 1 \
    -rmtOmega 0.005 \
    -fieldOutput 1 \
    2>&1 | tee physical.log
