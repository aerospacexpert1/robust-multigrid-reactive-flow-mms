#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN="${ROOT}/build/opposedflow_rmt3h"

if [[ ! -x "${BIN}" ]]; then
    ./build.sh
fi

SMOKE="${ROOT}/tests/smoke"

rm -rf "${SMOKE}"
mkdir -p "${SMOKE}"

cd "${SMOKE}"

export OMP_NUM_THREADS=2
export OMP_DYNAMIC=FALSE
export OMP_PROC_BIND=close
export OMP_PLACES=cores

"${BIN}" \
    -Nx 108 \
    -Ny 36 \
    -end 2.0e-6 \
    -dt 1.0e-7 \
    -maxCo 0.05 \
    -vIn 0.10 \
    -arrA 1.0e7 \
    -arrBeta 5.0 \
    -arrTa 1000.0 \
    -pCycles 2 \
    -sCycles 2 \
    -rmtLevels 4 \
    -rmtPost 3 \
    -rmtCoarseSweeps 12 \
    -rmtCoarseRepeats 1 \
    -rmtOmega 0.005 \
    -fieldOutput 0 \
    2>&1 | tee smoke.log

grep "RMT_RUN_SUMMARY" smoke.log

echo
echo "Smoke test completed."
