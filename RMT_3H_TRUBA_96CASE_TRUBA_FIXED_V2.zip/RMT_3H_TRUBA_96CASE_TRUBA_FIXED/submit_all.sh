#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${ROOT}"
mkdir -p logs

# Orfoz scheduler allocation.  This is NOT the OpenMP benchmark thread count.
ALLOC_CPUS=56
ARRAY_CONCURRENCY=3

echo "============================================================"
echo "RMT-3h / 9-shift TRUBA campaign"
echo "============================================================"
echo "Orfoz allocation per array task : ${ALLOC_CPUS} CPUs"
echo "Benchmark OpenMP threads        : manifest T1/T2/T4/T16"
echo "Array concurrency               : ${ARRAY_CONCURRENCY}"

echo
echo "1) Rebuilding manifest..."
./rebuild_manifest.sh

echo
echo "2) Building solver..."
./build.sh

echo
echo "3) Verifying campaign..."
./verify_campaign.sh

echo
echo "4) Submitting T1 cases..."

J1=$(
sbatch --parsable \
    --nodes=1 \
    --ntasks=1 \
    --cpus-per-task="${ALLOC_CPUS}" \
    --job-name=RMT3H_T1 \
    --array="0-92:4%${ARRAY_CONCURRENCY}" \
    rmt_96_array.slurm
)

echo "T1 array job ID: ${J1}"

echo
echo "5) Submitting T2 cases..."

J2=$(
sbatch --parsable \
    --dependency=afterany:${J1} \
    --nodes=1 \
    --ntasks=1 \
    --cpus-per-task="${ALLOC_CPUS}" \
    --job-name=RMT3H_T2 \
    --array="1-93:4%${ARRAY_CONCURRENCY}" \
    rmt_96_array.slurm
)

echo "T2 array job ID: ${J2}"

echo
echo "6) Submitting T4 cases..."

J4=$(
sbatch --parsable \
    --dependency=afterany:${J2} \
    --nodes=1 \
    --ntasks=1 \
    --cpus-per-task="${ALLOC_CPUS}" \
    --job-name=RMT3H_T4 \
    --array="2-94:4%${ARRAY_CONCURRENCY}" \
    rmt_96_array.slurm
)

echo "T4 array job ID: ${J4}"

echo
echo "7) Submitting T16 cases..."

J16=$(
sbatch --parsable \
    --dependency=afterany:${J4} \
    --nodes=1 \
    --ntasks=1 \
    --cpus-per-task="${ALLOC_CPUS}" \
    --job-name=RMT3H_T16 \
    --array="3-95:4%${ARRAY_CONCURRENCY}" \
    rmt_96_array.slurm
)

echo "T16 array job ID: ${J16}"

echo
echo "============================================================"
echo "Submitted successfully"
echo "============================================================"
echo "T1  : ${J1}"
echo "T2  : ${J2}"
echo "T4  : ${J4}"
echo "T16 : ${J16}"
echo
echo "Monitor with:"
echo "  squeue -u ${USER}"
echo
echo "Campaign status:"
echo "  ./check_campaign_status.sh"
echo "============================================================"
