#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
IDX="${1:?usage: ./submit_index.sh INDEX}"

if ! [[ "${IDX}" =~ ^[0-9]+$ ]] || (( IDX < 0 || IDX > 95 )); then
    echo "INDEX must be an integer in 0..95" >&2
    exit 2
fi

cd "${ROOT}"
mkdir -p logs

# Orfoz allocation is 56 CPUs, while run_case.sh selects the actual
# OpenMP benchmark thread count (1/2/4/16) from the manifest row.
sbatch \
    --nodes=1 \
    --ntasks=1 \
    --cpus-per-task=56 \
    --array="${IDX}-${IDX}" \
    rmt_96_array.slurm
