#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${ROOT}"
mkdir -p logs

# Scheduler allocation is fixed at 56 CPUs; task 0 itself remains OMP_NUM_THREADS=1.
sbatch \
    --nodes=1 \
    --ntasks=1 \
    --cpus-per-task=56 \
    --array=0-0 \
    rmt_96_array.slurm
