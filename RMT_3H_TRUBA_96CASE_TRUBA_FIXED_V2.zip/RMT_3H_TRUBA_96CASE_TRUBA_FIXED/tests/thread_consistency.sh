#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BIN="${ROOT}/build/opposedflow_rmt3h"
TESTROOT="${ROOT}/tests/thread_consistency"

rm -rf "${TESTROOT}"
mkdir -p "${TESTROOT}/T1"
mkdir -p "${TESTROOT}/T4"

run_test () {

    nth="$1"
    dir="$2"

    cd "${dir}"

    export OMP_NUM_THREADS="${nth}"
    export OMP_DYNAMIC=FALSE
    export OMP_PROC_BIND=close
    export OMP_PLACES=cores

    "${BIN}" \
        -Nx 108 \
        -Ny 36 \
        -end 5.0e-5 \
        -dt 1.0e-7 \
        -maxCo 0.05 \
        -vIn 0.10 \
        -arrA 1.0e7 \
        -arrBeta 5.0 \
        -arrTa 1000.0 \
        -pCycles 4 \
        -sCycles 4 \
        -rmtLevels 4 \
        -rmtPost 3 \
        -rmtCoarseSweeps 48 \
        -rmtCoarseRepeats 1 \
        -rmtOmega 0.005 \
        -fieldOutput 0 \
        > solver.log 2>&1

    grep "RMT_RUN_SUMMARY" solver.log
}

run_test 1 "${TESTROOT}/T1"
run_test 4 "${TESTROOT}/T4"

python3 - "${TESTROOT}" <<'PY'
import sys
from pathlib import Path

root = Path(sys.argv[1])

def read_summary(path):
    lines = [
        x for x in path.read_text().splitlines()
        if x.startswith("RMT_RUN_SUMMARY")
    ]

    if not lines:
        raise RuntimeError(f"No summary in {path}")

    d = {}

    for item in lines[-1].split()[1:]:
        k, v = item.split("=", 1)
        d[k] = float(v)

    return d

a = read_summary(root/"T1"/"solver.log")
b = read_summary(root/"T4"/"solver.log")

fields = [
    "final_time",
    "Tmax",
    "YPmax",
    "YOmax",
    "YFmax",
]

print()
print("============================================================")
print("THREAD CONSISTENCY")
print("============================================================")

failed = False

for key in fields:

    x = a[key]
    y = b[key]

    scale = max(abs(x), abs(y), 1.0e-30)
    rel = abs(x-y)/scale

    print(
        f"{key:15s} "
        f"T1={x:.17g} "
        f"T4={y:.17g} "
        f"relDiff={rel:.3e}"
    )

    if rel > 1.0e-10:
        failed = True

print()
print(
    "T1 total wall:",
    a["total_wall_s"],
    "s"
)

print(
    "T4 total wall:",
    b["total_wall_s"],
    "s"
)

print(
    "T1 pressure wall:",
    a["pressure_wall_s"],
    "s"
)

print(
    "T4 pressure wall:",
    b["pressure_wall_s"],
    "s"
)

if failed:
    print()
    print("FAIL: thread-dependent physical result detected")
    raise SystemExit(2)

print()
print("PASS: T1 and T4 physical summaries are consistent")
PY
