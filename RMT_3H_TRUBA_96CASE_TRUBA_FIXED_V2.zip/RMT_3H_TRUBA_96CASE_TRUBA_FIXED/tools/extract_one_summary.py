#!/usr/bin/env python3

import csv
import re
import sys
from pathlib import Path

if len(sys.argv) != 14:
    raise SystemExit(
        "usage: extract_one_summary.py "
        "outdir task_id case_id family level mesh Nx Ny threads "
        "vIn arrA arrBeta arrTa"
    )

(
    _,
    outdir,
    task_id,
    case_id,
    family,
    level,
    mesh,
    Nx,
    Ny,
    threads,
    vIn,
    arrA,
    arrBeta,
    arrTa,
) = sys.argv

outdir = Path(outdir)
log = outdir / "solver.log"

if not log.exists():
    raise SystemExit(f"missing {log}")

text = log.read_text(errors="replace")

matches = re.findall(
    r"RMT_RUN_SUMMARY\s+([^\n\r]+)",
    text
)

if not matches:
    raise SystemExit(
        f"RMT_RUN_SUMMARY not found in {log}"
    )

payload = matches[-1]

metrics = {}

for token in payload.split():
    if "=" not in token:
        continue

    key, value = token.split("=", 1)
    metrics[key] = value

row = {
    "task_id": task_id,
    "case_id": case_id,
    "solver": "RMT_3H_9SHIFT_PRESSURE",
    "family": family,
    "level": level,
    "mesh": mesh,
    "Nx": Nx,
    "Ny": Ny,
    "threads": threads,
    "vIn": vIn,
    "arrA": arrA,
    "arrBeta": arrBeta,
    "arrTa": arrTa,
    "final_time_s": metrics.get("final_time", ""),
    "total_wall_s": metrics.get("total_wall_s", ""),
    "pressure_wall_s": metrics.get("pressure_wall_s", ""),
    "pressure_calls": metrics.get("pressure_calls", ""),
    "Tmax": metrics.get("Tmax", ""),
    "YPmax": metrics.get("YPmax", ""),
    "YOmax": metrics.get("YOmax", ""),
    "YFmax": metrics.get("YFmax", ""),
}

dest = outdir / "case_summary.csv"

with dest.open("w", newline="") as f:
    writer = csv.DictWriter(
        f,
        fieldnames=list(row.keys()),
    )

    writer.writeheader()
    writer.writerow(row)

print(dest)
