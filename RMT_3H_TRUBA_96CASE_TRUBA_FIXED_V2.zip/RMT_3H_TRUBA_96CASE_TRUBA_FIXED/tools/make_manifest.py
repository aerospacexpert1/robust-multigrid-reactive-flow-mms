#!/usr/bin/env python3

import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENV_FILE = ROOT / "config" / "campaign.env"


def load_env(path):
    data = {}

    for raw in path.read_text().splitlines():
        line = raw.strip()

        if not line or line.startswith("#"):
            continue

        if "=" not in line:
            continue

        key, value = line.split("=", 1)
        data[key.strip()] = value.strip()

    return data


cfg = load_env(ENV_FILE)

required = [
    "END_TIME",
    "DT0",
    "MAX_CO",

    "FLOW_V_LOW",
    "FLOW_V_INTERMEDIATE",
    "FLOW_V_HIGH",
    "FLOW_A",
    "FLOW_BETA",
    "FLOW_TA",

    "STIFFNESS_V",

    "A_LOW",
    "BETA_LOW",
    "TA_LOW",

    "A_INTERMEDIATE",
    "BETA_INTERMEDIATE",
    "TA_INTERMEDIATE",

    "A_HIGH",
    "BETA_HIGH",
    "TA_HIGH",
]

missing = [
    key for key in required
    if key not in cfg or cfg[key] == ""
]

if missing:
    print("ERROR: missing campaign.env values:")

    for key in missing:
        print("   ", key)

    sys.exit(2)


meshes = [
    ("M1", 108, 36),
    ("M2", 216, 72),
    ("M3", 432, 144),
    ("M4", 864, 288),
]

threads = [1, 2, 4, 16]


flow_levels = [
    (
        "LOW",
        float(cfg["FLOW_V_LOW"]),
    ),
    (
        "NOMINAL",
        float(cfg["FLOW_V_INTERMEDIATE"]),
    ),
    (
        "HIGH",
        float(cfg["FLOW_V_HIGH"]),
    ),
]


stiffness_levels = [
    (
        "LOW",
        float(cfg["A_LOW"]),
        float(cfg["BETA_LOW"]),
        float(cfg["TA_LOW"]),
    ),
    (
        "INTERMEDIATE",
        float(cfg["A_INTERMEDIATE"]),
        float(cfg["BETA_INTERMEDIATE"]),
        float(cfg["TA_INTERMEDIATE"]),
    ),
    (
        "HIGH",
        float(cfg["A_HIGH"]),
        float(cfg["BETA_HIGH"]),
        float(cfg["TA_HIGH"]),
    ),
]


end_time = float(cfg["END_TIME"])

rows = []
task = 0


# ==========================================================================
# FLOW INTENSITY
# ==========================================================================

for level, vin in flow_levels:

    for mesh, nx, ny in meshes:

        for nth in threads:

            case_id = (
                f"FLOW_{level}_{mesh}_T{nth}"
            )

            rows.append({
                "task_id": task,
                "case_id": case_id,
                "family": "FLOW",
                "level": level,
                "mesh": mesh,
                "Nx": nx,
                "Ny": ny,
                "threads": nth,
                "vIn": f"{vin:.17g}",
                "arrA": f"{float(cfg['FLOW_A']):.17g}",
                "arrBeta": f"{float(cfg['FLOW_BETA']):.17g}",
                "arrTa": f"{float(cfg['FLOW_TA']):.17g}",
                "endTime": f"{end_time:.17g}",
            })

            task += 1


# ==========================================================================
# REACTION STIFFNESS
# ==========================================================================

for level, arrA, beta, ta in stiffness_levels:

    for mesh, nx, ny in meshes:

        for nth in threads:

            case_id = (
                f"STIFFNESS_{level}_{mesh}_T{nth}"
            )

            rows.append({
                "task_id": task,
                "case_id": case_id,
                "family": "STIFFNESS",
                "level": level,
                "mesh": mesh,
                "Nx": nx,
                "Ny": ny,
                "threads": nth,
                "vIn": f"{float(cfg['STIFFNESS_V']):.17g}",
                "arrA": f"{arrA:.17g}",
                "arrBeta": f"{beta:.17g}",
                "arrTa": f"{ta:.17g}",
                "endTime": f"{end_time:.17g}",
            })

            task += 1


assert len(rows) == 96
assert task == 96


fieldnames = [
    "task_id",
    "case_id",
    "family",
    "level",
    "mesh",
    "Nx",
    "Ny",
    "threads",
    "vIn",
    "arrA",
    "arrBeta",
    "arrTa",
    "endTime",
]


manifest = ROOT / "campaign_manifest.csv"

with manifest.open("w", newline="") as f:

    writer = csv.DictWriter(
        f,
        fieldnames=fieldnames,
    )

    writer.writeheader()
    writer.writerows(rows)


# ==========================================================================
# Physical configuration matrix
# ==========================================================================

phys_rows = []
seen = set()

for row in rows:

    key = (
        row["family"],
        row["level"],
        row["mesh"],
    )

    if key in seen:
        continue

    seen.add(key)

    phys_rows.append({
        "family": row["family"],
        "level": row["level"],
        "mesh": row["mesh"],
        "Nx": row["Nx"],
        "Ny": row["Ny"],
        "vIn": row["vIn"],
        "arrA": row["arrA"],
        "arrBeta": row["arrBeta"],
        "arrTa": row["arrTa"],
        "endTime": row["endTime"],
    })


physical = ROOT / "physical_configuration_matrix.csv"

with physical.open("w", newline="") as f:

    writer = csv.DictWriter(
        f,
        fieldnames=[
            "family",
            "level",
            "mesh",
            "Nx",
            "Ny",
            "vIn",
            "arrA",
            "arrBeta",
            "arrTa",
            "endTime",
        ],
    )

    writer.writeheader()
    writer.writerows(phys_rows)


print(manifest)
print("Rows:", len(rows))

print(physical)
print("Physical configurations:", len(phys_rows))

print()
print("FLOW chemistry:")
print(
    "A =", cfg["FLOW_A"],
    "beta =", cfg["FLOW_BETA"],
    "Ta =", cfg["FLOW_TA"]
)

print()
print("REACTION_STIFFNESS:")

for level, arrA, beta, ta in stiffness_levels:
    print(
        level,
        "A =", arrA,
        "beta =", beta,
        "Ta =", ta
    )
