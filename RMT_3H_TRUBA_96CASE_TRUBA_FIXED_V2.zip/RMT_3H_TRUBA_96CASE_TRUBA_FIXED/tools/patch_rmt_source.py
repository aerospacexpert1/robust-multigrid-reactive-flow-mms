#!/usr/bin/env python3

from pathlib import Path
import re
import shutil
import sys

if len(sys.argv) != 2:
    raise SystemExit(
        "usage: patch_rmt_source.py src/opposedflow_rmt3h.c"
    )

path = Path(sys.argv[1])
backup = path.with_suffix(path.suffix + ".prepatch")

if not backup.exists():
    shutil.copy2(path, backup)

s = path.read_text()

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def replace_once(old, new, label):
    global s
    require(old in s, f"Patch target not found: {label}")
    s = s.replace(old, new, 1)
    print(f"[patch] {label}")

###############################################################################
# 1. OpenMP include
###############################################################################

if "#include <omp.h>" not in s:
    replace_once(
        "#include <time.h>",
        """#include <time.h>

#ifdef _OPENMP
#include <omp.h>
#endif""",
        "OpenMP header"
    )

###############################################################################
# 2. Runtime / timing globals
###############################################################################

marker = "static double g_rmtOmega = 0.005;"

if "g_pressure_rmt_wall_seconds" not in s:
    require(marker in s, "Could not find g_rmtOmega")

    extra = r'''
static double g_pressure_rmt_wall_seconds = 0.0;
static long long g_pressure_rmt_calls = 0;
static int g_fieldOutput = 1;

static double rmt_wall_now(void) {
#ifdef _OPENMP
    return omp_get_wtime();
#else
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (double)ts.tv_sec + 1.0e-9*(double)ts.tv_nsec;
#endif
}
'''

    s = s.replace(marker, marker + "\n" + extra, 1)
    print("[patch] pressure timing globals")

###############################################################################
# 3. New command-line arguments:
#
#      -vIn
#      -arrA
#      -arrBeta
#      -arrTa
#      -fieldOutput
###############################################################################

if '"-vIn"' not in s:

    target = (
        'else if (!strcmp(argv[i], "-rmtOmega") && i+1<argc) '
        'g_rmtOmega = atof(argv[++i]);'
    )

    require(target in s, "Could not locate parse_args rmtOmega line")

    replacement = target + r'''
        else if (!strcmp(argv[i], "-vIn") && i+1<argc) {
            double vmag = fabs(atof(argv[++i]));
            ph->vFuel = +vmag;
            ph->vOx   = -vmag;
        }
        else if (!strcmp(argv[i], "-arrA") && i+1<argc)
            ph->A = atof(argv[++i]);
        else if (!strcmp(argv[i], "-arrBeta") && i+1<argc)
            ph->beta = atof(argv[++i]);
        else if (!strcmp(argv[i], "-arrTa") && i+1<argc)
            ph->Ta = atof(argv[++i]);
        else if (!strcmp(argv[i], "-fieldOutput") && i+1<argc)
            g_fieldOutput = atoi(argv[++i]) != 0;'''

    s = s.replace(target, replacement, 1)
    print("[patch] runtime vIn / Arrhenius / fieldOutput arguments")

###############################################################################
# 4. Disable expensive VTI / centerline writes in timing campaign when
#    -fieldOutput 0 is requested.
###############################################################################

old_write = "write_vti(&g,&ph,&f,time); write_centerline_csv(&g,&f,time);"

if old_write in s and "if (g_fieldOutput)" not in s:
    s = s.replace(
        old_write,
        """if (g_fieldOutput) {
                write_vti(&g,&ph,&f,time);
                write_centerline_csv(&g,&f,time);
            }""",
        1
    )
    print("[patch] field-output timing exclusion")

###############################################################################
# 5. Parallel RMT residual evaluation.
###############################################################################

start_fn = s.find("static void rmt_compute_residual(")
end_fn = s.find("\nstatic int rmt_shift_count", start_fn)

if start_fn < 0 or end_fn < 0:
    raise RuntimeError(
        "Could not locate rmt_compute_residual by function markers"
    )

fn = s[start_fn:end_fn]

loop = "    for (int i=1; i<=nx; ++i) for (int j=1; j<=ny; ++j) {"

pragma = """#ifdef _OPENMP
#pragma omp parallel for collapse(2) schedule(static)
#endif
"""

if "#pragma omp parallel for collapse(2) schedule(static)" not in fn:
    if loop not in fn:
        raise RuntimeError(
            "Could not locate residual loop inside rmt_compute_residual"
        )

    fn = fn.replace(
        loop,
        pragma + loop,
        1
    )

    s = s[:start_fn] + fn + s[end_fn:]

print("[patch] parallel RMT residual")

###############################################################################
# 6. Parallelize the nine shifted coarse-grid families on the TOP RMT level.
#
# Important:
# Each (sx,sy) family injects into a different fine-grid residue class:
#
#     i mod 3, j mod 3
#
# so top-level injection is disjoint.
#
# Deeper recursive levels remain serial in order to avoid nested OpenMP
# oversubscription.
###############################################################################

needle = """for (int rep=0; rep<fineSt->coarseRepeats; ++rep) {
        for (int sx=0; sx<3; ++sx) for (int sy=0; sy<3; ++sy) {"""

if needle in s and "if(level == 0)" not in s:
    replacement = """for (int rep=0; rep<fineSt->coarseRepeats; ++rep) {
#ifdef _OPENMP
#pragma omp parallel for collapse(2) schedule(static) if(level == 0)
#endif
        for (int sx=0; sx<3; ++sx) for (int sy=0; sy<3; ++sy) {"""

    s = s.replace(needle, replacement, 1)
    print("[patch] 9 shifted-grid top-level geometric parallelism")

###############################################################################
# 7. Parallelize fine pressure RMT work without changing numerical formulas.
###############################################################################

p0 = s.find("static void solve_pressure_poisson(")
p1 = s.find("\nstatic void correct_velocity", p0)

require(p0 >= 0 and p1 > p0, "Could not isolate solve_pressure_poisson")

pressure = s[p0:p1]

# Add timer at entry.
if "__rmt_pressure_t0" not in pressure:
    pressure = re.sub(
        r'(\)\s*\{\s*\n)',
        r'\1    const double __rmt_pressure_t0 = rmt_wall_now();\n',
        pressure,
        count=1
    )

# Fine pressure residual build.
old = """        for (int i=1; i<=nx; ++i) for (int j=1; j<=ny; ++j) {
            double Ap = ap*f->p[IDX(i,j,ny)]"""

new = """#ifdef _OPENMP
#pragma omp parallel for collapse(2) schedule(static)
#endif
        for (int i=1; i<=nx; ++i) for (int j=1; j<=ny; ++j) {
            double Ap = ap*f->p[IDX(i,j,ny)]"""

if old in pressure:
    pressure = pressure.replace(old, new, 1)

# Add correction.
old = """            for (int i=1; i<=nx; ++i) for (int j=1; j<=ny; ++j)
                f->p[IDX(i,j,ny)] += omegaTry * corr[IDX(i,j,ny)];"""

new = """#ifdef _OPENMP
#pragma omp parallel for collapse(2) schedule(static)
#endif
            for (int i=1; i<=nx; ++i) for (int j=1; j<=ny; ++j)
                f->p[IDX(i,j,ny)] += omegaTry * corr[IDX(i,j,ny)];"""

if old in pressure:
    pressure = pressure.replace(old, new, 1)

# Rollback correction.
old = """            for (int i=1; i<=nx; ++i) for (int j=1; j<=ny; ++j)
                f->p[IDX(i,j,ny)] -= omegaTry * corr[IDX(i,j,ny)];"""

new = """#ifdef _OPENMP
#pragma omp parallel for collapse(2) schedule(static)
#endif
            for (int i=1; i<=nx; ++i) for (int j=1; j<=ny; ++j)
                f->p[IDX(i,j,ny)] -= omegaTry * corr[IDX(i,j,ny)];"""

if old in pressure:
    pressure = pressure.replace(old, new, 1)

# Pressure RBGS.
old = """            for (int color=0; color<2; ++color) {
                for (int i=1; i<=nx; ++i) for (int j=1; j<=ny; ++j) {"""

new = """            for (int color=0; color<2; ++color) {
#ifdef _OPENMP
#pragma omp parallel for collapse(2) schedule(static)
#endif
                for (int i=1; i<=nx; ++i) for (int j=1; j<=ny; ++j) {"""

if old in pressure:
    pressure = pressure.replace(old, new, 1)

# Add accumulated pressure timing.
oldtail = "    free(corr); free(res);\n}"

newtail = """    free(corr);
    free(res);

    g_pressure_rmt_wall_seconds +=
        rmt_wall_now() - __rmt_pressure_t0;

    g_pressure_rmt_calls += 1;
}"""

require(oldtail in pressure, "Could not locate pressure solver tail")
pressure = pressure.replace(oldtail, newtail, 1)

s = s[:p0] + pressure + s[p1:]

print("[patch] parallel fine pressure RMT work")
print("[patch] pressure block timing")

###############################################################################
# 8. Parallelize the existing stable scalar RBGS.
#
# This does NOT replace the scalar algorithm with RMT.
# It only executes each checkerboard color in parallel.
###############################################################################

q0 = s.find("static void solve_scalar_helmholtz(")

if q0 >= 0:
    # Try to find next top-level static function after scalar solver.
    q1 = s.find("\nstatic ", q0 + 40)

    if q1 > q0:
        scalar = s[q0:q1]

        old = """            for (int color=0; color<2; ++color) {
                for (int i=1; i<=nx; ++i) for (int j=1; j<=ny; ++j) {"""

        new = """            for (int color=0; color<2; ++color) {
#ifdef _OPENMP
#pragma omp parallel for collapse(2) schedule(static)
#endif
                for (int i=1; i<=nx; ++i) for (int j=1; j<=ny; ++j) {"""

        if old in scalar and "#pragma omp parallel for" not in scalar:
            scalar = scalar.replace(old, new, 1)
            s = s[:q0] + scalar + s[q1:]
            print("[patch] parallel stable scalar RBGS")

###############################################################################
# 9. Final machine-readable run summary.
###############################################################################

summary_anchor = 'printf("Elapsed computational time: %.6f s\\n", elapsed);'

if summary_anchor in s and "RMT_RUN_SUMMARY" not in s:

    summary = r'''
    double finalTmax  = field_max(&g, f.T);
    double finalYPmax = field_max(&g, f.YP);
    double finalYOmax = field_max(&g, f.YO);
    double finalYFmax = field_max(&g, f.YF);

    printf("Pressure RMT wall time: %.9f s\n",
           g_pressure_rmt_wall_seconds);

    printf("Pressure RMT calls: %lld\n",
           g_pressure_rmt_calls);

#ifdef _OPENMP
    printf("OpenMP max threads: %d\n",
           omp_get_max_threads());
#else
    printf("OpenMP max threads: 1\n");
#endif

    printf(
        "RMT_RUN_SUMMARY "
        "final_time=%.17g "
        "total_wall_s=%.17g "
        "pressure_wall_s=%.17g "
        "pressure_calls=%lld "
        "Tmax=%.17g "
        "YPmax=%.17g "
        "YOmax=%.17g "
        "YFmax=%.17g\n",
        time,
        elapsed,
        g_pressure_rmt_wall_seconds,
        g_pressure_rmt_calls,
        finalTmax,
        finalYPmax,
        finalYOmax,
        finalYFmax
    );
'''

    s = s.replace(
        summary_anchor,
        summary_anchor + "\n" + summary,
        1
    )

    print("[patch] machine-readable final summary")

###############################################################################
# 10. Add runtime banner.
###############################################################################

main_anchor = "parse_args(argc, argv, &g, &ph, &c);"

if main_anchor in s and "RMT pressure-only production campaign" not in s:

    banner = r'''

#ifdef _OPENMP
    omp_set_dynamic(0);
    printf(
        "RMT pressure-only production campaign: "
        "OpenMP enabled, max threads=%d\n",
        omp_get_max_threads()
    );
#else
    printf(
        "RMT pressure-only production campaign: "
        "WARNING OpenMP NOT enabled\n"
    );
#endif

    printf(
        "RMT configuration: 2D nine-shift triple-coarsening "
        "multiple coarse-grid correction\n"
    );

    printf(
        "Physical controls: Nx=%d Ny=%d end=%g "
        "vFuel=%g vOx=%g ArrheniusA=%g\n",
        g.Nx,
        g.Ny,
        c.endTime,
        ph.vFuel,
        ph.vOx,
        ph.A
    );

'''

    s = s.replace(
        main_anchor,
        main_anchor + banner,
        1
    )

    print("[patch] runtime banner")

###############################################################################
# Write final source.
###############################################################################

path.write_text(s)

print()
print("============================================================")
print("Patch complete:")
print(path)
print("Backup:")
print(backup)
print("============================================================")
