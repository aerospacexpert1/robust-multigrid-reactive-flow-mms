#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="${ROOT}/src/opposedflow_rmt3h.c"
BIN="${ROOT}/build/opposedflow_rmt3h"
MANIFEST="${ROOT}/campaign_manifest.csv"

# Orfoz requires 56 or 112 CPUs per node for submitted jobs.  This campaign
# intentionally requests 56 CPUs while retaining manifest OpenMP sizes 1/2/4/16.
ORFOZ_CPUS=56

echo "======================================================================"
echo "RMT CAMPAIGN VERIFICATION"
echo "======================================================================"

fail=0

check_file() {
    if [[ -e "$1" ]]; then
        echo "[OK] $1"
    else
        echo "[FAIL] missing $1"
        fail=1
    fi
}

check_file "${SRC}"
check_file "${ROOT}/config/campaign.env"
check_file "${ROOT}/run_case.sh"
check_file "${ROOT}/rmt_96_array.slurm"
check_file "${ROOT}/submit_all.sh"
check_file "${ROOT}/submit_task0.sh"
check_file "${ROOT}/submit_index.sh"
check_file "${ROOT}/build_rmt.slurm"
check_file "${ROOT}/collect_summary.py"

if [[ -x "${BIN}" ]]; then
    echo "[OK] solver binary exists"
else
    echo "[FAIL] solver binary missing"
    fail=1
fi

if [[ -f "${MANIFEST}" ]]; then
    lines="$(wc -l < "${MANIFEST}")"

    if [[ "${lines}" -eq 97 ]]; then
        echo "[OK] manifest has 96 cases + header"
    else
        echo "[FAIL] manifest line count = ${lines}, expected 97"
        fail=1
    fi

    flow_count="$(awk -F, 'NR>1 && $3=="FLOW" {n++} END {print n+0}' "${MANIFEST}")"
    stiff_count="$(awk -F, 'NR>1 && $3=="STIFFNESS" {n++} END {print n+0}' "${MANIFEST}")"

    [[ "${flow_count}" -eq 48 ]] && echo "[OK] FLOW = 48 cases" || { echo "[FAIL] FLOW count = ${flow_count}"; fail=1; }
    [[ "${stiff_count}" -eq 48 ]] && echo "[OK] STIFFNESS = 48 cases" || { echo "[FAIL] STIFFNESS count = ${stiff_count}"; fail=1; }

    expected_threads="1 2 4 16"
    actual_threads="$(awk -F, 'NR>1{t[$8]=1} END{for(k in t) print k}' "${MANIFEST}" | sort -n | xargs)"
    if [[ "${actual_threads}" == "${expected_threads}" ]]; then
        echo "[OK] benchmark thread levels = ${actual_threads}"
    else
        echo "[FAIL] benchmark thread levels = ${actual_threads}, expected ${expected_threads}"
        fail=1
    fi

    for t in 1 2 4 16; do
        n="$(awk -F, -v t="$t" 'NR>1 && $8==t{n++} END{print n+0}' "${MANIFEST}")"
        [[ "$n" -eq 24 ]] && echo "[OK] T${t} = 24 cases" || { echo "[FAIL] T${t} count = ${n}"; fail=1; }
    done

    meshes="$(awk -F, 'NR>1{m[$6"x"$7]=1} END{for(k in m) print k}' "${MANIFEST}" | sort -V | xargs)"
    if [[ "${meshes}" == "108x36 216x72 432x144 864x288" ]]; then
        echo "[OK] mesh family preserved: ${meshes}"
    else
        echo "[FAIL] unexpected meshes: ${meshes}"
        fail=1
    fi

    end_times="$(awk -F, 'NR>1{v=$13; gsub(/\r/,"",v); e[v]=1} END{for(k in e) print k}' "${MANIFEST}" | sort -n | xargs)"
    if [[ "${end_times}" == "2" || "${end_times}" == "2.0" ]]; then
        echo "[OK] final physical time = 2.0 s"
    else
        echo "[FAIL] unexpected end times: ${end_times}"
        fail=1
    fi
else
    echo "[FAIL] manifest not generated"
    fail=1
fi

echo
echo "Checking source architecture..."

grep -q "rmt_multiple_recursive" "${SRC}" && echo "[OK] recursive RMT correction present" || { echo "[FAIL] RMT recursion missing"; fail=1; }
if grep -q "sx<3" "${SRC}" && grep -q "sy<3" "${SRC}"; then
    echo "[OK] 3 x 3 = 9 shifted families present"
else
    echo "[FAIL] 9 shifted families not detected"; fail=1
fi
if grep -q "3.0 \* fine->dx" "${SRC}" || grep -q "3.0\*fine->dx" "${SRC}"; then
    echo "[OK] factor-three spatial coarsening detected"
else
    echo "[FAIL] factor-three dx not detected"; fail=1
fi
grep -q "#include <omp.h>" "${SRC}" && echo "[OK] OpenMP source support present" || { echo "[FAIL] omp.h absent"; fail=1; }
grep -q '"-vIn"' "${SRC}" && echo "[OK] -vIn runtime control" || { echo "[FAIL] -vIn absent"; fail=1; }
grep -q '"-arrA"' "${SRC}" && echo "[OK] -arrA runtime control" || { echo "[FAIL] -arrA absent"; fail=1; }
grep -q "RMT_RUN_SUMMARY" "${SRC}" && echo "[OK] machine-readable final summary" || { echo "[FAIL] final RMT summary absent"; fail=1; }
grep -q "g_pressure_rmt_wall_seconds" "${SRC}" && echo "[OK] pressure timing instrumentation" || { echo "[FAIL] pressure timing instrumentation absent"; fail=1; }

echo
echo "Checking Orfoz allocation vs actual OpenMP threads..."
for f in rmt_96_array.slurm build_rmt.slurm; do
    if grep -Eq '^#SBATCH[[:space:]]+--nodes=1([[:space:]]|$)' "${ROOT}/${f}" \
       && grep -Eq '^#SBATCH[[:space:]]+--ntasks=1([[:space:]]|$)' "${ROOT}/${f}" \
       && grep -Eq "^#SBATCH[[:space:]]+--cpus-per-task=${ORFOZ_CPUS}([[:space:]]|$)" "${ROOT}/${f}"; then
        echo "[OK] ${f}: 1 node / 1 task / ${ORFOZ_CPUS} CPUs"
    else
        echo "[FAIL] ${f}: Orfoz resource request is not 1 node / 1 task / ${ORFOZ_CPUS} CPUs"
        fail=1
    fi
done

for f in submit_all.sh submit_task0.sh submit_index.sh; do
    if grep -q -- '--cpus-per-task' "${ROOT}/${f}"; then
        if grep -Eq -- '--cpus-per-task=("?\$\{?ALLOC_CPUS\}?"?|56)([[:space:]\\]|$)' "${ROOT}/${f}"; then
            echo "[OK] ${f}: submission allocation is 56 CPUs"
        else
            echo "[FAIL] ${f}: found non-56 cpus-per-task submission override"
            grep -n -- '--cpus-per-task' "${ROOT}/${f}" || true
            fail=1
        fi
    else
        echo "[FAIL] ${f}: no explicit cpus-per-task allocation"
        fail=1
    fi
done

if grep -q 'export OMP_NUM_THREADS="${threads}"' "${ROOT}/run_case.sh" \
   && grep -q 'export OMP_THREAD_LIMIT="${threads}"' "${ROOT}/run_case.sh"; then
    echo "[OK] run_case.sh uses manifest threads for actual OpenMP execution"
else
    echo "[FAIL] run_case.sh does not enforce manifest OpenMP threads"
    fail=1
fi

if grep -q -- '-fieldOutput 0' "${ROOT}/run_case.sh"; then
    echo "[OK] timing campaign field output disabled"
else
    echo "[FAIL] timing campaign field output setting changed"
    fail=1
fi

echo
echo "Checking OpenMP binary linkage..."
if ldd "${BIN}" 2>/dev/null | grep -q "libgomp"; then
    echo "[OK] binary linked against libgomp"
else
    echo "[WARN] libgomp not detected by ldd"
fi

echo
echo "======================================================================"
if (( fail != 0 )); then
    echo "VERIFICATION FAILED"
    exit 1
fi

echo "VERIFIED:"
echo "  pressure-only RMT reacting-flow solver"
echo "  2D 9-shift multiple coarse-grid correction"
echo "  factor-three hierarchy"
echo "  FLOW + STIFFNESS = 48 + 48"
echo "  meshes 108x36, 216x72, 432x144, 864x288"
echo "  actual OpenMP threads 1,2,4,16"
echo "  Orfoz allocation 56 CPUs per submitted job"
echo "  total 96 cases"
echo "  final physical time 2.0 s"
echo "  field output excluded from timing campaign"
echo "  separate total and pressure/RMT wall time"
echo "======================================================================"
