# SG-RBGS opposed-flow reacting-flow campaign

Complete ready-to-run TRUBA campaign for the **single-grid red-black Gauss-Seidel** pressure baseline.

The reacting-flow formulation is frozen relative to the matched V95/OpenFOAM and multigrid campaigns. Only the pressure-solution strategy changes.

## Pressure solver

- grid hierarchy: finest grid only
- cycle: none
- iteration: one red update followed by one black update = one RBGS sweep
- default relaxation: omega = 1.0
- maximum pressure sweeps per pressure solve: 500000 (safety cap; the solve stops as soon as the common residual tolerance is met)
- relative tolerance: 1e-4
- absolute tolerance: 1e-6
- no restriction, prolongation, or coarse-grid correction

## Campaign matrix

- FLOW_INTENSITY: 0.05, 0.10, 0.20 m/s
- REACTION_STIFFNESS: low/intermediate/high chemistry cases
- meshes: 108x36, 216x72, 432x144, 864x288
- threads: 1, 2, 4, 16
- final physical time: 2.0 s
- total: 96 runs

## TRUBA quick start

```bash
chmod +x *.sh *.slurm *.py tests/*.sh
./verify_campaign.sh
./submit_task0.sh
```

After task 0 is confirmed:

```bash
./submit_all.sh
```

Monitor:

```bash
squeue -u "$USER"
./check_campaign_status.sh
```

Collect after completion:

```bash
python3 collect_summary.py
wc -l SG_RBGS_campaign_summary.csv
python3 analyze_scaling.py
```

A complete campaign produces 97 lines in `SG_RBGS_campaign_summary.csv` (header + 96 cases).
