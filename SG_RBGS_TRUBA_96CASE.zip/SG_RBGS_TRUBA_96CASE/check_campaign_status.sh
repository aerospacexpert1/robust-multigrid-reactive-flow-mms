#!/bin/bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
completed=$(find "$root/results" -name RUN_COMPLETE -type f 2>/dev/null | wc -l || true)
failed=$(find "$root/results" -name RUN_FAILED -type f 2>/dev/null | wc -l || true)
started=$(find "$root/results" -name launcher_timing.txt -type f 2>/dev/null | wc -l || true)
summaries=$(find "$root/results" -path '*/output/summary.csv' -type f 2>/dev/null | wc -l || true)
echo "Completed : $completed / 96"
echo "Failed    : $failed"
echo "Started   : $started / 96"
echo "Summaries : $summaries / 96"
if (( failed > 0 )); then
    echo "Failed cases:"
    find "$root/results" -name RUN_FAILED -printf '%h\n' | sort
fi
