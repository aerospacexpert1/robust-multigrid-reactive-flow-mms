#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
rm -rf results
mkdir -p results
rm -f slurm-SGRBGS_96_*.out slurm-SGRBGS_96_*.err
rm -f slurm-SGRBGS_BUILD_*.out slurm-SGRBGS_BUILD_*.err
rm -f SG_RBGS_campaign_summary.csv SG_RBGS_scaling.csv
