#!/usr/bin/env python3
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "campaign_manifest.csv"
OUT = ROOT / "SG_RBGS_campaign_summary.csv"

def clean_row(row):
    return {k.strip(): (v.strip() if isinstance(v, str) else v) for k, v in row.items()}

with MANIFEST.open(newline="", encoding="utf-8") as f:
    manifest = [clean_row(r) for r in csv.DictReader(f)]

rows = []
missing = []
for m in manifest:
    run_dir = ROOT / "results" / m["group_dir"] / m["physical_case"] / m["mesh_name"] / m["core_label"]
    summary = run_dir / "output" / "summary.csv"
    if not summary.exists():
        missing.append(m["case_id"])
        continue
    with summary.open(newline="", encoding="utf-8", errors="replace") as f:
        data = clean_row(next(csv.DictReader(f)))
    merged = dict(m)
    merged.update(data)
    merged["run_complete"] = int((run_dir / "RUN_COMPLETE").exists())
    merged["run_failed"] = int((run_dir / "RUN_FAILED").exists())
    merged["node"] = ""
    params = run_dir / "parameters.txt"
    if params.exists():
        kv = {}
        for line in params.read_text(errors="replace").splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                kv[k.strip()] = v.strip()
        merged["node"] = kv.get("node", "")
        merged["job_id"] = kv.get("job_id", "")
    merged["launcher_wall_seconds"] = ""
    timing = run_dir / "launcher_timing.txt"
    if timing.exists():
        for line in timing.read_text(errors="replace").splitlines():
            if line.startswith("launcher_wall_seconds_including_srun_and_output="):
                merged["launcher_wall_seconds"] = line.split("=", 1)[1].strip()
    rows.append(merged)

if not rows:
    raise SystemExit("No completed summary files found under results/")

fieldnames = []
for row in rows:
    for key in row:
        if key not in fieldnames:
            fieldnames.append(key)

with OUT.open("w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=fieldnames)
    w.writeheader()
    w.writerows(rows)

print(f"Wrote {OUT} with {len(rows)} rows")
if missing:
    print(f"Missing summaries: {len(missing)}")
else:
    print("Missing summaries: 0")
