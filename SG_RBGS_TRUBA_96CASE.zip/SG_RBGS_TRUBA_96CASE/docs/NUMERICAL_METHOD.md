# SG-RBGS numerical method

This executable preserves the frozen V95 opposed-flow reacting-flow formulation and changes the pressure Poisson solver only.

`SG-RBGS` is the non-multilevel reference pressure solver. The pressure equation is solved only on the finest structured grid. One iteration consists of one red-node update followed by one black-node update using the same five-point pressure stencil and boundary-condition treatment used as the smoother in the multigrid campaigns.

## One pressure sweep

1. Apply the pressure boundary conditions.
2. Update all red cells in parallel while black values are held fixed.
3. Reapply the pressure boundary conditions.
4. Update all black cells using the new red values.
5. Recompute the fine-grid pressure residual.
6. Stop if the absolute or relative pressure tolerance is satisfied; otherwise perform the next RBGS sweep.

Default controls are `omega=1.0`, maximum 500000 sweeps, relative tolerance `1e-4`, and absolute tolerance `1e-6`. There is no restriction, prolongation, coarse-grid solve, or multigrid correction.

## Reported metrics

Each run reports pressure time, total and average RBGS sweeps, maximum sweeps in any pressure solve, residual/convergence-factor information, complete reacting-flow compute time, physical extrema, and mass-residual metrics. Output I/O is excluded from the compute timer as in the other in-house campaigns.
