# Outputs

Each run writes its data below `results/<family>/<physical_case>/<mesh>/<core>/output/`.

Important files include:

- `summary.csv`: timing, RBGS pressure-sweep statistics, residuals and physical extrema
- `fields.pvd` and VTI files: ParaView-compatible fields
- `csv/centerline_*.csv`: centreline values
- `performance/pressure_step_history.csv`: per-time-step RBGS sweep counts and pressure residuals
- `performance/final_pressure_cycle_history.csv`: residual history of the final pressure solve (the filename is retained for cross-campaign compatibility; rows correspond to RBGS sweeps)

`compute_time_s` excludes field/performance output I/O. `pressure_time_s` is the cumulative time spent in the SG-RBGS pressure solver.
