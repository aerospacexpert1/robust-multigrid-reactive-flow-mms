# Provenance

The SG-RBGS campaign was derived from the same frozen V95 reacting-flow implementation and 96-case manifest used by the classical multigrid campaigns. The momentum, scalar, chemistry, enthalpy, thermophysical, boundary-condition, adaptive-time-step and output routines are retained. The pressure Poisson solver is replaced by a finest-grid-only red-black Gauss-Seidel iteration.
