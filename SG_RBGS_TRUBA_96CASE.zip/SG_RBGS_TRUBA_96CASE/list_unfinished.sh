#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PY'
import csv
from pathlib import Path
root=Path('.')
with open('campaign_manifest.csv',newline='') as f: rows=list(csv.DictReader(f))
for r in rows:
    d=root/'results'/r['group_dir']/r['physical_case']/r['mesh_name']/r['core_label']
    if not (d/'RUN_COMPLETE').exists():
        state='NOT_STARTED'
        if (d/'RUN_FAILED').exists(): state='FAILED'
        elif (d/'run.log').exists(): state='STARTED_INCOMPLETE'
        print(f"{int(r['array_index']):2d}  {state:18s}  {r['case_id']}")
PY
