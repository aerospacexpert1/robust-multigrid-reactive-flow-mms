#!/bin/bash
set -euo pipefail
idx=${1:?usage: ./submit_index.sh ARRAY_INDEX}
[[ "$idx" =~ ^[0-9]+$ ]] && (( idx >= 0 && idx <= 95 )) || { echo "Index must be 0..95" >&2; exit 2; }
cd "$(dirname "$0")"
[[ -x build/opposedflow_sg_rbgs ]] || { echo "Build first: sbatch build_sg_rbgs.slurm" >&2; exit 3; }
sbatch --array="$idx" sg_rbgs_96_array.slurm
