#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
make
rm -rf tests/_smoke_output
OMP_NUM_THREADS=2 build/opposedflow_sg_rbgs \
    -Nx 108 -Ny 36 -end 1e-7 -dt 1e-7 -dtMax 1e-4 \
    -vFuel 0.05 -vOx -0.05 -threads 2 -caseId LOCAL_SMOKE \
    -A 1e7 -beta 5 -Ta 1000 \
    -perfectGas 0 -variableCp 0 -sutherland 0 -rhoRelax 1 \
    -rho 1 -mu 2e-5 -cp 1000 -Pr 0.7 -Sc 1 -HfF 3.571428571e6 \
    -rbgsOmega 1.0 -pCycles 500000 -pRelTol 1e-4 -pAbsTol 1e-6 \
    -writeOutput 1 -write 1e-7 -outputDir tests/_smoke_output -progressEvery 0

test -s tests/_smoke_output/summary.csv
test -s tests/_smoke_output/fields.pvd
test -s tests/_smoke_output/performance/pressure_step_history.csv
python3 - <<'PY2'
import csv
row=next(csv.DictReader(open('tests/_smoke_output/summary.csv')))
assert row['solver']=='SG_RBGS'
assert float(row['final_pressure_rel_residual']) <= 1.0001e-4, row['final_pressure_rel_residual']
assert int(row['final_pressure_sweeps']) > 500, 'smoke test should demonstrate a genuine single-grid solve'
print('Smoke summary: sweeps=', row['final_pressure_sweeps'], 'relResidual=', row['final_pressure_rel_residual'])
PY2
echo "Smoke test passed."
