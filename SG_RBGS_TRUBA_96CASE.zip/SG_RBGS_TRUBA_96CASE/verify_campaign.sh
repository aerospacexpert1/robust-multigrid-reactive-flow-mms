#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PY'
import csv
from pathlib import Path
root=Path('.')
with open(root/'campaign_manifest.csv', newline='', encoding='utf-8') as f:
    rows=list(csv.DictReader(f))
assert len(rows)==96, f"expected 96 manifest rows, found {len(rows)}"
assert {int(r['threads']) for r in rows} == {1,2,4,16}
assert len({(r['study_family'],r['physical_case'],r['mesh_name']) for r in rows}) == 24
for p in root.rglob('*'):
    if p.is_file() and p.name != 'SHA256SUMS':
        b=p.read_bytes()
        assert b'\r' not in b, f"carriage-return contamination: {p}"
source=(root/'src/opposedflow_sg_rbgs.c').read_text()
required=['SG-RBGS','SG_RBGS','rbgs_pressure_sweeps','pressure_residual',
          'write_pressure_step_history','write_case_summary_csv']
for token in required:
    assert token in source, f"source verification missing {token}"
for forbidden in ['mg_level1_vcycle(', 'mg_restrict_2x2(', 'mg_prolong_bilinear_add(', 'MG2V_3LEVEL', 'MG3V_3LEVEL']:
    assert forbidden not in source, f"multilevel token remains in SG-RBGS source: {forbidden}"
assert 'rbgs_pressure_sweeps(g, ph, f, f->rhs, 1, c->mgOmega);' in source
print('Verified: SG-RBGS finest-grid-only pressure solver, 96 cases, 1/2/4/16 threads, LF-only files, and matched V95 output instrumentation.')
PY
