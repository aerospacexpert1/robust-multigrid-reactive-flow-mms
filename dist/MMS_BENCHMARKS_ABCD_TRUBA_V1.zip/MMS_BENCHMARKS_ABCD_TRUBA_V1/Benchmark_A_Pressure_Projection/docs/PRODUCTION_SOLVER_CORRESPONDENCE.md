# Production solver correspondence

The benchmark solver family preserves the reference campaign distinctions: SG_RBGS point red/black smoothing; MG2V factor-two V correction; MG2W factor-two W correction; MG3V h→2h→4h V structure; RMT3H factor-three, nine shifted (3×3) coarse-family injection with no presmoothing and post-smoothing. The MMS harness is an isolated verification driver, so full production time-loop and chemistry orchestration are not copied wholesale. The original production sources are retained as provenance in the repository `_reference_snapshot`.
