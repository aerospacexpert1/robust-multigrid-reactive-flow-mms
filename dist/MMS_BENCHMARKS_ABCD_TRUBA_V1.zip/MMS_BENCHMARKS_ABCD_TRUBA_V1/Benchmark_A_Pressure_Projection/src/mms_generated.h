#pragma once
#include <math.h>
#ifndef M_PI
#define M_PI 3.141592653589793238462643383279502884
#endif
/* Generated from continuous symbolic operators by tools/generate_mms_package.py. */
static inline double mms_diff(double x,double y,int s){
  switch(s){
    case 1: return 1.0/(0.080000000000000002*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1);
    case 2: return 1.0/(0.20000000000000001*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1);
    case 3: return 1.0/(0.34999999999999998*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1);
    default: return 0.0;
  }
}
static inline double mms_k(double x,double y,int s){
  switch(s){
    case 1: return 1.0/(0.080000000000000002*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1);
    case 2: return 1.0/(0.20000000000000001*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1);
    case 3: return 1.0/(0.34999999999999998*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1);
    default: return 0.0;
  }
}
static inline double mms_p(double x,double y,int s){
  switch(s){
    case 1: return 0.16000000000000003*pow(0.33333333333333331*x - 1.0/2.0, 2) - 0.16000000000000003*pow(1.0*y - 1.0/2.0, 2) + 0.80000000000000004*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 0.27999999999999997*cos(M_PI*x)*cos(M_PI*y);
    case 2: return 0.23999999999999999*pow(0.33333333333333331*x - 1.0/2.0, 2) - 0.23999999999999999*pow(1.0*y - 1.0/2.0, 2) + 1.2*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 0.41999999999999998*cos(M_PI*x)*cos(M_PI*y);
    case 3: return 0.36000000000000004*pow(0.33333333333333331*x - 1.0/2.0, 2) - 0.36000000000000004*pow(1.0*y - 1.0/2.0, 2) + 1.8*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 0.63*cos(M_PI*x)*cos(M_PI*y);
    default: return 0.0;
  }
}
static inline double mms_rho(double x,double y,int s){
  switch(s){
    case 1: return 0.080000000000000002*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1;
    case 2: return 0.20000000000000001*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1;
    case 3: return 0.34999999999999998*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1;
    default: return 0.0;
  }
}
static inline double mms_src_p(double x,double y,int s){
  switch(s){
    case 1: return -(-3.2000000000000002*pow(M_PI, 2)*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) - 0.27999999999999997*pow(M_PI, 2)*cos(M_PI*x)*cos(M_PI*y) - 0.32000000000000006)/(0.080000000000000002*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1) - (-0.35555555555555551*pow(M_PI, 2)*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) - 0.27999999999999997*pow(M_PI, 2)*cos(M_PI*x)*cos(M_PI*y) + 0.035555555555555562)/(0.080000000000000002*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1) + 0.05333333333333333*M_PI*(0.035555555555555562*x - 0.27999999999999997*M_PI*sin(M_PI*x)*cos(M_PI*y) + 0.53333333333333333*M_PI*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.053333333333333344)*cos(0.66666666666666663*M_PI*x)*cos(2*M_PI*y)/pow(0.080000000000000002*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1, 2) - 0.16*M_PI*(-0.32000000000000006*y + 1.6000000000000001*M_PI*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) - 0.27999999999999997*M_PI*sin(M_PI*y)*cos(M_PI*x) + 0.16000000000000003)*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y)/pow(0.080000000000000002*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1, 2);
    case 2: return -(-4.7999999999999998*pow(M_PI, 2)*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) - 0.41999999999999998*pow(M_PI, 2)*cos(M_PI*x)*cos(M_PI*y) - 0.47999999999999998)/(0.20000000000000001*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1) - (-0.53333333333333321*pow(M_PI, 2)*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) - 0.41999999999999998*pow(M_PI, 2)*cos(M_PI*x)*cos(M_PI*y) + 0.05333333333333333)/(0.20000000000000001*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1) + 0.13333333333333333*M_PI*(0.05333333333333333*x - 0.41999999999999998*M_PI*sin(M_PI*x)*cos(M_PI*y) + 0.79999999999999993*M_PI*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.079999999999999988)*cos(0.66666666666666663*M_PI*x)*cos(2*M_PI*y)/pow(0.20000000000000001*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1, 2) - 0.40000000000000002*M_PI*(-0.47999999999999998*y + 2.3999999999999999*M_PI*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) - 0.41999999999999998*M_PI*sin(M_PI*y)*cos(M_PI*x) + 0.23999999999999999)*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y)/pow(0.20000000000000001*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1, 2);
    case 3: return -(-7.2000000000000002*pow(M_PI, 2)*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) - 0.63*pow(M_PI, 2)*cos(M_PI*x)*cos(M_PI*y) - 0.72000000000000008)/(0.34999999999999998*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1) - (-0.79999999999999993*pow(M_PI, 2)*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) - 0.63*pow(M_PI, 2)*cos(M_PI*x)*cos(M_PI*y) + 0.080000000000000002)/(0.34999999999999998*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1) + 0.23333333333333331*M_PI*(0.080000000000000002*x - 0.63*M_PI*sin(M_PI*x)*cos(M_PI*y) + 1.2*M_PI*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.12000000000000001)*cos(0.66666666666666663*M_PI*x)*cos(2*M_PI*y)/pow(0.34999999999999998*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1, 2) - 0.69999999999999996*M_PI*(-0.72000000000000008*y + 3.6000000000000001*M_PI*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) - 0.63*M_PI*sin(M_PI*y)*cos(M_PI*x) + 0.36000000000000004)*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y)/pow(0.34999999999999998*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1, 2);
    default: return 0.0;
  }
}
static inline double mms_uadv(double x,double y,int s){
  switch(s){
    case 1: return 0;
    case 2: return 0;
    case 3: return 0;
    default: return 0.0;
  }
}
static inline double mms_vadv(double x,double y,int s){
  switch(s){
    case 1: return 0;
    case 2: return 0;
    case 3: return 0;
    default: return 0.0;
  }
}

static inline double mms_u(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_v(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_YF(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_YO(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_YP(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_h(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_T(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_src_u(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_src_v(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_src_YF(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_src_YO(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_src_YP(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_src_h(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_rate(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_arrA(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_arrBeta(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_arrTa(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
