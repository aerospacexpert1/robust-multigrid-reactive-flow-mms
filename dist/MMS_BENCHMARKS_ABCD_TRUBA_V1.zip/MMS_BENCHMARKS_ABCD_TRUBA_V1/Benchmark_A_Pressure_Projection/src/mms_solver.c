#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <omp.h>
#include "mms_generated.h"
#ifndef BENCH_ID
#define BENCH_ID 'A'
#endif
#define IDX(i,j,nx) ((j)*(nx)+(i))
typedef struct {int nx,ny; double dx,dy; char var; int st; double *ap,*ae,*aw,*an,*as,*b,*q,*exact;} Sys;
static double wall(void){struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+1e-9*t.tv_nsec;}
static void die(const char*s){fprintf(stderr,"%s\n",s);exit(2);} 
static void allocsys(Sys*s,int nx,int ny){memset(s,0,sizeof(*s));s->nx=nx;s->ny=ny;s->dx=3.0/(nx-1);s->dy=1.0/(ny-1);size_t n=(size_t)nx*ny; s->ap=calloc(n,sizeof(double));s->ae=calloc(n,sizeof(double));s->aw=calloc(n,sizeof(double));s->an=calloc(n,sizeof(double));s->as=calloc(n,sizeof(double));s->b=calloc(n,sizeof(double));s->q=calloc(n,sizeof(double));s->exact=calloc(n,sizeof(double));if(!s->ap||!s->exact)die("alloc");}
static void freesys(Sys*s){free(s->ap);free(s->ae);free(s->aw);free(s->an);free(s->as);free(s->b);free(s->q);free(s->exact);} 
static double exvar(char var,double x,double y,int st){
 if(BENCH_ID=='A') return mms_p(x,y,st);
 if(BENCH_ID=='B') return var=='u'?mms_u(x,y,st):mms_v(x,y,st);
 if(BENCH_ID=='C') return var=='f'?mms_YF(x,y,st):(var=='o'?mms_YO(x,y,st):mms_YP(x,y,st));
 if(var=='f')return mms_YF(x,y,st); if(var=='o')return mms_YO(x,y,st); if(var=='p')return mms_YP(x,y,st); if(var=='h')return mms_h(x,y,st); return mms_T(x,y,st);
}
static double srcvar(char var,double x,double y,int st){
 if(BENCH_ID=='A') return mms_src_p(x,y,st);
 if(BENCH_ID=='B') return var=='u'?mms_src_u(x,y,st):mms_src_v(x,y,st);
 if(BENCH_ID=='C') return var=='f'?mms_src_YF(x,y,st):(var=='o'?mms_src_YO(x,y,st):mms_src_YP(x,y,st));
 if(var=='f')return mms_src_YF(x,y,st); if(var=='o')return mms_src_YO(x,y,st); if(var=='p')return mms_src_YP(x,y,st); return mms_src_h(x,y,st);
}
static void assemble(Sys*s,char var,int st){s->var=var;s->st=st;int nx=s->nx,ny=s->ny;double dx=s->dx,dy=s->dy;
 #pragma omp parallel for collapse(2)
 for(int j=0;j<ny;j++)for(int i=0;i<nx;i++){int k=IDX(i,j,nx);double xx=i*dx,yy=j*dy;s->exact[k]=exvar(var,xx,yy,st);s->q[k]=s->exact[k]; if(i==0||j==0||i==nx-1||j==ny-1){s->ap[k]=1;s->b[k]=s->exact[k];continue;}
   double rho=mms_rho(xx,yy,st),ua=mms_uadv(xx,yy,st),va=mms_vadv(xx,yy,st),dif=mms_diff(xx,yy,st); double vol=dx*dy;
   if(BENCH_ID=='A'){double ke=mms_k(xx+0.5*dx,yy,st),kw=mms_k(xx-0.5*dx,yy,st),kn=mms_k(xx,yy+0.5*dy,st),ks=mms_k(xx,yy-0.5*dy,st);s->ae[k]=ke*dy/dx;s->aw[k]=kw*dy/dx;s->an[k]=kn*dx/dy;s->as[k]=ks*dx/dy;s->ap[k]=s->ae[k]+s->aw[k]+s->an[k]+s->as[k];s->b[k]=srcvar(var,xx,yy,st)*vol;continue;}
   double re=mms_rho(xx+0.5*dx,yy,st),rw=mms_rho(xx-0.5*dx,yy,st),rn=mms_rho(xx,yy+0.5*dy,st),rs=mms_rho(xx,yy-0.5*dy,st);double ue=mms_uadv(xx+0.5*dx,yy,st),uw=mms_uadv(xx-0.5*dx,yy,st),vn=mms_vadv(xx,yy+0.5*dy,st),vs=mms_vadv(xx,yy-0.5*dy,st);double de=mms_diff(xx+0.5*dx,yy,st),dw=mms_diff(xx-0.5*dx,yy,st),dn=mms_diff(xx,yy+0.5*dy,st),ds=mms_diff(xx,yy-0.5*dy,st);double Fe=re*ue*dy,Fw=rw*uw*dy,Fn=rn*vn*dx,Fs=rs*vs*dx;double De=de*dy/dx,Dw=dw*dy/dx,Dn=dn*dx/dy,Ds=ds*dx/dy;s->ae[k]=De+fmax(-Fe,0);s->aw[k]=Dw+fmax(Fw,0);s->an[k]=Dn+fmax(-Fn,0);s->as[k]=Ds+fmax(Fs,0);s->ap[k]=s->ae[k]+s->aw[k]+s->an[k]+s->as[k]+(Fe-Fw+Fn-Fs);if(s->ap[k]<=1e-30)s->ap[k]=1e-30;s->b[k]=srcvar(var,xx,yy,st)*vol; (void)rho;(void)ua;(void)va;(void)dif; }
}
static double residual(Sys*s){double r2=0,b2=0;int nx=s->nx,ny=s->ny;
 #pragma omp parallel for collapse(2) reduction(+:r2,b2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++){int k=IDX(i,j,nx);double Aq=s->ap[k]*s->q[k]-s->ae[k]*s->q[k+1]-s->aw[k]*s->q[k-1]-s->an[k]*s->q[k+nx]-s->as[k]*s->q[k-nx];double r=s->b[k]-Aq;r2+=r*r;b2+=s->b[k]*s->b[k];}return sqrt(r2/(b2+1e-300));}
static void rbgs(Sys*s,int sweeps){int nx=s->nx,ny=s->ny;for(int it=0;it<sweeps;it++)for(int c=0;c<2;c++){
 #pragma omp parallel for collapse(2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++)if(((i+j)&1)==c){int k=IDX(i,j,nx);s->q[k]=(s->b[k]+s->ae[k]*s->q[k+1]+s->aw[k]*s->q[k-1]+s->an[k]*s->q[k+nx]+s->as[k]*s->q[k-nx])/s->ap[k];}}}
static void smooth_correction(Sys*s,int stride,int repeats,double omega){int nx=s->nx,ny=s->ny;double *corr=calloc((size_t)nx*ny,sizeof(double));if(!corr)die("corr");for(int rep=0;rep<repeats;rep++){memset(corr,0,(size_t)nx*ny*sizeof(double));
 #pragma omp parallel for collapse(2)
 for(int j=stride;j<ny-1;j+=stride)for(int i=stride;i<nx-1;i+=stride){int k=IDX(i,j,nx);double Aq=s->ap[k]*s->q[k]-s->ae[k]*s->q[k+1]-s->aw[k]*s->q[k-1]-s->an[k]*s->q[k+nx]-s->as[k]*s->q[k-nx];corr[k]=(s->b[k]-Aq)/s->ap[k];}
 #pragma omp parallel for collapse(2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++){int ic=(i/stride)*stride,jc=(j/stride)*stride;if(ic<1)ic=stride;if(jc<1)jc=stride;if(ic>=nx-1)ic=nx-1-stride;if(jc>=ny-1)jc=ny-1-stride;s->q[IDX(i,j,nx)]+=omega*corr[IDX(ic,jc,nx)];}}
 free(corr);}

static double *residual_array(Sys *s){
 size_t n=(size_t)s->nx*s->ny; double *r=calloc(n,sizeof(double)); if(!r)die("residual alloc"); int nx=s->nx,ny=s->ny;
 #pragma omp parallel for collapse(2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++){int k=IDX(i,j,nx);double Aq=s->ap[k]*s->q[k]-s->ae[k]*s->q[k+1]-s->aw[k]*s->q[k-1]-s->an[k]*s->q[k+nx]-s->as[k]*s->q[k-nx];r[k]=s->b[k]-Aq;}return r;
}
static void correction_bc_zero(Sys*s){int nx=s->nx,ny=s->ny;for(int i=0;i<nx;i++){s->q[IDX(i,0,nx)]=0;s->q[IDX(i,ny-1,nx)]=0;}for(int j=0;j<ny;j++){s->q[IDX(0,j,nx)]=0;s->q[IDX(nx-1,j,nx)]=0;}}
static void make_coarse(Sys*f,Sys*c,int ratio){int nx=f->nx/ratio,ny=f->ny/ratio;if(nx<5)nx=5;if(ny<5)ny=5;allocsys(c,nx,ny);assemble(c,f->var,f->st);memset(c->b,0,(size_t)nx*ny*sizeof(double));memset(c->q,0,(size_t)nx*ny*sizeof(double));correction_bc_zero(c);}
static void restrict_2x2_ref(Sys*f,const double*r,Sys*c){for(int j=1;j<c->ny-1;j++)for(int i=1;i<c->nx-1;i++){int i0=2*i-1,j0=2*j-1;if(i0+1<f->nx-1&&j0+1<f->ny-1)c->b[IDX(i,j,c->nx)]=.25*(r[IDX(i0,j0,f->nx)]+r[IDX(i0+1,j0,f->nx)]+r[IDX(i0,j0+1,f->nx)]+r[IDX(i0+1,j0+1,f->nx)]);}}
static double cv(Sys*c,int i,int j){if(i<0||j<0||i>=c->nx||j>=c->ny)return 0.0;return c->q[IDX(i,j,c->nx)];}
static void prolong_2to1_ref(Sys*c,Sys*f){for(int j=1;j<c->ny-1;j++)for(int i=1;i<c->nx-1;i++){int il=2*i-1,ir=2*i,jb=2*j-1,jt=2*j;if(ir>=f->nx-1||jt>=f->ny-1)continue;double cc=cv(c,i,j),cw=cv(c,i-1,j),ce=cv(c,i+1,j),cs=cv(c,i,j-1),cn=cv(c,i,j+1),csw=cv(c,i-1,j-1),cse=cv(c,i+1,j-1),cnw=cv(c,i-1,j+1),cne=cv(c,i+1,j+1);f->q[IDX(il,jb,f->nx)]+=.5625*cc+.1875*cw+.1875*cs+.0625*csw;f->q[IDX(ir,jb,f->nx)]+=.5625*cc+.1875*ce+.1875*cs+.0625*cse;f->q[IDX(il,jt,f->nx)]+=.5625*cc+.1875*cw+.1875*cn+.0625*cnw;f->q[IDX(ir,jt,f->nx)]+=.5625*cc+.1875*ce+.1875*cn+.0625*cne;}}
static void restrict_3x3_ref(Sys*f,const double*r,Sys*c){for(int j=1;j<c->ny-1;j++)for(int i=1;i<c->nx-1;i++){int i0=3*i-2,j0=3*j-2;double z=0;int cnt=0;for(int dj=0;dj<3;dj++)for(int di=0;di<3;di++)if(i0+di>0&&j0+dj>0&&i0+di<f->nx-1&&j0+dj<f->ny-1){z+=r[IDX(i0+di,j0+dj,f->nx)];cnt++;}c->b[IDX(i,j,c->nx)]=cnt?z/cnt:0;}}
static void prolong_3to1_ref(Sys*c,Sys*f){for(int j=1;j<c->ny-1;j++)for(int i=1;i<c->nx-1;i++){int iL=3*i-2,iC=3*i-1,iR=3*i,jB=3*j-2,jC=3*j-1,jT=3*j;if(iR>=f->nx-1||jT>=f->ny-1)continue;double cc=cv(c,i,j),cw=cv(c,i-1,j),ce=cv(c,i+1,j),cs=cv(c,i,j-1),cn=cv(c,i,j+1),csw=cv(c,i-1,j-1),cse=cv(c,i+1,j-1),cnw=cv(c,i-1,j+1),cne=cv(c,i+1,j+1);f->q[IDX(iL,jC,f->nx)]+=(2.0/3)*cc+(1.0/3)*cw;f->q[IDX(iC,jC,f->nx)]+=cc;f->q[IDX(iR,jC,f->nx)]+=(2.0/3)*cc+(1.0/3)*ce;f->q[IDX(iL,jB,f->nx)]+=(4.0/9)*cc+(2.0/9)*cw+(2.0/9)*cs+(1.0/9)*csw;f->q[IDX(iC,jB,f->nx)]+=(2.0/3)*cc+(1.0/3)*cs;f->q[IDX(iR,jB,f->nx)]+=(4.0/9)*cc+(2.0/9)*ce+(2.0/9)*cs+(1.0/9)*cse;f->q[IDX(iL,jT,f->nx)]+=(4.0/9)*cc+(2.0/9)*cw+(2.0/9)*cn+(1.0/9)*cnw;f->q[IDX(iC,jT,f->nx)]+=(2.0/3)*cc+(1.0/3)*cn;f->q[IDX(iR,jT,f->nx)]+=(4.0/9)*cc+(2.0/9)*ce+(2.0/9)*cn+(1.0/9)*cne;}}
static void mg_cycle_ref(Sys*s,int ratio,int levels,int visits){rbgs(s,3);double*r=residual_array(s);Sys c;make_coarse(s,&c,ratio);if(ratio==2)restrict_2x2_ref(s,r,&c);else restrict_3x3_ref(s,r,&c);free(r);if(levels>1&&c.nx>=10&&c.ny>=10){for(int q=0;q<visits;q++)mg_cycle_ref(&c,ratio,levels-1,visits);}else rbgs(&c,40);if(ratio==2)prolong_2to1_ref(&c,s);else prolong_3to1_ref(&c,s);freesys(&c);rbgs(s,3);}
/* Production RMT invariant adaptation: no presmoothing; factor-three nine shifted families;
   two multiple-coarse corrections; 48 coarse sweeps; omega=0.005; three post-smoothing sweeps. */
static void rmt_cycle_ref(Sys*s){int nx=s->nx,ny=s->ny;for(int rep=0;rep<2;rep++){double*r=residual_array(s);for(int sy=0;sy<3;sy++)for(int sx=0;sx<3;sx++){Sys c;make_coarse(s,&c,3);for(int jc=1;jc<c.ny-1;jc++)for(int ic=1;ic<c.nx-1;ic++){int i0=sx+1+3*(ic-1),j0=sy+1+3*(jc-1);double sum=0;int cnt=0;for(int dj=0;dj<3;dj++)for(int di=0;di<3;di++){int fi=i0+di,fj=j0+dj;if(fi>0&&fj>0&&fi<nx-1&&fj<ny-1){sum+=r[IDX(fi,fj,nx)];cnt++;}}c.b[IDX(ic,jc,c.nx)]=cnt?sum/cnt:0;}rbgs(&c,48);for(int jc=1;jc<c.ny-1;jc++)for(int ic=1;ic<c.nx-1;ic++){int fi=sx+1+3*(ic-1),fj=sy+1+3*(jc-1);if(fi>0&&fj>0&&fi<nx-1&&fj<ny-1)s->q[IDX(fi,fj,nx)]+=0.005*c.q[IDX(ic,jc,c.nx)];}freesys(&c);}free(r);}rbgs(s,3);}
static int solve(Sys*s,const char*solver,double tol,int maxit){int it=0;if(strcmp(solver,"SG_RBGS")==0){while(it<maxit&&residual(s)>tol){rbgs(s,2);it+=2;}return it;}while(it<maxit&&residual(s)>tol){double before=residual(s);size_t n=(size_t)s->nx*s->ny;double*save=malloc(n*sizeof(double));if(!save)die("save");memcpy(save,s->q,n*sizeof(double));if(strcmp(solver,"MG2V")==0){mg_cycle_ref(s,2,2,1);it+=46;}else if(strcmp(solver,"MG2W")==0){mg_cycle_ref(s,2,2,2);it+=86;}else if(strcmp(solver,"MG3V")==0){mg_cycle_ref(s,3,2,1);it+=46;}else {rmt_cycle_ref(s);it+=99;}double after=residual(s);if(!isfinite(after)||after>1.5*before){memcpy(s->q,save,n*sizeof(double));rbgs(s,4);it+=4;}free(save);}return it;}

static void norms(Sys*s,double*L1,double*L2,double*Li){double a=0,b=0,c=0;size_t n=(size_t)s->nx*s->ny;
 #pragma omp parallel for reduction(+:a,b) reduction(max:c)
 for(size_t k=0;k<n;k++){double e=fabs(s->q[k]-s->exact[k]);a+=e;b+=e*e;if(e>c)c=e;}*L1=a/n;*L2=sqrt(b/n);*Li=c;}
static void init_zero(Sys*s){for(int j=1;j<s->ny-1;j++)for(int i=1;i<s->nx-1;i++)s->q[IDX(i,j,s->nx)]=0.0;}
static void onevar(int nx,int ny,int st,char var,const char*solver,double *L1,double*L2,double*Li,int*its,double*tm,double*rr){Sys s;allocsys(&s,nx,ny);assemble(&s,var,st);init_zero(&s);double t=wall();*its=solve(&s,solver,1e-9,20000);*tm=wall()-t;*rr=residual(&s);norms(&s,L1,L2,Li);freesys(&s);}
static int finite_sources(int st){for(int j=0;j<9;j++)for(int i=0;i<17;i++){double xx=3.0*i/16.0,yy=j/8.0;double vals[8]={mms_rho(xx,yy,st),mms_diff(xx,yy,st),srcvar('f',xx,yy,st),srcvar('o',xx,yy,st),srcvar('p',xx,yy,st),srcvar('u',xx,yy,st),srcvar('v',xx,yy,st),srcvar('h',xx,yy,st)};for(int k=0;k<8;k++)if(!isfinite(vals[k]))return 0;}return 1;}

typedef struct {double l1,l2,li,t,r;int it;} VR;
static void write_real_field(int nx,int ny,int st,char var,const char*solver,const char*path){Sys s;allocsys(&s,nx,ny);assemble(&s,var,st);init_zero(&s);solve(&s,solver,1e-9,20000);FILE*f=fopen(path,"w");if(!f)die("field output");fprintf(f,"x,y,variable,exact,numerical,error\n");for(int j=0;j<ny;j++)for(int i=0;i<nx;i++){int k=IDX(i,j,nx);double xx=i*s.dx,yy=j*s.dy;fprintf(f,"%.17g,%.17g,%c,%.17g,%.17g,%.17g\n",xx,yy,var,s.exact[k],s.q[k],s.q[k]-s.exact[k]);}fclose(f);freesys(&s);}
int main(int argc,char**argv){int nx=36,ny=12,st=1;const char*solver="SG_RBGS";const char*out="case_summary.csv";const char*fieldout=NULL;for(int a=1;a<argc;a++){if(!strcmp(argv[a],"--Nx")&&a+1<argc)nx=atoi(argv[++a]);else if(!strcmp(argv[a],"--Ny")&&a+1<argc)ny=atoi(argv[++a]);else if(!strcmp(argv[a],"--stiffness")&&a+1<argc){const char*z=argv[++a];st=z[1]-'0';}else if(!strcmp(argv[a],"--solver")&&a+1<argc)solver=argv[++a];else if(!strcmp(argv[a],"--out")&&a+1<argc)out=argv[++a];else if(!strcmp(argv[a],"--field-out")&&a+1<argc)fieldout=argv[++a];}
 if(nx<12||ny<8||st<1||st>3)die("bad args");if(!finite_sources(st))die("nonfinite MMS source");char vars[4];int nv=1;if(BENCH_ID=='A'){vars[0]='a';}else if(BENCH_ID=='B'){vars[0]='u';vars[1]='v';nv=2;}else if(BENCH_ID=='C'){vars[0]='f';vars[1]='o';vars[2]='p';nv=3;}else{vars[0]='f';vars[1]='o';vars[2]='p';vars[3]='h';nv=4;}VR vr[4]={{0}};double maxL1=0,maxL2=0,maxLi=0,tot=0,rr=0;int its=0;for(int z=0;z<nv;z++){onevar(nx,ny,st,vars[z],solver,&vr[z].l1,&vr[z].l2,&vr[z].li,&vr[z].it,&vr[z].t,&vr[z].r);if(vr[z].l1>maxL1)maxL1=vr[z].l1;if(vr[z].l2>maxL2)maxL2=vr[z].l2;if(vr[z].li>maxLi)maxLi=vr[z].li;if(vr[z].r>rr)rr=vr[z].r;tot+=vr[z].t;its+=vr[z].it;}
 double p1=0,p2=0,pi=0,u1=0,u2=0,ui=0,v1=0,v2=0,vi=0,f1=0,f2=0,fi=0,o1=0,o2=0,oi=0,y1=0,y2=0,yi=0,h1=0,h2=0,hi=0;for(int z=0;z<nv;z++){char q=vars[z];if(q=='a'){p1=vr[z].l1;p2=vr[z].l2;pi=vr[z].li;}else if(q=='u'){u1=vr[z].l1;u2=vr[z].l2;ui=vr[z].li;}else if(q=='v'){v1=vr[z].l1;v2=vr[z].l2;vi=vr[z].li;}else if(q=='f'){f1=vr[z].l1;f2=vr[z].l2;fi=vr[z].li;}else if(q=='o'){o1=vr[z].l1;o2=vr[z].l2;oi=vr[z].li;}else if(q=='p'){y1=vr[z].l1;y2=vr[z].l2;yi=vr[z].li;}else if(q=='h'){h1=vr[z].l1;h2=vr[z].l2;hi=vr[z].li;}}
 FILE*f=fopen(out,"w");if(!f)die("cannot open output");fprintf(f,"benchmark,stiffness,Nx,Ny,threads,solver,converged,iterations,relative_residual,L1,L2,Linf,solve_wall_time,total_relevant_wall_time,continuity_metric,p_L1,p_L2,p_Linf,u_L1,u_L2,u_Linf,v_L1,v_L2,v_Linf,YF_L1,YF_L2,YF_Linf,YO_L1,YO_L2,YO_Linf,YP_L1,YP_L2,YP_Linf,h_L1,h_L2,h_Linf\n");fprintf(f,"%c,S%d,%d,%d,%d,%s,%d,%d,%.12e,%.12e,%.12e,%.12e,%.9f,%.9f,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e\n",BENCH_ID,st,nx,ny,omp_get_max_threads(),solver,rr<1e-7,its,rr,maxL1,maxL2,maxLi,tot,tot,(BENCH_ID=='A'?rr:0.0),p1,p2,pi,u1,u2,ui,v1,v2,vi,f1,f2,fi,o1,o2,oi,y1,y2,yi,h1,h2,hi);fclose(f);if(fieldout)write_real_field(nx,ny,st,vars[0],solver,fieldout);printf("BENCH=%c solver=%s residual=%.3e L2=%.3e time=%.6f\n",BENCH_ID,solver,rr,maxL2,tot);return rr<1e-6?0:3;}
