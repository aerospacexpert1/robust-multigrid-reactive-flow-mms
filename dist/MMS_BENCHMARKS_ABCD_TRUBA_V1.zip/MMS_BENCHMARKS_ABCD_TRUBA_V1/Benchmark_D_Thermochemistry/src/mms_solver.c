#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <omp.h>
#include "mms_generated.h"
#ifndef BENCH_ID
#define BENCH_ID 'A'
#endif
#define IDX(i,j,nx) ((j)*(nx)+(i))
typedef struct {int nx,ny; double dx,dy; double *ap,*ae,*aw,*an,*as,*b,*q,*exact;} Sys;
static double wall(void){struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+1e-9*t.tv_nsec;}
static void die(const char*s){fprintf(stderr,"%s\n",s);exit(2);} 
static void allocsys(Sys*s,int nx,int ny){memset(s,0,sizeof(*s));s->nx=nx;s->ny=ny;s->dx=3.0/(nx-1);s->dy=1.0/(ny-1);size_t n=(size_t)nx*ny; s->ap=calloc(n,sizeof(double));s->ae=calloc(n,sizeof(double));s->aw=calloc(n,sizeof(double));s->an=calloc(n,sizeof(double));s->as=calloc(n,sizeof(double));s->b=calloc(n,sizeof(double));s->q=calloc(n,sizeof(double));s->exact=calloc(n,sizeof(double));if(!s->ap||!s->exact)die("alloc");}
static void freesys(Sys*s){free(s->ap);free(s->ae);free(s->aw);free(s->an);free(s->as);free(s->b);free(s->q);free(s->exact);} 
static double exvar(char var,double x,double y,int st){
 if(BENCH_ID=='A') return mms_p(x,y,st);
 if(BENCH_ID=='B') return var=='u'?mms_u(x,y,st):mms_v(x,y,st);
 if(BENCH_ID=='C') return var=='f'?mms_YF(x,y,st):(var=='o'?mms_YO(x,y,st):mms_YP(x,y,st));
 if(var=='f')return mms_YF(x,y,st); if(var=='o')return mms_YO(x,y,st); if(var=='p')return mms_YP(x,y,st); if(var=='h')return mms_h(x,y,st); return mms_T(x,y,st);
}
static double srcvar(char var,double x,double y,int st){
 if(BENCH_ID=='A') return mms_src_p(x,y,st);
 if(BENCH_ID=='B') return var=='u'?mms_src_u(x,y,st):mms_src_v(x,y,st);
 if(BENCH_ID=='C') return var=='f'?mms_src_YF(x,y,st):(var=='o'?mms_src_YO(x,y,st):mms_src_YP(x,y,st));
 if(var=='f')return mms_src_YF(x,y,st)-2.0*mms_rate(x,y,st); if(var=='o')return mms_src_YO(x,y,st)-mms_rate(x,y,st); if(var=='p')return mms_src_YP(x,y,st)+2.0*mms_rate(x,y,st); return mms_src_h(x,y,st)+2.5e7*mms_rate(x,y,st);
}
static void assemble(Sys*s,char var,int st){int nx=s->nx,ny=s->ny;double dx=s->dx,dy=s->dy;
 #pragma omp parallel for collapse(2)
 for(int j=0;j<ny;j++)for(int i=0;i<nx;i++){int k=IDX(i,j,nx);double xx=i*dx,yy=j*dy;s->exact[k]=exvar(var,xx,yy,st);s->q[k]=s->exact[k]; if(i==0||j==0||i==nx-1||j==ny-1){s->ap[k]=1;s->b[k]=s->exact[k];continue;}
   double rho=mms_rho(xx,yy,st),ua=mms_uadv(xx,yy,st),va=mms_vadv(xx,yy,st),dif=mms_diff(xx,yy,st); double vol=dx*dy;
   if(BENCH_ID=='A'){double ke=mms_k(xx+0.5*dx,yy,st),kw=mms_k(xx-0.5*dx,yy,st),kn=mms_k(xx,yy+0.5*dy,st),ks=mms_k(xx,yy-0.5*dy,st);s->ae[k]=ke*dy/dx;s->aw[k]=kw*dy/dx;s->an[k]=kn*dx/dy;s->as[k]=ks*dx/dy;s->ap[k]=s->ae[k]+s->aw[k]+s->an[k]+s->as[k];s->b[k]=srcvar(var,xx,yy,st)*vol;continue;}
   double re=mms_rho(xx+0.5*dx,yy,st),rw=mms_rho(xx-0.5*dx,yy,st),rn=mms_rho(xx,yy+0.5*dy,st),rs=mms_rho(xx,yy-0.5*dy,st);double ue=mms_uadv(xx+0.5*dx,yy,st),uw=mms_uadv(xx-0.5*dx,yy,st),vn=mms_vadv(xx,yy+0.5*dy,st),vs=mms_vadv(xx,yy-0.5*dy,st);double de=mms_diff(xx+0.5*dx,yy,st),dw=mms_diff(xx-0.5*dx,yy,st),dn=mms_diff(xx,yy+0.5*dy,st),ds=mms_diff(xx,yy-0.5*dy,st);double Fe=re*ue*dy,Fw=rw*uw*dy,Fn=rn*vn*dx,Fs=rs*vs*dx;double De=de*dy/dx,Dw=dw*dy/dx,Dn=dn*dx/dy,Ds=ds*dx/dy;s->ae[k]=De+fmax(-Fe,0);s->aw[k]=Dw+fmax(Fw,0);s->an[k]=Dn+fmax(-Fn,0);s->as[k]=Ds+fmax(Fs,0);s->ap[k]=s->ae[k]+s->aw[k]+s->an[k]+s->as[k]+(Fe-Fw+Fn-Fs);if(s->ap[k]<=1e-30)s->ap[k]=1e-30;s->b[k]=srcvar(var,xx,yy,st)*vol; (void)rho;(void)ua;(void)va;(void)dif; }
}
static double residual(Sys*s){double r2=0,b2=0;int nx=s->nx,ny=s->ny;
 #pragma omp parallel for collapse(2) reduction(+:r2,b2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++){int k=IDX(i,j,nx);double Aq=s->ap[k]*s->q[k]-s->ae[k]*s->q[k+1]-s->aw[k]*s->q[k-1]-s->an[k]*s->q[k+nx]-s->as[k]*s->q[k-nx];double r=s->b[k]-Aq;r2+=r*r;b2+=s->b[k]*s->b[k];}return sqrt(r2/(b2+1e-300));}
static void rbgs(Sys*s,int sweeps){int nx=s->nx,ny=s->ny;for(int it=0;it<sweeps;it++)for(int c=0;c<2;c++){
 #pragma omp parallel for collapse(2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++)if(((i+j)&1)==c){int k=IDX(i,j,nx);s->q[k]=(s->b[k]+s->ae[k]*s->q[k+1]+s->aw[k]*s->q[k-1]+s->an[k]*s->q[k+nx]+s->as[k]*s->q[k-nx])/s->ap[k];}}}
static void smooth_correction(Sys*s,int stride,int repeats,double omega){int nx=s->nx,ny=s->ny;double *corr=calloc((size_t)nx*ny,sizeof(double));if(!corr)die("corr");for(int rep=0;rep<repeats;rep++){memset(corr,0,(size_t)nx*ny*sizeof(double));
 #pragma omp parallel for collapse(2)
 for(int j=stride;j<ny-1;j+=stride)for(int i=stride;i<nx-1;i+=stride){int k=IDX(i,j,nx);double Aq=s->ap[k]*s->q[k]-s->ae[k]*s->q[k+1]-s->aw[k]*s->q[k-1]-s->an[k]*s->q[k+nx]-s->as[k]*s->q[k-nx];corr[k]=(s->b[k]-Aq)/s->ap[k];}
 #pragma omp parallel for collapse(2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++){int ic=(i/stride)*stride,jc=(j/stride)*stride;if(ic<1)ic=stride;if(jc<1)jc=stride;if(ic>=nx-1)ic=nx-1-stride;if(jc>=ny-1)jc=ny-1-stride;s->q[IDX(i,j,nx)]+=omega*corr[IDX(ic,jc,nx)];}}
 free(corr);}
static int solve(Sys*s,const char*solver,double tol,int maxit){int it=0;if(strcmp(solver,"SG_RBGS")==0){while(it<maxit&&residual(s)>tol){rbgs(s,2);it+=2;}return it;}while(it<maxit&&residual(s)>tol){if(strcmp(solver,"MG2V")==0){rbgs(s,1);smooth_correction(s,2,1,0.20);rbgs(s,2);it+=3;}else if(strcmp(solver,"MG2W")==0){rbgs(s,1);smooth_correction(s,2,2,0.16);rbgs(s,2);it+=4;}else if(strcmp(solver,"MG3V")==0){rbgs(s,1);smooth_correction(s,4,1,0.12);smooth_correction(s,2,1,0.18);rbgs(s,2);it+=4;}else { /* RMT3H: no presmoothing, 3x3 shifted family injection followed by post smoothing. */ for(int sy=0;sy<3;sy++)for(int sx=0;sx<3;sx++){int nx=s->nx,ny=s->ny;
 #pragma omp parallel for collapse(2)
   for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++)if(i%3==sx&&j%3==sy){int k=IDX(i,j,nx);double Aq=s->ap[k]*s->q[k]-s->ae[k]*s->q[k+1]-s->aw[k]*s->q[k-1]-s->an[k]*s->q[k+nx]-s->as[k]*s->q[k-nx];s->q[k]+=0.12*(s->b[k]-Aq)/s->ap[k];}}rbgs(s,3);it+=4;}if(!isfinite(residual(s)))break;}if(residual(s)>tol){while(it<maxit&&residual(s)>tol){rbgs(s,4);it+=4;}}return it;}
static void norms(Sys*s,double*L1,double*L2,double*Li){double a=0,b=0,c=0;size_t n=(size_t)s->nx*s->ny;
 #pragma omp parallel for reduction(+:a,b) reduction(max:c)
 for(size_t k=0;k<n;k++){double e=fabs(s->q[k]-s->exact[k]);a+=e;b+=e*e;if(e>c)c=e;}*L1=a/n;*L2=sqrt(b/n);*Li=c;}
static void init_zero(Sys*s){for(int j=1;j<s->ny-1;j++)for(int i=1;i<s->nx-1;i++)s->q[IDX(i,j,s->nx)]=0.0;}
static void onevar(int nx,int ny,int st,char var,const char*solver,double *L1,double*L2,double*Li,int*its,double*tm,double*rr){Sys s;allocsys(&s,nx,ny);assemble(&s,var,st);init_zero(&s);double t=wall();*its=solve(&s,solver,1e-9,20000);*tm=wall()-t;*rr=residual(&s);norms(&s,L1,L2,Li);freesys(&s);}
static int finite_sources(int st){for(int j=0;j<9;j++)for(int i=0;i<17;i++){double xx=3.0*i/16.0,yy=j/8.0;double vals[8]={mms_rho(xx,yy,st),mms_diff(xx,yy,st),srcvar('f',xx,yy,st),srcvar('o',xx,yy,st),srcvar('p',xx,yy,st),srcvar('u',xx,yy,st),srcvar('v',xx,yy,st),srcvar('h',xx,yy,st)};for(int k=0;k<8;k++)if(!isfinite(vals[k]))return 0;}return 1;}
int main(int argc,char**argv){int nx=36,ny=12,st=1;const char*solver="SG_RBGS";const char*out="case_summary.csv";for(int a=1;a<argc;a++){if(!strcmp(argv[a],"--Nx")&&a+1<argc)nx=atoi(argv[++a]);else if(!strcmp(argv[a],"--Ny")&&a+1<argc)ny=atoi(argv[++a]);else if(!strcmp(argv[a],"--stiffness")&&a+1<argc){const char*z=argv[++a];st=z[1]-'0';}else if(!strcmp(argv[a],"--solver")&&a+1<argc)solver=argv[++a];else if(!strcmp(argv[a],"--out")&&a+1<argc)out=argv[++a];}
 if(nx<12||ny<8||st<1||st>3)die("bad args");if(!finite_sources(st))die("nonfinite MMS source");char vars[4];int nv=1;if(BENCH_ID=='A'){vars[0]='a';}else if(BENCH_ID=='B'){vars[0]='u';vars[1]='v';nv=2;}else if(BENCH_ID=='C'){vars[0]='f';vars[1]='o';vars[2]='p';nv=3;}else{vars[0]='f';vars[1]='o';vars[2]='p';vars[3]='h';nv=4;}
 double maxL1=0,maxL2=0,maxLi=0,tot=0,rr=0;int its=0;for(int z=0;z<nv;z++){double l1,l2,li,t,r;int it;onevar(nx,ny,st,vars[z],solver,&l1,&l2,&li,&it,&t,&r);if(l1>maxL1)maxL1=l1;if(l2>maxL2)maxL2=l2;if(li>maxLi)maxLi=li;if(r>rr)rr=r;tot+=t;its+=it;}
 FILE*f=fopen(out,"w");if(!f)die("cannot open output");fprintf(f,"benchmark,stiffness,Nx,Ny,threads,solver,converged,iterations,relative_residual,L1,L2,Linf,solve_wall_time\n");fprintf(f,"%c,S%d,%d,%d,%d,%s,%d,%d,%.12e,%.12e,%.12e,%.12e,%.9f\n",BENCH_ID,st,nx,ny,omp_get_max_threads(),solver,rr<1e-7,its,rr,maxL1,maxL2,maxLi,tot);fclose(f);printf("BENCH=%c solver=%s residual=%.3e L2=%.3e time=%.6f\n",BENCH_ID,solver,rr,maxL2,tot);return rr<1e-6?0:3;}
