| Benchmark | Block | Visual character |
|---|---|---|
| A | Pressure projection | multi-lobed / saddle pressure |
| B | Momentum | opposed stagnation + vortex |
| C | Species transport | fuel/oxidizer mixing layer + product band |
| D | Thermochemistry + energy | localized curved flame sheet |
