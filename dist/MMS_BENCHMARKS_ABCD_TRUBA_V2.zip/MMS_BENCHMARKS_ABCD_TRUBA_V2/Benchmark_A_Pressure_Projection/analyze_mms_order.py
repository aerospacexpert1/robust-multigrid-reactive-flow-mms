import math
def order(eh,eh2): return math.log(eh/eh2)/math.log(2.0)
print('p_obs=log(E_h/E_h2)/log(2)')
