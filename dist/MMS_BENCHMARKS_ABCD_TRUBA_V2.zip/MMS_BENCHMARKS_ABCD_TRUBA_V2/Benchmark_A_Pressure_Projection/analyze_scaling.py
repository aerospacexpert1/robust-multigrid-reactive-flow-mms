import csv,collections
print('Scaling analysis reads campaign_summary.csv and groups solver wall time by threads; field I/O is outside solver timing.')
