#!/usr/bin/env bash
set -euo pipefail
echo "completed=$(find results -name completed 2>/dev/null | wc -l) / 300"
