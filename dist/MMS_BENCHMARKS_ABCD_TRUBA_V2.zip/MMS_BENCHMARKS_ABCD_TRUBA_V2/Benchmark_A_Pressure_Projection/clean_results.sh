#!/usr/bin/env bash
set -euo pipefail
rm -rf results/* logs/* build/*
