import glob,csv
fs=glob.glob('results/**/case_summary.csv',recursive=True);rows=[]
for f in fs: rows += list(csv.DictReader(open(f)))
if rows:
 w=csv.DictWriter(open('campaign_summary.csv','w',newline=''),fieldnames=rows[0]);w.writeheader();w.writerows(rows)
print('rows',len(rows))
