# S1 / S2 / S3 parameters

S1=Low, S2=Medium, S3=High. Difficulty changes physical coefficients/gradients, not solver tolerance.
