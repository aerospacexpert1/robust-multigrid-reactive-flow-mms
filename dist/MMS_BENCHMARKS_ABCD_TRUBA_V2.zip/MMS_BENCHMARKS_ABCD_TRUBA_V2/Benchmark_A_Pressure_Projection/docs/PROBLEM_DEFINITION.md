# Pressure Projection / Continuity

Variable-density pressure-correction elliptic operator: -div((1/rho*) grad p*) = S_MMS. Exact pressure is a multi-lobed saddle field. The additive pressure null-space is removed by analytic Dirichlet traces in the MMS mode; production projection correspondence is documented separately.
