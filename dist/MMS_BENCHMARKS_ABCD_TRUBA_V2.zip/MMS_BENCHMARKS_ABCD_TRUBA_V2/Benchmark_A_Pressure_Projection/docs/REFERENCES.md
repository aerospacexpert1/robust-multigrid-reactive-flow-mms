# References

- Oberkampf, W. L. & Roy, C. J. (2010), *Verification and Validation in Scientific Computing*, Cambridge University Press. MMS and systematic mesh refinement: Chapters 5–6.
- Martynenko, S. I. (2006), “Robust Multigrid Technique for Black Box Software”, *Computational Methods in Applied Mathematics*, 6(4), 413–435.
- Martynenko, S. I. (2017), *The Robust Multigrid Technique: For Black-Box Software*, De Gruyter. DOI: 10.1515/9783110539264.
- Trottenberg, U., Oosterlee, C. & Schüller, A. (2001), *Multigrid*, Academic Press.
- Shunn, L., Ham, F. & Moin, P. (2012), “Verification of variable-density flow solvers using manufactured solutions”, *Journal of Computational Physics* 231, 3801–3827. DOI: 10.1016/j.jcp.2012.01.027.
- Vedovoto, J. M. et al. (2011), “Application of the method of manufactured solutions to the verification of a pressure-based finite-volume numerical scheme”, *Computers & Fluids* 51, 85–99. DOI: 10.1016/j.compfluid.2011.07.014.
