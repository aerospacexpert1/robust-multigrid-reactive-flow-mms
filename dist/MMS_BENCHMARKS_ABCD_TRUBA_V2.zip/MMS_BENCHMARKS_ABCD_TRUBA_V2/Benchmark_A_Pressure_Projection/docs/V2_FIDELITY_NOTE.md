# V2 production-fidelity corrections

- **A** uses the production low-Mach pressure-correction Laplacian and reconstructs predictor mass flux, numerical pressure correction, corrected flux and a discrete continuity defect. Density is manufactured in the predictor/corrector chain; it is not used to invent a variable-k Poisson equation.
- **B** keeps the known pressure gradient in the momentum predictor and verifies the conservative advection-diffusion operator for both u and v.
- **C** verifies chemistry-off YF/YO/YP transport.
- **D** is an energy/thermochemistry isolation MMS: YF/YO/YP are prescribed manufactured composition fields (their transport is verified in C), while sensible enthalpy is the numerical unknown. Each Picard update recomputes T(h,Y), low-Mach perfect-gas density and Arrhenius heat release. Raw h error and derived T/rho absolute and relative errors are reported.
- RMT3H is a production-aligned factor-three multiple-shifted-grid benchmark adaptation: no presmoothing, control-volume defect restriction, direct coarsest solves, 16 post-smoothing sweeps, and full correction without interpolation, damping, line search, rollback, or hidden fallback.
- A is the direct production pressure-solver comparison. Applying the five solver kernels to B/C/D is explicitly an **operator-solver extension** for numerical-method study, not a claim that the production opposed-flow executable switches those transport blocks among five solver families.

Continuous MMS sources are derived before discretization; no `b_h=A_h phi_exact` construction is used.
