#!/usr/bin/env bash
set -euo pipefail
python3 tools/list_unfinished.py
