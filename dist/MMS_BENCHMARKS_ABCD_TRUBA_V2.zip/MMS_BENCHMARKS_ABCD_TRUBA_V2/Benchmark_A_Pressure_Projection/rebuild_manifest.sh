#!/usr/bin/env bash
set -euo pipefail
python3 tools/rebuild_manifest.py
