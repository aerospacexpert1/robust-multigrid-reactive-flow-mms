#!/usr/bin/env bash
set -euo pipefail
idx="\${1:?task index required}"
IFS=, read -r task stiffness mesh Nx Ny tlabel threads solver < <(awk -F, -v n=$((idx+2)) 'NR==n{print $0}' campaign_manifest.csv)
[ -n "\${task:-}" ] || { echo "task not found" >&2; exit 2; }
export OMP_NUM_THREADS="$threads" OMP_THREAD_LIMIT="$threads"
out="results/\${stiffness}/\${mesh}/\${tlabel}/\${solver}"; mkdir -p "$out" logs
if [[ -f "$out/completed" && -s "$out/case_summary.csv" ]]; then
  echo "SKIP completed task=$idx solver=$solver mesh=$mesh threads=$threads"
  exit 0
fi
touch "$out/started"; rm -f "$out/completed" "$out/failed" "$out/nonconverged"
set +e
field_args=(); if [[ "$mesh" == "M3" && "$tlabel" == "T1" && "$solver" == "RMT3H" ]]; then field_args=(--field-out "$out/field.csv"); fi
./build/mms_solver --Nx "$Nx" --Ny "$Ny" --stiffness "$stiffness" --solver "$solver" --out "$out/case_summary.csv" "${field_args[@]}" >"$out/run.log" 2>&1
rc=$?
set -e
printf '%s
' "$rc" > "$out/solver_exit_code"
if [[ "$rc" -eq 0 || "$rc" -eq 3 ]]; then
  touch "$out/completed"
  if [[ "$rc" -eq 3 ]]; then
    touch "$out/nonconverged"
    echo "NONCONVERGED recorded as benchmark data: task=$idx solver=$solver" >&2
  fi
  exit 0
fi
touch "$out/failed"
exit "$rc"
