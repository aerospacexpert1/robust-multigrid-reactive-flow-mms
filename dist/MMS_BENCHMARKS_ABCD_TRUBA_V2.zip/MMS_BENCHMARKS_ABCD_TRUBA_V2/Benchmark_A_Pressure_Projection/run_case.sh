#!/usr/bin/env bash
set -euo pipefail
idx="${1:?task index required}"
IFS=, read -r task stiffness mesh Nx Ny tlabel threads solver < <(awk -F, -v n=$((idx+2)) 'NR==n{print $0}' campaign_manifest.csv)
[ -n "${task:-}" ] || { echo "task not found" >&2; exit 2; }
export OMP_NUM_THREADS="$threads" OMP_THREAD_LIMIT="$threads"
out="results/${stiffness}/${mesh}/${tlabel}/${solver}"; mkdir -p "$out" logs
touch "$out/started"; rm -f "$out/completed"
field_args=(); if [[ "$mesh" == "M3" && "$tlabel" == "T1" && "$solver" == "RMT3H" ]]; then field_args=(--field-out "$out/field.csv"); fi
./build/mms_solver --Nx "$Nx" --Ny "$Ny" --stiffness "$stiffness" --solver "$solver" --out "$out/case_summary.csv" "${field_args[@]}" >"$out/run.log" 2>&1
touch "$out/completed"
