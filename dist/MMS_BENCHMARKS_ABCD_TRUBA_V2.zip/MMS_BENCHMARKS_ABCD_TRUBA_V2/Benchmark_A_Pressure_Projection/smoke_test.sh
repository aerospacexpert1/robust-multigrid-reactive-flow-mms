#!/usr/bin/env bash
set -euo pipefail
./build.sh
rm -rf results/_smoke; mkdir -p results/_smoke
for s in SG_RBGS MG2V MG2W MG3V RMT3H; do
  OMP_NUM_THREADS=1 OMP_THREAD_LIMIT=1 ./build/mms_solver --Nx 108 --Ny 36 --stiffness S1 --solver "$s" --out "results/_smoke/${s}.csv" >"results/_smoke/${s}.log" 2>&1
  grep -q ',1,' "results/_smoke/${s}.csv"
done
echo SMOKE_PASS
