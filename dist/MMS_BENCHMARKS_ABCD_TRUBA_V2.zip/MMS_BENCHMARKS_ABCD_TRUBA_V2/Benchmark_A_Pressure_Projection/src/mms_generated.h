#pragma once
#include <math.h>
#ifndef M_PI
#define M_PI 3.141592653589793238462643383279502884
#endif
/* Generated from continuous symbolic operators by tools/generate_mms_package.py. */
static inline double mms_diff(double x,double y,int s){
  switch(s){
    case 1: return 1.0/(0.080000000000000002*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1);
    case 2: return 1.0/(0.20000000000000001*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1);
    case 3: return 1.0/(0.34999999999999998*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1);
    default: return 0.0;
  }
}
static inline double mms_k(double x,double y,int s){
  switch(s){
    case 1: return 1.0/(0.080000000000000002*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1);
    case 2: return 1.0/(0.20000000000000001*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1);
    case 3: return 1.0/(0.34999999999999998*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1);
    default: return 0.0;
  }
}
static inline double mms_p(double x,double y,int s){
  switch(s){
    case 1: return 0.16000000000000003*pow(0.33333333333333331*x - 1.0/2.0, 2) - 0.16000000000000003*pow(1.0*y - 1.0/2.0, 2) + 0.80000000000000004*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 0.27999999999999997*cos(M_PI*x)*cos(M_PI*y);
    case 2: return 0.23999999999999999*pow(0.33333333333333331*x - 1.0/2.0, 2) - 0.23999999999999999*pow(1.0*y - 1.0/2.0, 2) + 1.2*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 0.41999999999999998*cos(M_PI*x)*cos(M_PI*y);
    case 3: return 0.36000000000000004*pow(0.33333333333333331*x - 1.0/2.0, 2) - 0.36000000000000004*pow(1.0*y - 1.0/2.0, 2) + 1.8*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 0.63*cos(M_PI*x)*cos(M_PI*y);
    default: return 0.0;
  }
}
static inline double mms_rho(double x,double y,int s){
  switch(s){
    case 1: return 0.080000000000000002*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1;
    case 2: return 0.20000000000000001*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1;
    case 3: return 0.34999999999999998*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1;
    default: return 0.0;
  }
}
static inline double mms_src_p(double x,double y,int s){
  switch(s){
    case 1: return 3.5555555555555558*pow(M_PI, 2)*sin((2.0/3.0)*M_PI*x)*sin(2*M_PI*y) + 0.55999999999999994*pow(M_PI, 2)*cos(M_PI*x)*cos(M_PI*y) + 0.2844444444444445;
    case 2: return 5.333333333333333*pow(M_PI, 2)*sin((2.0/3.0)*M_PI*x)*sin(2*M_PI*y) + 0.83999999999999997*pow(M_PI, 2)*cos(M_PI*x)*cos(M_PI*y) + 0.42666666666666664;
    case 3: return 8.0*pow(M_PI, 2)*sin((2.0/3.0)*M_PI*x)*sin(2*M_PI*y) + 1.26*pow(M_PI, 2)*cos(M_PI*x)*cos(M_PI*y) + 0.64000000000000012;
    default: return 0.0;
  }
}
static inline double mms_uadv(double x,double y,int s){
  switch(s){
    case 1: return 0;
    case 2: return 0;
    case 3: return 0;
    default: return 0.0;
  }
}
static inline double mms_vadv(double x,double y,int s){
  switch(s){
    case 1: return 0;
    case 2: return 0;
    case 3: return 0;
    default: return 0.0;
  }
}

static inline double mms_u(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_v(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_YF(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_YO(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_YP(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_h(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_T(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_src_u(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_src_v(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_src_YF(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_src_YO(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_src_YP(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_src_h(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_rate(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_arrA(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_arrBeta(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_arrTa(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}

/* V2 pressure-projection manufactured fields. */
static inline double mms_u_corr(double x,double y,int s){
  switch(s){
    case 1: return -0.17999999999999999*x + 0.059999999999999998*sin((2.0/3.0)*M_PI*x)*sin(2*M_PI*y) + 0.27000000000000002;
    case 2: return -0.17999999999999999*x + 0.059999999999999998*sin((2.0/3.0)*M_PI*x)*sin(2*M_PI*y) + 0.27000000000000002;
    case 3: return -0.17999999999999999*x + 0.059999999999999998*sin((2.0/3.0)*M_PI*x)*sin(2*M_PI*y) + 0.27000000000000002;
    default: return 0.0;
  }
}
static inline double mms_v_corr(double x,double y,int s){
  switch(s){
    case 1: return 0.17999999999999999*y - 0.059999999999999998*sin(2*M_PI*y)*cos((2.0/3.0)*M_PI*x) - 0.089999999999999997;
    case 2: return 0.17999999999999999*y - 0.059999999999999998*sin(2*M_PI*y)*cos((2.0/3.0)*M_PI*x) - 0.089999999999999997;
    case 3: return 0.17999999999999999*y - 0.059999999999999998*sin(2*M_PI*y)*cos((2.0/3.0)*M_PI*x) - 0.089999999999999997;
    default: return 0.0;
  }
}
static inline double mms_mass_src(double x,double y,int s){
  switch(s){
    case 1: return (0.080000000000000002*sin((2.0/3.0)*M_PI*x)*cos(2*M_PI*y) + 1)*(0.039999999999999994*M_PI*sin(2*M_PI*y)*cos((2.0/3.0)*M_PI*x) - 0.17999999999999999) - (0.080000000000000002*sin((2.0/3.0)*M_PI*x)*cos(2*M_PI*y) + 1)*(0.12*M_PI*cos((2.0/3.0)*M_PI*x)*cos(2*M_PI*y) - 0.17999999999999999) + 0.05333333333333333*M_PI*(-0.17999999999999999*x + 0.059999999999999998*sin((2.0/3.0)*M_PI*x)*sin(2*M_PI*y) + 0.27000000000000002)*cos((2.0/3.0)*M_PI*x)*cos(2*M_PI*y) + 0.16*M_PI*(-0.17999999999999999*y + 0.059999999999999998*sin(2*M_PI*y)*cos((2.0/3.0)*M_PI*x) + 0.089999999999999997)*sin((2.0/3.0)*M_PI*x)*sin(2*M_PI*y);
    case 2: return (0.20000000000000001*sin((2.0/3.0)*M_PI*x)*cos(2*M_PI*y) + 1)*(0.039999999999999994*M_PI*sin(2*M_PI*y)*cos((2.0/3.0)*M_PI*x) - 0.17999999999999999) - (0.20000000000000001*sin((2.0/3.0)*M_PI*x)*cos(2*M_PI*y) + 1)*(0.12*M_PI*cos((2.0/3.0)*M_PI*x)*cos(2*M_PI*y) - 0.17999999999999999) + 0.13333333333333333*M_PI*(-0.17999999999999999*x + 0.059999999999999998*sin((2.0/3.0)*M_PI*x)*sin(2*M_PI*y) + 0.27000000000000002)*cos((2.0/3.0)*M_PI*x)*cos(2*M_PI*y) + 0.40000000000000002*M_PI*(-0.17999999999999999*y + 0.059999999999999998*sin(2*M_PI*y)*cos((2.0/3.0)*M_PI*x) + 0.089999999999999997)*sin((2.0/3.0)*M_PI*x)*sin(2*M_PI*y);
    case 3: return (0.34999999999999998*sin((2.0/3.0)*M_PI*x)*cos(2*M_PI*y) + 1)*(0.039999999999999994*M_PI*sin(2*M_PI*y)*cos((2.0/3.0)*M_PI*x) - 0.17999999999999999) - (0.34999999999999998*sin((2.0/3.0)*M_PI*x)*cos(2*M_PI*y) + 1)*(0.12*M_PI*cos((2.0/3.0)*M_PI*x)*cos(2*M_PI*y) - 0.17999999999999999) + 0.23333333333333331*M_PI*(-0.17999999999999999*x + 0.059999999999999998*sin((2.0/3.0)*M_PI*x)*sin(2*M_PI*y) + 0.27000000000000002)*cos((2.0/3.0)*M_PI*x)*cos(2*M_PI*y) + 0.69999999999999996*M_PI*(-0.17999999999999999*y + 0.059999999999999998*sin(2*M_PI*y)*cos((2.0/3.0)*M_PI*x) + 0.089999999999999997)*sin((2.0/3.0)*M_PI*x)*sin(2*M_PI*y);
    default: return 0.0;
  }
}
static inline double mms_dpx(double x,double y,int s){
  switch(s){
    case 1: return 0.035555555555555562*x - 0.27999999999999997*M_PI*sin(M_PI*x)*cos(M_PI*y) + 0.53333333333333333*M_PI*sin(2*M_PI*y)*cos((2.0/3.0)*M_PI*x) - 0.053333333333333344;
    case 2: return 0.05333333333333333*x - 0.41999999999999998*M_PI*sin(M_PI*x)*cos(M_PI*y) + 0.79999999999999993*M_PI*sin(2*M_PI*y)*cos((2.0/3.0)*M_PI*x) - 0.079999999999999988;
    case 3: return 0.080000000000000002*x - 0.63*M_PI*sin(M_PI*x)*cos(M_PI*y) + 1.2*M_PI*sin(2*M_PI*y)*cos((2.0/3.0)*M_PI*x) - 0.12000000000000001;
    default: return 0.0;
  }
}
static inline double mms_dpy(double x,double y,int s){
  switch(s){
    case 1: return -0.32000000000000006*y + 1.6000000000000001*M_PI*sin((2.0/3.0)*M_PI*x)*cos(2*M_PI*y) - 0.27999999999999997*M_PI*sin(M_PI*y)*cos(M_PI*x) + 0.16000000000000003;
    case 2: return -0.47999999999999998*y + 2.3999999999999999*M_PI*sin((2.0/3.0)*M_PI*x)*cos(2*M_PI*y) - 0.41999999999999998*M_PI*sin(M_PI*y)*cos(M_PI*x) + 0.23999999999999999;
    case 3: return -0.72000000000000008*y + 3.6000000000000001*M_PI*sin((2.0/3.0)*M_PI*x)*cos(2*M_PI*y) - 0.63*M_PI*sin(M_PI*y)*cos(M_PI*x) + 0.36000000000000004;
    default: return 0.0;
  }
}

static inline double mms_pdx(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_pdy(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
