#!/usr/bin/env bash
set -euo pipefail
mkdir -p logs
sbatch benchmark_A_array.slurm
