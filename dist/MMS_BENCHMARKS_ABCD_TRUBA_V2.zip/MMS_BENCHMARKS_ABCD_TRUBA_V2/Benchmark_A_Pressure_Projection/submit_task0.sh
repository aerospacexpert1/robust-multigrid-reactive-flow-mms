#!/usr/bin/env bash
set -euo pipefail
mkdir -p logs
sbatch --array=0 benchmark_A_array.slurm
