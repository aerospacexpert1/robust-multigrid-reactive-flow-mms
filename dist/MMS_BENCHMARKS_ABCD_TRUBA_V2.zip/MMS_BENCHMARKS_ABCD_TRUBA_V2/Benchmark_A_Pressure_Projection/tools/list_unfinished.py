import csv,os
for r in csv.DictReader(open('campaign_manifest.csv')):
 p=f"results/{r['stiffness']}/{r['mesh']}/{r['thread_label']}/{r['solver']}/completed"
 if not os.path.exists(p): print(r['task_id'],p)
