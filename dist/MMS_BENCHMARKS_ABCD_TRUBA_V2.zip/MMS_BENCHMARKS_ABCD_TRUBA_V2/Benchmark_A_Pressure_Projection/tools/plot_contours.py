#!/usr/bin/env python3
import argparse,csv
import numpy as np
import matplotlib.pyplot as plt
p=argparse.ArgumentParser();p.add_argument('--field',required=True);p.add_argument('--mode',choices=['exact','numerical','error'],required=True);p.add_argument('--output',required=True);a=p.parse_args()
r=list(csv.DictReader(open(a.field))); xs=sorted({float(z['x']) for z in r});ys=sorted({float(z['y']) for z in r}); ix={v:i for i,v in enumerate(xs)};iy={v:i for i,v in enumerate(ys)};Z=np.zeros((len(ys),len(xs)))
for z in r:
 v=float(z['exact'] if a.mode=='exact' else z['numerical'] if a.mode=='numerical' else z['error']);Z[iy[float(z['y'])],ix[float(z['x'])]]=abs(v) if a.mode=='error' else v
X,Y=np.meshgrid(xs,ys);plt.figure(figsize=(7,2.8));plt.contourf(X,Y,Z,40);plt.colorbar();plt.xlabel('x');plt.ylabel('y');plt.tight_layout();plt.savefig(a.output,dpi=130);plt.close()
