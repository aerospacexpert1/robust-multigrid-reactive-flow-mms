print('Manifest is generated deterministically by top-level tools/generate_mms_package.py; rerun that generator to rebuild.')
