import csv,sys,collections
p=sys.argv[1];r=list(csv.DictReader(open(p)));assert len(r)==300
for k,exp in [('stiffness',{'S1':100,'S2':100,'S3':100}),('thread_label',{'T1':75,'T2':75,'T4':75,'T16':75}),('mesh',{'M1':60,'M2':60,'M3':60,'M4':60,'M5':60}),('solver',{'SG_RBGS':60,'MG2V':60,'MG2W':60,'MG3V':60,'RMT3H':60})]: assert dict(collections.Counter(x[k] for x in r))==exp,(k,collections.Counter(x[k] for x in r))
assert len({(x['stiffness'],x['mesh'],x['thread_label']) for x in r})==60
print('MANIFEST_PASS')
