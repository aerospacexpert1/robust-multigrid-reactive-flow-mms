#!/usr/bin/env bash
set -euo pipefail
python3 tools/verify_manifest.py campaign_manifest.csv
for f in *.sh *.slurm; do bash -n "$f"; done
python3 -m py_compile collect_summary.py analyze_scaling.py analyze_mms_order.py tools/*.py
grep -q '#SBATCH --cpus-per-task=56' benchmark_?_array.slurm
grep -q 'SLURM_SUBMIT_DIR' benchmark_?_array.slurm
grep -q 'OMP_NUM_THREADS' run_case.sh
echo VERIFY_PASS
