# Momentum

Two conservative variable-density momentum-component equations are verified: div(rho U u)-div(mu grad u)+dp/dx=S_u and div(rho U v)-div(mu grad v)+dp/dy=S_v. The exact field combines opposed stagnation and a 2-D vortical perturbation.
