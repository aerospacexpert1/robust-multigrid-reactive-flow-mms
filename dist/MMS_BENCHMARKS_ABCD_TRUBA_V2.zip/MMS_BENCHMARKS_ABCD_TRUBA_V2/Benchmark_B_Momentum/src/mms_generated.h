#pragma once
#include <math.h>
#ifndef M_PI
#define M_PI 3.141592653589793238462643383279502884
#endif
/* Generated from continuous symbolic operators by tools/generate_mms_package.py. */
static inline double mms_diff(double x,double y,int s){
  switch(s){
    case 1: return 0.025000000000000001;
    case 2: return 0.014999999999999999;
    case 3: return 0.0080000000000000002;
    default: return 0.0;
  }
}
static inline double mms_p(double x,double y,int s){
  switch(s){
    case 1: return 0.12*sin(2*M_PI*y)*cos(0.33333333333333331*M_PI*x);
    case 2: return 0.12*sin(2*M_PI*y)*cos(0.33333333333333331*M_PI*x);
    case 3: return 0.12*sin(2*M_PI*y)*cos(0.33333333333333331*M_PI*x);
    default: return 0.0;
  }
}
static inline double mms_rho(double x,double y,int s){
  switch(s){
    case 1: return 0.029999999999999999*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1;
    case 2: return 0.10000000000000001*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1;
    case 3: return 0.20000000000000001*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1;
    default: return 0.0;
  }
}
static inline double mms_src_u(double x,double y,int s){
  switch(s){
    case 1: return (0.029999999999999999*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1)*(0.10666666666666666*M_PI*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 1.0)*(-0.5*x + 0.080000000000000002*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 0.75) + (0.029999999999999999*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1)*(-0.16*M_PI*cos(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 0.5)*(-0.5*x + 0.080000000000000002*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 0.75) + 0.16*M_PI*(0.029999999999999999*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1)*(0.5*y - 0.080000000000000002*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.25)*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) - 0.019999999999999997*M_PI*pow(-0.5*x + 0.080000000000000002*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 0.75, 2)*sin(0.66666666666666663*M_PI*x)*cos(M_PI*y) - 0.029999999999999999*M_PI*(-0.5*x + 0.080000000000000002*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 0.75)*(0.5*y - 0.080000000000000002*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.25)*sin(M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.039999999999999994*M_PI*sin(0.33333333333333331*M_PI*x)*sin(2*M_PI*y) + 0.0088888888888888889*pow(M_PI, 2)*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y);
    case 2: return (0.10000000000000001*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1)*(0.19999999999999998*M_PI*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 2.0)*(-1.0*x + 0.14999999999999999*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 1.5) + (0.10000000000000001*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1)*(-0.29999999999999999*M_PI*cos(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1.0)*(-1.0*x + 0.14999999999999999*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 1.5) + 0.29999999999999999*M_PI*(0.10000000000000001*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1)*(1.0*y - 0.14999999999999999*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.5)*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) - 0.066666666666666666*M_PI*pow(-1.0*x + 0.14999999999999999*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 1.5, 2)*sin(0.66666666666666663*M_PI*x)*cos(M_PI*y) - 0.10000000000000001*M_PI*(-1.0*x + 0.14999999999999999*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 1.5)*(1.0*y - 0.14999999999999999*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.5)*sin(M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.039999999999999994*M_PI*sin(0.33333333333333331*M_PI*x)*sin(2*M_PI*y) + 0.0099999999999999985*pow(M_PI, 2)*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y);
    case 3: return (0.20000000000000001*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1)*(0.33333333333333331*M_PI*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 3.6000000000000001)*(-1.8*x + 0.25*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 2.7000000000000002) + (0.20000000000000001*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1)*(-0.5*M_PI*cos(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1.8)*(-1.8*x + 0.25*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 2.7000000000000002) + 0.5*M_PI*(0.20000000000000001*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1)*(1.8*y - 0.25*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.90000000000000002)*sin(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) - 0.13333333333333333*M_PI*pow(-1.8*x + 0.25*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 2.7000000000000002, 2)*sin(0.66666666666666663*M_PI*x)*cos(M_PI*y) - 0.20000000000000001*M_PI*(-1.8*x + 0.25*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 2.7000000000000002)*(1.8*y - 0.25*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.90000000000000002)*sin(M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.039999999999999994*M_PI*sin(0.33333333333333331*M_PI*x)*sin(2*M_PI*y) + 0.0088888888888888889*pow(M_PI, 2)*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y);
    default: return 0.0;
  }
}
static inline double mms_src_v(double x,double y,int s){
  switch(s){
    case 1: return (0.029999999999999999*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1)*(0.05333333333333333*M_PI*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.5)*(0.5*y - 0.080000000000000002*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.25) + (0.029999999999999999*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1)*(-0.32000000000000001*M_PI*cos(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 1.0)*(0.5*y - 0.080000000000000002*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.25) + 0.05333333333333333*M_PI*(0.029999999999999999*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1)*(-0.5*x + 0.080000000000000002*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 0.75)*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) - 0.019999999999999997*M_PI*(-0.5*x + 0.080000000000000002*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 0.75)*(0.5*y - 0.080000000000000002*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.25)*sin(0.66666666666666663*M_PI*x)*cos(M_PI*y) - 0.029999999999999999*M_PI*pow(0.5*y - 0.080000000000000002*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.25, 2)*sin(M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.0088888888888888889*pow(M_PI, 2)*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) + 0.23999999999999999*M_PI*cos(0.33333333333333331*M_PI*x)*cos(2*M_PI*y);
    case 2: return (0.10000000000000001*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1)*(0.099999999999999992*M_PI*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 1.0)*(1.0*y - 0.14999999999999999*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.5) + (0.10000000000000001*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1)*(-0.59999999999999998*M_PI*cos(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 2.0)*(1.0*y - 0.14999999999999999*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.5) + 0.099999999999999992*M_PI*(0.10000000000000001*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1)*(-1.0*x + 0.14999999999999999*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 1.5)*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) - 0.066666666666666666*M_PI*(-1.0*x + 0.14999999999999999*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 1.5)*(1.0*y - 0.14999999999999999*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.5)*sin(0.66666666666666663*M_PI*x)*cos(M_PI*y) - 0.10000000000000001*M_PI*pow(1.0*y - 0.14999999999999999*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.5, 2)*sin(M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.0099999999999999985*pow(M_PI, 2)*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) + 0.23999999999999999*M_PI*cos(0.33333333333333331*M_PI*x)*cos(2*M_PI*y);
    case 3: return (0.20000000000000001*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1)*(0.16666666666666666*M_PI*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 1.8)*(1.8*y - 0.25*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.90000000000000002) + (0.20000000000000001*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1)*(-1.0*M_PI*cos(0.66666666666666663*M_PI*x)*cos(2*M_PI*y) + 3.6000000000000001)*(1.8*y - 0.25*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.90000000000000002) + 0.16666666666666666*M_PI*(0.20000000000000001*cos(0.66666666666666663*M_PI*x)*cos(M_PI*y) + 1)*(-1.8*x + 0.25*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 2.7000000000000002)*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) - 0.13333333333333333*M_PI*(-1.8*x + 0.25*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 2.7000000000000002)*(1.8*y - 0.25*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.90000000000000002)*sin(0.66666666666666663*M_PI*x)*cos(M_PI*y) - 0.20000000000000001*M_PI*pow(1.8*y - 0.25*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.90000000000000002, 2)*sin(M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.0088888888888888889*pow(M_PI, 2)*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) + 0.23999999999999999*M_PI*cos(0.33333333333333331*M_PI*x)*cos(2*M_PI*y);
    default: return 0.0;
  }
}
static inline double mms_u(double x,double y,int s){
  switch(s){
    case 1: return -0.5*x + 0.080000000000000002*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 0.75;
    case 2: return -1.0*x + 0.14999999999999999*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 1.5;
    case 3: return -1.8*x + 0.25*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 2.7000000000000002;
    default: return 0.0;
  }
}
static inline double mms_uadv(double x,double y,int s){
  switch(s){
    case 1: return -0.5*x + 0.080000000000000002*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 0.75;
    case 2: return -1.0*x + 0.14999999999999999*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 1.5;
    case 3: return -1.8*x + 0.25*sin(0.66666666666666663*M_PI*x)*sin(2*M_PI*y) + 2.7000000000000002;
    default: return 0.0;
  }
}
static inline double mms_v(double x,double y,int s){
  switch(s){
    case 1: return 0.5*y - 0.080000000000000002*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.25;
    case 2: return 1.0*y - 0.14999999999999999*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.5;
    case 3: return 1.8*y - 0.25*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.90000000000000002;
    default: return 0.0;
  }
}
static inline double mms_vadv(double x,double y,int s){
  switch(s){
    case 1: return 0.5*y - 0.080000000000000002*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.25;
    case 2: return 1.0*y - 0.14999999999999999*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.5;
    case 3: return 1.8*y - 0.25*sin(2*M_PI*y)*cos(0.66666666666666663*M_PI*x) - 0.90000000000000002;
    default: return 0.0;
  }
}

static inline double mms_YF(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_YO(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_YP(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_h(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_T(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_k(double x,double y,int s){(void)x;(void)y;(void)s;return mms_diff(x,y,s);}
static inline double mms_src_p(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_src_YF(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_src_YO(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_src_YP(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_src_h(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_rate(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_arrA(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_arrBeta(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_arrTa(double x,double y,int s){(void)x;(void)y;(void)s;return 0.0;}
static inline double mms_dpdx(double x,double y,int s){(void)s;return -0.04*M_PI*sin(M_PI*x/3.0)*sin(2.0*M_PI*y);}
static inline double mms_dpdy(double x,double y,int s){(void)s;return 0.24*M_PI*cos(M_PI*x/3.0)*cos(2.0*M_PI*y);}

/* V2 known pressure-gradient forcing for the momentum predictor. */
static inline double mms_pdx(double x,double y,int s){
  switch(s){
    case 1: return -0.039999999999999994*M_PI*sin((1.0/3.0)*M_PI*x)*sin(2*M_PI*y);
    case 2: return -0.039999999999999994*M_PI*sin((1.0/3.0)*M_PI*x)*sin(2*M_PI*y);
    case 3: return -0.039999999999999994*M_PI*sin((1.0/3.0)*M_PI*x)*sin(2*M_PI*y);
    default: return 0.0;
  }
}
static inline double mms_pdy(double x,double y,int s){
  switch(s){
    case 1: return 0.23999999999999999*M_PI*cos((1.0/3.0)*M_PI*x)*cos(2*M_PI*y);
    case 2: return 0.23999999999999999*M_PI*cos((1.0/3.0)*M_PI*x)*cos(2*M_PI*y);
    case 3: return 0.23999999999999999*M_PI*cos((1.0/3.0)*M_PI*x)*cos(2*M_PI*y);
    default: return 0.0;
  }
}
