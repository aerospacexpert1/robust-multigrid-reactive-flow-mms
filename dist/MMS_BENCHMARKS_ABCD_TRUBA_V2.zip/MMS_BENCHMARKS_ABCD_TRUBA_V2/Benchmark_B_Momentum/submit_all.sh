#!/usr/bin/env bash
set -euo pipefail
mkdir -p logs
sbatch benchmark_B_array.slurm
