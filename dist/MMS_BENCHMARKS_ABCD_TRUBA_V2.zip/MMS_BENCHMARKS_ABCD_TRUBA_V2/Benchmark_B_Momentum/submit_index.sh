#!/usr/bin/env bash
set -euo pipefail
idx="${1:?index}"
mkdir -p logs
sbatch --array="$idx" benchmark_B_array.slurm
