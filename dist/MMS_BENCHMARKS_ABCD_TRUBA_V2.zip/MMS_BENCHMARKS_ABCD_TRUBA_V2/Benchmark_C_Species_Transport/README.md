# Benchmark C — Species Transport

Formal continuous-operator MMS verification campaign.

- Stiffness: S1 Low, S2 Medium, S3 High
- Meshes: 108x36, 216x72, 432x144, 864x288, 1728x576
- Threads: 1, 2, 4, 16
- Solvers: SG_RBGS, MG2V, MG2W, MG3V, RMT3H
- 60 unique physical MMS configurations; 300 solver executions.
