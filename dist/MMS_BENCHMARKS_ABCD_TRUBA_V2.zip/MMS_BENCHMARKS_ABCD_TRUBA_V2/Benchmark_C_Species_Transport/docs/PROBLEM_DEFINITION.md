# Species Transport

Three chemistry-off species transport equations are verified: div(rho U Y_i)-div(D grad Y_i)=S_i. Analytic YF/YO/YP fields form an opposed fuel/oxidizer mixing layer with a curved interface and product band.
