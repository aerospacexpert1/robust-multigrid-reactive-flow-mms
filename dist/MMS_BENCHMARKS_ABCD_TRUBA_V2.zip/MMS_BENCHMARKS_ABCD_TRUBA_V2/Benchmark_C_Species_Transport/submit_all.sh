#!/usr/bin/env bash
set -euo pipefail
mkdir -p logs
echo "Submitting 60 physical groups x 5 solvers = 300 executions"
echo "At most 3 physical groups run concurrently; each group runs its five solvers sequentially on one node."
sbatch benchmark_C_array.slurm
