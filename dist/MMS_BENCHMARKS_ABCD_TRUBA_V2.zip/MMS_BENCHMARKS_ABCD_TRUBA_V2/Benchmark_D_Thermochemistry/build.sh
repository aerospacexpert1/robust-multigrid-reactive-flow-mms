#!/usr/bin/env bash
set -euo pipefail
mkdir -p build
gcc -O2 -std=c11 -fopenmp -Wall -Wextra -pedantic -DBENCH_ID=\'D\' src/mms_solver.c -lm -o build/mms_solver
