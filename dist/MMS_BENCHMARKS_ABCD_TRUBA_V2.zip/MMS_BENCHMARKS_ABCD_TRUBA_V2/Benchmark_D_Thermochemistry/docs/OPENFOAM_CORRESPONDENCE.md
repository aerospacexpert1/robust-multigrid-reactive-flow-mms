# OpenFOAM correspondence

OpenFOAM YEqn + EEqn + thermo/chemistry correspondence. The uploaded v2312 counter-flow reference uses a reacting-flow pressure/velocity coupling workflow; this MMS package isolates the corresponding operator block rather than attempting to reproduce the complete integrated flame in each benchmark.
