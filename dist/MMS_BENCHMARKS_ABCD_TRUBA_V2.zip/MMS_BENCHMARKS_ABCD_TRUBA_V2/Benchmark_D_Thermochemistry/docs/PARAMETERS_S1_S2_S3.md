# S1 / S2 / S3 parameters

S1=Low, S2=Medium, S3=High. Difficulty changes physical coefficients/gradients, not solver tolerance.

The Arrhenius family follows the production campaign terminology and form `A*T^beta*exp(-Ta/T)`. This package uses A={1e7,1e8,1e9}, beta=5, Ta={1000,500,350} K; S1 and S2 are directly aligned with the production LOW/INTERMEDIATE reference values, while S3 is a controlled high-stiffness extension documented here rather than guessed to be an undocumented production value.
