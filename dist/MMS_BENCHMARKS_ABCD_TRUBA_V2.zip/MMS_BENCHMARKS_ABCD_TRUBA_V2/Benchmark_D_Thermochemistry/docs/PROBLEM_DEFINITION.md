# Thermochemistry + Energy

Coupled thermochemistry verification uses YF/YO/YP and sensible enthalpy h=h(T,Y), low-Mach rho=p0/(Rmix T), a production-like 2F+O->2P Arrhenius source, and heat release. Exact T and species define derived h and rho before continuous MMS sources are formed.
