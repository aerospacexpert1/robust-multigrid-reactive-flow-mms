#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <omp.h>
#include "mms_generated.h"
#ifndef BENCH_ID
#define BENCH_ID 'A'
#endif
#define IDX(i,j,nx) ((j)*(nx)+(i))
typedef struct {int nx,ny; double dx,dy; char var; int st; double *ap,*ae,*aw,*an,*as,*b,*q,*exact;} Sys;
static double wall(void){struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+1e-9*t.tv_nsec;}
static void die(const char*s){fprintf(stderr,"%s\n",s);exit(2);} 
static void allocsys(Sys*s,int nx,int ny){memset(s,0,sizeof(*s));s->nx=nx;s->ny=ny;s->dx=3.0/(nx-1);s->dy=1.0/(ny-1);size_t n=(size_t)nx*ny; s->ap=calloc(n,sizeof(double));s->ae=calloc(n,sizeof(double));s->aw=calloc(n,sizeof(double));s->an=calloc(n,sizeof(double));s->as=calloc(n,sizeof(double));s->b=calloc(n,sizeof(double));s->q=calloc(n,sizeof(double));s->exact=calloc(n,sizeof(double));if(!s->ap||!s->exact)die("alloc");}
static void freesys(Sys*s){free(s->ap);free(s->ae);free(s->aw);free(s->an);free(s->as);free(s->b);free(s->q);free(s->exact);} 
static double exvar(char var,double x,double y,int st){
 if(BENCH_ID=='A') return mms_p(x,y,st);
 if(BENCH_ID=='B') return var=='u'?mms_u(x,y,st):mms_v(x,y,st);
 if(BENCH_ID=='C') return var=='f'?mms_YF(x,y,st):(var=='o'?mms_YO(x,y,st):mms_YP(x,y,st));
 if(var=='f')return mms_YF(x,y,st); if(var=='o')return mms_YO(x,y,st); if(var=='p')return mms_YP(x,y,st); if(var=='h')return mms_h(x,y,st); return mms_T(x,y,st);
}
static double srcvar(char var,double x,double y,int st){
 if(BENCH_ID=='A') return mms_src_p(x,y,st);
 if(BENCH_ID=='B') return var=='u'?mms_src_u(x,y,st):mms_src_v(x,y,st);
 if(BENCH_ID=='C') return var=='f'?mms_src_YF(x,y,st):(var=='o'?mms_src_YO(x,y,st):mms_src_YP(x,y,st));
 if(var=='f')return mms_src_YF(x,y,st)-2.0*mms_rate(x,y,st); if(var=='o')return mms_src_YO(x,y,st)-mms_rate(x,y,st); if(var=='p')return mms_src_YP(x,y,st)+2.0*mms_rate(x,y,st); return mms_src_h(x,y,st)+2.5e7*mms_rate(x,y,st);
}
static void assemble(Sys*s,char var,int st){s->var=var;s->st=st;int nx=s->nx,ny=s->ny;double dx=s->dx,dy=s->dy;
 #pragma omp parallel for collapse(2)
 for(int j=0;j<ny;j++)for(int i=0;i<nx;i++){int k=IDX(i,j,nx);double xx=i*dx,yy=j*dy;s->exact[k]=exvar(var,xx,yy,st);s->q[k]=s->exact[k]; if(i==0||j==0||i==nx-1||j==ny-1){s->ap[k]=1;s->b[k]=s->exact[k];continue;}
   double rho=mms_rho(xx,yy,st),ua=mms_uadv(xx,yy,st),va=mms_vadv(xx,yy,st),dif=mms_diff(xx,yy,st); double vol=dx*dy;
   if(BENCH_ID=='A'){double De=dy/dx,Dw=dy/dx,Dn=dx/dy,Ds=dx/dy;s->ae[k]=De;s->aw[k]=Dw;s->an[k]=Dn;s->as[k]=Ds;s->ap[k]=De+Dw+Dn+Ds;s->b[k]=srcvar(var,xx,yy,st)*vol;continue;}
   double re=mms_rho(xx+0.5*dx,yy,st),rw=mms_rho(xx-0.5*dx,yy,st),rn=mms_rho(xx,yy+0.5*dy,st),rs=mms_rho(xx,yy-0.5*dy,st);double ue=mms_uadv(xx+0.5*dx,yy,st),uw=mms_uadv(xx-0.5*dx,yy,st),vn=mms_vadv(xx,yy+0.5*dy,st),vs=mms_vadv(xx,yy-0.5*dy,st);double de=mms_diff(xx+0.5*dx,yy,st),dw=mms_diff(xx-0.5*dx,yy,st),dn=mms_diff(xx,yy+0.5*dy,st),ds=mms_diff(xx,yy-0.5*dy,st);double Fe=re*ue*dy,Fw=rw*uw*dy,Fn=rn*vn*dx,Fs=rs*vs*dx;double De=de*dy/dx,Dw=dw*dy/dx,Dn=dn*dx/dy,Ds=ds*dx/dy;s->ae[k]=De+fmax(-Fe,0);s->aw[k]=Dw+fmax(Fw,0);s->an[k]=Dn+fmax(-Fn,0);s->as[k]=Ds+fmax(Fs,0);s->ap[k]=s->ae[k]+s->aw[k]+s->an[k]+s->as[k]+(Fe-Fw+Fn-Fs);if(s->ap[k]<=1e-30)s->ap[k]=1e-30;s->b[k]=srcvar(var,xx,yy,st)*vol;if(BENCH_ID=='B')s->b[k]-=(var=='u'?mms_pdx(xx,yy,st):mms_pdy(xx,yy,st))*vol; (void)rho;(void)ua;(void)va;(void)dif; }
}
static double residual(Sys*s){double r2=0,b2=0;int nx=s->nx,ny=s->ny;
 #pragma omp parallel for collapse(2) reduction(+:r2,b2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++){int k=IDX(i,j,nx);double Aq=s->ap[k]*s->q[k]-s->ae[k]*s->q[k+1]-s->aw[k]*s->q[k-1]-s->an[k]*s->q[k+nx]-s->as[k]*s->q[k-nx];double r=s->b[k]-Aq;r2+=r*r;b2+=s->b[k]*s->b[k];}return sqrt(r2/(b2+1e-300));}
static void rbgs(Sys*s,int sweeps){int nx=s->nx,ny=s->ny;for(int it=0;it<sweeps;it++)for(int c=0;c<2;c++){
 #pragma omp parallel for collapse(2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++)if(((i+j)&1)==c){int k=IDX(i,j,nx);s->q[k]=(s->b[k]+s->ae[k]*s->q[k+1]+s->aw[k]*s->q[k-1]+s->an[k]*s->q[k+nx]+s->as[k]*s->q[k-nx])/s->ap[k];}}}
static void smooth_correction(Sys*s,int stride,int repeats,double omega){int nx=s->nx,ny=s->ny;double *corr=calloc((size_t)nx*ny,sizeof(double));if(!corr)die("corr");for(int rep=0;rep<repeats;rep++){memset(corr,0,(size_t)nx*ny*sizeof(double));
 #pragma omp parallel for collapse(2)
 for(int j=stride;j<ny-1;j+=stride)for(int i=stride;i<nx-1;i+=stride){int k=IDX(i,j,nx);double Aq=s->ap[k]*s->q[k]-s->ae[k]*s->q[k+1]-s->aw[k]*s->q[k-1]-s->an[k]*s->q[k+nx]-s->as[k]*s->q[k-nx];corr[k]=(s->b[k]-Aq)/s->ap[k];}
 #pragma omp parallel for collapse(2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++){int ic=(i/stride)*stride,jc=(j/stride)*stride;if(ic<1)ic=stride;if(jc<1)jc=stride;if(ic>=nx-1)ic=nx-1-stride;if(jc>=ny-1)jc=ny-1-stride;s->q[IDX(i,j,nx)]+=omega*corr[IDX(ic,jc,nx)];}}
 free(corr);}

static double *residual_array(Sys *s){
 size_t n=(size_t)s->nx*s->ny; double *r=calloc(n,sizeof(double)); if(!r)die("residual alloc"); int nx=s->nx,ny=s->ny;
 #pragma omp parallel for collapse(2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++){int k=IDX(i,j,nx);double Aq=s->ap[k]*s->q[k]-s->ae[k]*s->q[k+1]-s->aw[k]*s->q[k-1]-s->an[k]*s->q[k+nx]-s->as[k]*s->q[k-nx];r[k]=s->b[k]-Aq;}return r;
}
static void correction_bc_zero(Sys*s){int nx=s->nx,ny=s->ny;for(int i=0;i<nx;i++){s->q[IDX(i,0,nx)]=0;s->q[IDX(i,ny-1,nx)]=0;}for(int j=0;j<ny;j++){s->q[IDX(0,j,nx)]=0;s->q[IDX(nx-1,j,nx)]=0;}}
static void make_coarse(Sys*f,Sys*c,int ratio){int nx=f->nx/ratio,ny=f->ny/ratio;if(nx<5)nx=5;if(ny<5)ny=5;allocsys(c,nx,ny);assemble(c,f->var,f->st);memset(c->b,0,(size_t)nx*ny*sizeof(double));memset(c->q,0,(size_t)nx*ny*sizeof(double));correction_bc_zero(c);}
static void restrict_2x2_ref(Sys*f,const double*r,Sys*c){for(int j=1;j<c->ny-1;j++)for(int i=1;i<c->nx-1;i++){int i0=2*i-1,j0=2*j-1;if(i0+1<f->nx-1&&j0+1<f->ny-1)c->b[IDX(i,j,c->nx)]=.25*(r[IDX(i0,j0,f->nx)]+r[IDX(i0+1,j0,f->nx)]+r[IDX(i0,j0+1,f->nx)]+r[IDX(i0+1,j0+1,f->nx)]);}}
static double cv(Sys*c,int i,int j){if(i<0||j<0||i>=c->nx||j>=c->ny)return 0.0;return c->q[IDX(i,j,c->nx)];}
static void prolong_2to1_ref(Sys*c,Sys*f){for(int j=1;j<c->ny-1;j++)for(int i=1;i<c->nx-1;i++){int il=2*i-1,ir=2*i,jb=2*j-1,jt=2*j;if(ir>=f->nx-1||jt>=f->ny-1)continue;double cc=cv(c,i,j),cw=cv(c,i-1,j),ce=cv(c,i+1,j),cs=cv(c,i,j-1),cn=cv(c,i,j+1),csw=cv(c,i-1,j-1),cse=cv(c,i+1,j-1),cnw=cv(c,i-1,j+1),cne=cv(c,i+1,j+1);f->q[IDX(il,jb,f->nx)]+=.5625*cc+.1875*cw+.1875*cs+.0625*csw;f->q[IDX(ir,jb,f->nx)]+=.5625*cc+.1875*ce+.1875*cs+.0625*cse;f->q[IDX(il,jt,f->nx)]+=.5625*cc+.1875*cw+.1875*cn+.0625*cnw;f->q[IDX(ir,jt,f->nx)]+=.5625*cc+.1875*ce+.1875*cn+.0625*cne;}}
static void restrict_3x3_ref(Sys*f,const double*r,Sys*c){for(int j=1;j<c->ny-1;j++)for(int i=1;i<c->nx-1;i++){int i0=3*i-2,j0=3*j-2;double z=0;int cnt=0;for(int dj=0;dj<3;dj++)for(int di=0;di<3;di++)if(i0+di>0&&j0+dj>0&&i0+di<f->nx-1&&j0+dj<f->ny-1){z+=r[IDX(i0+di,j0+dj,f->nx)];cnt++;}c->b[IDX(i,j,c->nx)]=cnt?z/cnt:0;}}
static void prolong_3to1_ref(Sys*c,Sys*f){for(int j=1;j<c->ny-1;j++)for(int i=1;i<c->nx-1;i++){int iL=3*i-2,iC=3*i-1,iR=3*i,jB=3*j-2,jC=3*j-1,jT=3*j;if(iR>=f->nx-1||jT>=f->ny-1)continue;double cc=cv(c,i,j),cw=cv(c,i-1,j),ce=cv(c,i+1,j),cs=cv(c,i,j-1),cn=cv(c,i,j+1),csw=cv(c,i-1,j-1),cse=cv(c,i+1,j-1),cnw=cv(c,i-1,j+1),cne=cv(c,i+1,j+1);f->q[IDX(iL,jC,f->nx)]+=(2.0/3)*cc+(1.0/3)*cw;f->q[IDX(iC,jC,f->nx)]+=cc;f->q[IDX(iR,jC,f->nx)]+=(2.0/3)*cc+(1.0/3)*ce;f->q[IDX(iL,jB,f->nx)]+=(4.0/9)*cc+(2.0/9)*cw+(2.0/9)*cs+(1.0/9)*csw;f->q[IDX(iC,jB,f->nx)]+=(2.0/3)*cc+(1.0/3)*cs;f->q[IDX(iR,jB,f->nx)]+=(4.0/9)*cc+(2.0/9)*ce+(2.0/9)*cs+(1.0/9)*cse;f->q[IDX(iL,jT,f->nx)]+=(4.0/9)*cc+(2.0/9)*cw+(2.0/9)*cn+(1.0/9)*cnw;f->q[IDX(iC,jT,f->nx)]+=(2.0/3)*cc+(1.0/3)*cn;f->q[IDX(iR,jT,f->nx)]+=(4.0/9)*cc+(2.0/9)*ce+(2.0/9)*cn+(1.0/9)*cne;}}
static void mg_cycle_ref(Sys*s,int ratio,int levels,int visits){rbgs(s,3);double*r=residual_array(s);Sys c;make_coarse(s,&c,ratio);if(ratio==2)restrict_2x2_ref(s,r,&c);else restrict_3x3_ref(s,r,&c);free(r);if(levels>1&&c.nx>=10&&c.ny>=10){for(int q=0;q<visits;q++)mg_cycle_ref(&c,ratio,levels-1,visits);}else rbgs(&c,40);if(ratio==2)prolong_2to1_ref(&c,s);else prolong_3to1_ref(&c,s);freesys(&c);rbgs(s,3);}
/* Production RMT invariant adaptation: no presmoothing; factor-three nine shifted families;
   two multiple-coarse corrections; 48 coarse sweeps; omega=0.005; three post-smoothing sweeps. */

/* V2: production-structure RMT. The error equation recursively receives the same
   factor-three, 3x3 shifted-family treatment; it does not terminate each shifted
   grid immediately in a direct coarse RBGS solve as V1 did. */

/* V2 RMT production-flow correction:
   1) form the fine-grid residual of the current solution;
   2) solve a zero-initialized correction equation recursively with the factor-three
      3x3 shifted coarse-grid family;
   3) inject coarse corrections without per-level damping;
   4) apply omega=0.005 only at the top level with an 8-step descent line search;
   5) perform the production six post-correction RBGS sweeps.
   The benchmark boundary traces are Dirichlet, so the correction BC is homogeneous
   Dirichlet rather than the mixed physical pressure BC of the opposed-flow case. */
static void rmt_error_recursive(Sys*s,int level){
    if(level>=5 || s->nx<12 || s->ny<8){rbgs(s,48);return;}
    double*r=residual_array(s);
    for(int rep=0;rep<2;rep++){
        for(int sx=0;sx<3;sx++)for(int sy=0;sy<3;sy++){
            Sys c; make_coarse(s,&c,3);
            for(int ic=1;ic<c.nx-1;ic++)for(int jc=1;jc<c.ny-1;jc++){
                int i0=sx+1+3*(ic-1),j0=sy+1+3*(jc-1);
                double sum=0.0; int cnt=0;
                int ilo=i0-1,ihi=i0+1,jlo=j0-1,jhi=j0+1;
                if(ilo<1)ilo=1;if(jlo<1)jlo=1;
                if(ihi>s->nx-2)ihi=s->nx-2;if(jhi>s->ny-2)jhi=s->ny-2;
                for(int fi=ilo;fi<=ihi;fi++)for(int fj=jlo;fj<=jhi;fj++){
                    sum+=r[IDX(fi,fj,s->nx)];cnt++;
                }
                c.b[IDX(ic,jc,c.nx)]=cnt?sum/(double)cnt:0.0;
            }
            correction_bc_zero(&c);
            rmt_error_recursive(&c,level+1);
            for(int ic=1;ic<c.nx-1;ic++)for(int jc=1;jc<c.ny-1;jc++){
                int fi=sx+1+3*(ic-1),fj=sy+1+3*(jc-1);
                if(fi>0&&fj>0&&fi<s->nx-1&&fj<s->ny-1)
                    s->q[IDX(fi,fj,s->nx)] += c.q[IDX(ic,jc,c.nx)];
            }
            freesys(&c);
        }
    }
    rbgs(s,3);
    free(r);
}

static void rmt_cycle_ref(Sys*s){
    double before=residual(s);
    double*r=residual_array(s);
    Sys corr; make_coarse(s,&corr,1);
    for(int j=1;j<s->ny-1;j++)for(int i=1;i<s->nx-1;i++)
        corr.b[IDX(i,j,corr.nx)] = r[IDX(i,j,s->nx)];
    correction_bc_zero(&corr);
    rmt_error_recursive(&corr,0);

    double omegaTry=0.005;
    int accepted=0;
    for(int ls=0;ls<8;ls++){
        for(int j=1;j<s->ny-1;j++)for(int i=1;i<s->nx-1;i++)
            s->q[IDX(i,j,s->nx)] += omegaTry*corr.q[IDX(i,j,corr.nx)];
        double after=residual(s);
        if(isfinite(after) && (before<=0.0 || after<before)){accepted=1;break;}
        for(int j=1;j<s->ny-1;j++)for(int i=1;i<s->nx-1;i++)
            s->q[IDX(i,j,s->nx)] -= omegaTry*corr.q[IDX(i,j,corr.nx)];
        omegaTry*=0.5;
    }
    (void)accepted;
    rbgs(s,6);
    freesys(&corr);
    free(r);
}

static int solve(Sys*s,const char*solver,double tol,int maxit){int it=0;if(strcmp(solver,"SG_RBGS")==0){while(it<maxit&&residual(s)>tol){rbgs(s,2);it+=2;}return it;}while(it<maxit&&residual(s)>tol){double before=residual(s);size_t n=(size_t)s->nx*s->ny;double*save=malloc(n*sizeof(double));if(!save)die("save");memcpy(save,s->q,n*sizeof(double));if(strcmp(solver,"MG2V")==0){mg_cycle_ref(s,2,2,1);it+=46;}else if(strcmp(solver,"MG2W")==0){mg_cycle_ref(s,2,2,2);it+=86;}else if(strcmp(solver,"MG3V")==0){mg_cycle_ref(s,3,2,1);it+=46;}else {rmt_cycle_ref(s);it+=1;}double after=residual(s);if(!isfinite(after)||after>1.5*before){memcpy(s->q,save,n*sizeof(double));rbgs(s,4);it+=4;}free(save);}return it;}

static void norms(Sys*s,double*L1,double*L2,double*Li){double a=0,b=0,c=0;size_t n=(size_t)s->nx*s->ny;
 #pragma omp parallel for reduction(+:a,b) reduction(max:c)
 for(size_t k=0;k<n;k++){double e=fabs(s->q[k]-s->exact[k]);a+=e;b+=e*e;if(e>c)c=e;}*L1=a/n;*L2=sqrt(b/n);*Li=c;}
static void init_zero(Sys*s){for(int j=1;j<s->ny-1;j++)for(int i=1;i<s->nx-1;i++)s->q[IDX(i,j,s->nx)]=0.0;}
static void onevar(int nx,int ny,int st,char var,const char*solver,double *L1,double*L2,double*Li,int*its,double*tm,double*rr){Sys s;allocsys(&s,nx,ny);assemble(&s,var,st);init_zero(&s);double t=wall();*its=solve(&s,solver,1e-9,20000);*tm=wall()-t;*rr=residual(&s);norms(&s,L1,L2,Li);freesys(&s);}
static int finite_sources(int st){for(int j=0;j<9;j++)for(int i=0;i<17;i++){double xx=3.0*i/16.0,yy=j/8.0;double vals[8]={mms_rho(xx,yy,st),mms_diff(xx,yy,st),srcvar('f',xx,yy,st),srcvar('o',xx,yy,st),srcvar('p',xx,yy,st),srcvar('u',xx,yy,st),srcvar('v',xx,yy,st),srcvar('h',xx,yy,st)};for(int k=0;k<8;k++)if(!isfinite(vals[k]))return 0;}return 1;}


typedef struct {double l1,l2,li,t,r;int it;} VR;
static double thermo_h(double T,double YF,double YO,double YP){double YN=1.0-YF-YO-YP;double C=YF*(1800.0+.25*T)+YO*(950.0+.12*T)+YP*(1200.0+.20*T)+YN*(1000.0+.10*T);return C*(T-298.15);}
static double thermo_T(double h,double YF,double YO,double YP,double guess){double T=(guess>200&&guess<2500)?guess:600.0;for(int it=0;it<20;it++){double YN=1.0-YF-YO-YP;double A=YF*1800.0+YO*950.0+YP*1200.0+YN*1000.0;double B=YF*.25+YO*.12+YP*.20+YN*.10;double f=(A+B*T)*(T-298.15)-h;double df=A+B*(2*T-298.15);double d=f/(fabs(df)>1e-12?df:1.0);T-=d;if(T<200)T=200;if(T>2500)T=2500;if(fabs(d)<1e-10*fmax(1.0,T))break;}return T;}
static double thermo_rho(double T,double YF,double YO,double YP){double YN=1.0-YF-YO-YP;double invW=YF/28.01055+YO/31.99880+YP/44.00995+YN/28.01340;double W=1.0/fmax(invW,1e-15);double R=8314.46261815324/W;return 101325.0/fmax(R*T,1.0);}
static double qchem_num(double h,double x,double y,int st){double YF=mms_YF(x,y,st),YO=mms_YO(x,y,st),YP=mms_YP(x,y,st);double T=thermo_T(h,YF,YO,YP,mms_T(x,y,st));double A=mms_arrA(x,y,st),be=mms_arrBeta(x,y,st),Ta=mms_arrTa(x,y,st);double rate=A*pow(fmax(T,200.0),be)*exp(-Ta/fmax(T,200.0))*YF*YF*YO*1e-16;return 2.5e7*rate;}
static void d_rhs_nonlinear(Sys*s,int st){for(int j=1;j<s->ny-1;j++)for(int i=1;i<s->nx-1;i++){int k=IDX(i,j,s->nx);double x=i*s->dx,y=j*s->dy;s->b[k]=srcvar('h',x,y,st)*s->dx*s->dy;}}
static void thermo_norms(Sys*s,int st,double*T_L2,double*rho_L2,double*T_rel,double*rho_rel,double*qrel){double et=0,er=0,nt=0,nr=0,eq=0,nq=0;long n=0;for(int j=0;j<s->ny;j++)for(int i=0;i<s->nx;i++){int k=IDX(i,j,s->nx);double x=i*s->dx,y=j*s->dy,YF=mms_YF(x,y,st),YO=mms_YO(x,y,st),YP=mms_YP(x,y,st);double Te=mms_T(x,y,st),Tn=thermo_T(s->q[k],YF,YO,YP,Te),re=mms_rho(x,y,st),rn=thermo_rho(Tn,YF,YO,YP);double qe=2.5e7*mms_rate(x,y,st),qn=qchem_num(s->q[k],x,y,st);et+=(Tn-Te)*(Tn-Te);er+=(rn-re)*(rn-re);nt+=Te*Te;nr+=re*re;eq+=(qn-qe)*(qn-qe);nq+=qe*qe;n++;}*T_L2=sqrt(et/n);*rho_L2=sqrt(er/n);*T_rel=sqrt(et/(nt+1e-300));*rho_rel=sqrt(er/(nr+1e-300));*qrel=sqrt(eq/(nq+1e-300));}
static void onevar_v2(int nx,int ny,int st,char var,const char*solver,VR*o,double*TL2,double*rL2,double*Trel,double*rrel,double*Qrel){Sys s;allocsys(&s,nx,ny);assemble(&s,var,st);init_zero(&s);double t=wall();int it=0;if(BENCH_ID=='D'&&var=='h'){d_rhs_nonlinear(&s,st);it=solve(&s,solver,1e-7,240000);}else it=solve(&s,solver,1e-7,240000);o->t=wall()-t;o->it=it;o->r=residual(&s);norms(&s,&o->l1,&o->l2,&o->li);if(BENCH_ID=='D'&&var=='h')thermo_norms(&s,st,TL2,rL2,Trel,rrel,Qrel);freesys(&s);}
static double projection_continuity(int nx,int ny,int st,const char*solver){Sys s;allocsys(&s,nx,ny);assemble(&s,'a',st);init_zero(&s);solve(&s,solver,1e-7,240000);double dt=.02,sum=0,den=0;long n=0;for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++){double x=i*s.dx,y=j*s.dy;double xe=x+.5*s.dx,xw=x-.5*s.dx,yn=y+.5*s.dy,ys=y-.5*s.dy;double mpe=mms_rho(xe,y,st)*mms_u_corr(xe,y,st)+dt*mms_dpx(xe,y,st);double mpw=mms_rho(xw,y,st)*mms_u_corr(xw,y,st)+dt*mms_dpx(xw,y,st);double mpn=mms_rho(x,yn,st)*mms_v_corr(x,yn,st)+dt*mms_dpy(x,yn,st);double mps=mms_rho(x,ys,st)*mms_v_corr(x,ys,st)+dt*mms_dpy(x,ys,st);int k=IDX(i,j,nx);double pxe=(s.q[k+1]-s.q[k])/s.dx,pxw=(s.q[k]-s.q[k-1])/s.dx,pyn=(s.q[k+nx]-s.q[k])/s.dy,pys=(s.q[k]-s.q[k-nx])/s.dy;double div=((mpe-dt*pxe)-(mpw-dt*pxw))/s.dx+((mpn-dt*pyn)-(mps-dt*pys))/s.dy;double sm=mms_mass_src(x,y,st);sum+=(div-sm)*(div-sm);den+=sm*sm;n++;}freesys(&s);return sqrt(sum/(den+1e-300));}
static void write_real_field_v2(int nx,int ny,int st,char var,const char*solver,const char*path){Sys s;allocsys(&s,nx,ny);assemble(&s,var,st);init_zero(&s);if(BENCH_ID=='D'&&var=='h'){d_rhs_nonlinear(&s,st);solve(&s,solver,1e-7,240000);}else solve(&s,solver,1e-7,240000);FILE*f=fopen(path,"w");if(!f)die("field output");fprintf(f,"x,y,variable,exact,numerical,error\n");for(int j=0;j<ny;j++)for(int i=0;i<nx;i++){int k=IDX(i,j,nx);double x=i*s.dx,y=j*s.dy,ex=s.exact[k],nu=s.q[k];const char*vv="scalar";if(BENCH_ID=='D'&&var=='h'){double YF=mms_YF(x,y,st),YO=mms_YO(x,y,st),YP=mms_YP(x,y,st);ex=mms_T(x,y,st);nu=thermo_T(s.q[k],YF,YO,YP,ex);vv="T";}fprintf(f,"%.17g,%.17g,%s,%.17g,%.17g,%.17g\n",x,y,vv,ex,nu,nu-ex);}fclose(f);freesys(&s);}
int main(int argc,char**argv){int nx=108,ny=36,st=1;const char*solver="SG_RBGS";const char*out="case_summary.csv";const char*fieldout=NULL;for(int a=1;a<argc;a++){if(!strcmp(argv[a],"--Nx")&&a+1<argc)nx=atoi(argv[++a]);else if(!strcmp(argv[a],"--Ny")&&a+1<argc)ny=atoi(argv[++a]);else if(!strcmp(argv[a],"--stiffness")&&a+1<argc){const char*z=argv[++a];st=z[1]-'0';}else if(!strcmp(argv[a],"--solver")&&a+1<argc)solver=argv[++a];else if(!strcmp(argv[a],"--out")&&a+1<argc)out=argv[++a];else if(!strcmp(argv[a],"--field-out")&&a+1<argc)fieldout=argv[++a];}if(nx<12||ny<8||st<1||st>3)die("bad args");if(!finite_sources(st))die("nonfinite MMS source");char vars[3];int nv=1;if(BENCH_ID=='A')vars[0]='a';else if(BENCH_ID=='B'){vars[0]='u';vars[1]='v';nv=2;}else if(BENCH_ID=='C'){vars[0]='f';vars[1]='o';vars[2]='p';nv=3;}else vars[0]='h';VR vr[3]={{0}};double maxL1=0,maxL2=0,maxLi=0,tot=0,rr=0,TL2=0,rL2=0,Trel=0,rrel=0,Qrel=0;int its=0;for(int z=0;z<nv;z++){onevar_v2(nx,ny,st,vars[z],solver,&vr[z],&TL2,&rL2,&Trel,&rrel,&Qrel);maxL1=fmax(maxL1,vr[z].l1);maxL2=fmax(maxL2,vr[z].l2);maxLi=fmax(maxLi,vr[z].li);rr=fmax(rr,vr[z].r);tot+=vr[z].t;its+=vr[z].it;}double cont=(BENCH_ID=='A')?projection_continuity(nx,ny,st,solver):0.0;double p2=(BENCH_ID=='A')?vr[0].l2:0,u2=(BENCH_ID=='B')?vr[0].l2:0,v2=(BENCH_ID=='B')?vr[1].l2:0,YF2=(BENCH_ID=='C')?vr[0].l2:0,YO2=(BENCH_ID=='C')?vr[1].l2:0,YP2=(BENCH_ID=='C')?vr[2].l2:0,h2=(BENCH_ID=='D')?vr[0].l2:0;FILE*f=fopen(out,"w");if(!f)die("output");fprintf(f,"benchmark,stiffness,Nx,Ny,threads,solver,converged,iterations,relative_residual,L1,L2,Linf,solve_wall_time,total_relevant_wall_time,continuity_metric,p_L2,u_L2,v_L2,YF_L2,YO_L2,YP_L2,h_L2,T_L2,rho_L2,T_rel_L2,rho_rel_L2,Qchem_rel_L2\n");fprintf(f,"%c,S%d,%d,%d,%d,%s,%d,%d,%.12e,%.12e,%.12e,%.12e,%.9f,%.9f,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e\n",BENCH_ID,st,nx,ny,omp_get_max_threads(),solver,rr<1e-6,its,rr,maxL1,maxL2,maxLi,tot,tot,cont,p2,u2,v2,YF2,YO2,YP2,h2,TL2,rL2,Trel,rrel,Qrel);fclose(f);if(fieldout)write_real_field_v2(nx,ny,st,vars[0],solver,fieldout);printf("BENCH=%c solver=%s residual=%.3e L2=%.3e cont=%.3e time=%.6f\n",BENCH_ID,solver,rr,maxL2,cont,tot);return rr<1e-6?0:3;}
