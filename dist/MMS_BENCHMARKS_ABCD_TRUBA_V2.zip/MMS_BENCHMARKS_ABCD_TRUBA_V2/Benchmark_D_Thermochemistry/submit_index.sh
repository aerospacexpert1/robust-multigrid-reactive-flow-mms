#!/usr/bin/env bash
set -euo pipefail
idx="\${1:?index}"
[[ "$idx" =~ ^[0-9]+$ ]] && (( idx >= 0 && idx < 300 )) || { echo "index must be 0..299" >&2; exit 2; }
mkdir -p logs
sbatch --array=0 --export=ALL,SINGLE_TASK_ID="$idx" benchmark_D_array.slurm
