# MMS_BENCHMARKS_ABCD_TRUBA_V2

A = Pressure Projection / Continuity
B = Momentum
C = Species Transport
D = Thermochemistry + Energy

Meshes: 108x36, 216x72, 432x144, 864x288, 1728x576. Threads: 1,2,4,16. Stiffness: S1/S2/S3. Solvers: SG_RBGS, MG2V, MG2W, MG3V, RMT3H. Each benchmark has 60 physical MMS configurations and 300 solver executions; total 240 physical configurations and 1200 solver executions. TRUBA submission uses 60 Slurm array elements per benchmark, with each element executing the five solver variants for one physical configuration sequentially on the same node. This stays below MaxArraySize=100 without reducing the campaign. Each allocation uses one node, one task, 56 CPUs/task while actual OpenMP threads come from the manifest.
