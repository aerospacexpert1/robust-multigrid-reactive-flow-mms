# V2 production-fidelity corrections

- **A** uses the production low-Mach pressure-correction Laplacian and reconstructs predictor mass flux, numerical pressure correction, corrected flux and a discrete continuity defect. Density is manufactured in the predictor/corrector chain; it is not used to invent a variable-k Poisson equation.
- **B** keeps the known pressure gradient in the momentum predictor and verifies the conservative advection-diffusion operator for both u and v.
- **C** verifies chemistry-off YF/YO/YP transport.
- **D** is an energy/thermochemistry isolation MMS: YF/YO/YP are prescribed manufactured composition fields (their transport is verified in C), while sensible enthalpy is the numerical unknown. Each Picard update recomputes T(h,Y), low-Mach perfect-gas density and Arrhenius heat release. Raw h error and derived T/rho absolute and relative errors are reported.
- RMT3H is a production-aligned factor-three multiple-shifted-grid benchmark adaptation: no presmoothing, control-volume defect restriction, direct coarsest solves, 16 post-smoothing sweeps, and full correction without interpolation, damping, line search, rollback, or hidden fallback.
- A is the direct production pressure-solver comparison. Applying the five solver kernels to B/C/D is explicitly an **operator-solver extension** for numerical-method study, not a claim that the production opposed-flow executable switches those transport blocks among five solver families.

Continuous MMS sources are derived before discretization; no `b_h=A_h phi_exact` construction is used.

## Benchmark D operator split
The V2 energy MMS does not solve a synthetic steady Picard reaction-energy equation. The production solver applies chemistry as an operator-split, lagged-temperature subcycle. Therefore the manufactured sensible-enthalpy transport equation uses the exact manufactured heat-release contribution in its source balance, while the runtime `h -> T -> rho` closure and Arrhenius heat-release kernel are evaluated from the numerical enthalpy and reported through `T_rel_L2`, `rho_rel_L2`, and `Qchem_rel_L2`.

## Benchmark B pressure-gradient split
The continuous momentum MMS source contains the analytic pressure gradient. `postprocess_package.py` moves that known pressure-gradient term out of the predictor transport operator exactly once. V2 removes the former second subtraction in FV assembly, which otherwise produced a non-vanishing refinement error.
