#!/usr/bin/env bash
set -euo pipefail
idx="${1:?real manifest index 0..299 required}"
if (( idx < 0 || idx > 299 )); then
  echo "index must be 0..299" >&2
  exit 2
fi
offset=$(( (idx / 100) * 100 ))
local_id=$(( idx - offset ))
mkdir -p logs
sbatch --array="${local_id}" --export=ALL,TASK_OFFSET="${offset}" benchmark_A_array.slurm
