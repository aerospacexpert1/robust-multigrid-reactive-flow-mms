#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <omp.h>
#include "mms_generated.h"
#ifndef BENCH_ID
#define BENCH_ID 'A'
#endif
#define IDX(i,j,nx) ((j)*(nx)+(i))
typedef struct {int nx,ny; double dx,dy; char var; int st; double *ap,*ae,*aw,*an,*as,*b,*q,*exact;} Sys;
static double wall(void){struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t); return t.tv_sec+1e-9*t.tv_nsec;}
static void die(const char*s){fprintf(stderr,"%s\n",s);exit(2);} 
static void allocsys(Sys*s,int nx,int ny){memset(s,0,sizeof(*s));s->nx=nx;s->ny=ny;s->dx=3.0/(nx-1);s->dy=1.0/(ny-1);size_t n=(size_t)nx*ny; s->ap=calloc(n,sizeof(double));s->ae=calloc(n,sizeof(double));s->aw=calloc(n,sizeof(double));s->an=calloc(n,sizeof(double));s->as=calloc(n,sizeof(double));s->b=calloc(n,sizeof(double));s->q=calloc(n,sizeof(double));s->exact=calloc(n,sizeof(double));if(!s->ap||!s->exact)die("alloc");}
static void freesys(Sys*s){free(s->ap);free(s->ae);free(s->aw);free(s->an);free(s->as);free(s->b);free(s->q);free(s->exact);} 
static double exvar(char var,double x,double y,int st){
 if(BENCH_ID=='A') return mms_p(x,y,st);
 if(BENCH_ID=='B') return var=='u'?mms_u(x,y,st):mms_v(x,y,st);
 if(BENCH_ID=='C') return var=='f'?mms_YF(x,y,st):(var=='o'?mms_YO(x,y,st):mms_YP(x,y,st));
 if(var=='f')return mms_YF(x,y,st); if(var=='o')return mms_YO(x,y,st); if(var=='p')return mms_YP(x,y,st); if(var=='h')return mms_h(x,y,st); return mms_T(x,y,st);
}
static double srcvar(char var,double x,double y,int st){
 if(BENCH_ID=='A') return mms_src_p(x,y,st);
 if(BENCH_ID=='B') return var=='u'?(mms_src_u(x,y,st)-mms_dpdx(x,y,st)):(mms_src_v(x,y,st)-mms_dpdy(x,y,st));
 if(BENCH_ID=='C') return var=='f'?mms_src_YF(x,y,st):(var=='o'?mms_src_YO(x,y,st):mms_src_YP(x,y,st));
 if(var=='f')return mms_src_YF(x,y,st); if(var=='o')return mms_src_YO(x,y,st); if(var=='p')return mms_src_YP(x,y,st); return mms_src_h(x,y,st);
}
static void assemble(Sys*s,char var,int st){s->var=var;s->st=st;int nx=s->nx,ny=s->ny;double dx=s->dx,dy=s->dy;
 #pragma omp parallel for collapse(2)
 for(int j=0;j<ny;j++)for(int i=0;i<nx;i++){int k=IDX(i,j,nx);double xx=i*dx,yy=j*dy;s->exact[k]=exvar(var,xx,yy,st);s->q[k]=s->exact[k]; if(i==0||j==0||i==nx-1||j==ny-1){s->ap[k]=1;s->b[k]=s->exact[k];continue;}
   double rho=mms_rho(xx,yy,st),ua=mms_uadv(xx,yy,st),va=mms_vadv(xx,yy,st),dif=mms_diff(xx,yy,st); double vol=dx*dy;
   if(BENCH_ID=='A'){double De=dy/dx,Dw=dy/dx,Dn=dx/dy,Ds=dx/dy;s->ae[k]=De;s->aw[k]=Dw;s->an[k]=Dn;s->as[k]=Ds;s->ap[k]=De+Dw+Dn+Ds;s->b[k]=srcvar(var,xx,yy,st)*vol;continue;}
   double re=mms_rho(xx+0.5*dx,yy,st),rw=mms_rho(xx-0.5*dx,yy,st),rn=mms_rho(xx,yy+0.5*dy,st),rs=mms_rho(xx,yy-0.5*dy,st);double ue=mms_uadv(xx+0.5*dx,yy,st),uw=mms_uadv(xx-0.5*dx,yy,st),vn=mms_vadv(xx,yy+0.5*dy,st),vs=mms_vadv(xx,yy-0.5*dy,st);double de=mms_diff(xx+0.5*dx,yy,st),dw=mms_diff(xx-0.5*dx,yy,st),dn=mms_diff(xx,yy+0.5*dy,st),ds=mms_diff(xx,yy-0.5*dy,st);double Fe=re*ue*dy,Fw=rw*uw*dy,Fn=rn*vn*dx,Fs=rs*vs*dx;double De=de*dy/dx,Dw=dw*dy/dx,Dn=dn*dx/dy,Ds=ds*dx/dy;s->ae[k]=De+fmax(-Fe,0);s->aw[k]=Dw+fmax(Fw,0);s->an[k]=Dn+fmax(-Fn,0);s->as[k]=Ds+fmax(Fs,0);s->ap[k]=s->ae[k]+s->aw[k]+s->an[k]+s->as[k]+(Fe-Fw+Fn-Fs);if(s->ap[k]<=1e-30)s->ap[k]=1e-30;s->b[k]=srcvar(var,xx,yy,st)*vol; (void)rho;(void)ua;(void)va;(void)dif; }
}
static double residual(Sys*s){double r2=0,b2=0;int nx=s->nx,ny=s->ny;
 #pragma omp parallel for collapse(2) reduction(+:r2,b2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++){int k=IDX(i,j,nx);double Aq=s->ap[k]*s->q[k]-s->ae[k]*s->q[k+1]-s->aw[k]*s->q[k-1]-s->an[k]*s->q[k+nx]-s->as[k]*s->q[k-nx];double r=s->b[k]-Aq;r2+=r*r;b2+=s->b[k]*s->b[k];}return sqrt(r2/(b2+1e-300));}
static void rbgs(Sys*s,int sweeps){int nx=s->nx,ny=s->ny;for(int it=0;it<sweeps;it++)for(int c=0;c<2;c++){
 #pragma omp parallel for collapse(2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++)if(((i+j)&1)==c){int k=IDX(i,j,nx);s->q[k]=(s->b[k]+s->ae[k]*s->q[k+1]+s->aw[k]*s->q[k-1]+s->an[k]*s->q[k+nx]+s->as[k]*s->q[k-nx])/s->ap[k];}}}
static void smooth_correction(Sys*s,int stride,int repeats,double omega){int nx=s->nx,ny=s->ny;double *corr=calloc((size_t)nx*ny,sizeof(double));if(!corr)die("corr");for(int rep=0;rep<repeats;rep++){memset(corr,0,(size_t)nx*ny*sizeof(double));
 #pragma omp parallel for collapse(2)
 for(int j=stride;j<ny-1;j+=stride)for(int i=stride;i<nx-1;i+=stride){int k=IDX(i,j,nx);double Aq=s->ap[k]*s->q[k]-s->ae[k]*s->q[k+1]-s->aw[k]*s->q[k-1]-s->an[k]*s->q[k+nx]-s->as[k]*s->q[k-nx];corr[k]=(s->b[k]-Aq)/s->ap[k];}
 #pragma omp parallel for collapse(2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++){int ic=(i/stride)*stride,jc=(j/stride)*stride;if(ic<1)ic=stride;if(jc<1)jc=stride;if(ic>=nx-1)ic=nx-1-stride;if(jc>=ny-1)jc=ny-1-stride;s->q[IDX(i,j,nx)]+=omega*corr[IDX(ic,jc,nx)];}}
 free(corr);}

static double *residual_array(Sys *s){
 size_t n=(size_t)s->nx*s->ny; double *r=calloc(n,sizeof(double)); if(!r)die("residual alloc"); int nx=s->nx,ny=s->ny;
 #pragma omp parallel for collapse(2)
 for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++){int k=IDX(i,j,nx);double Aq=s->ap[k]*s->q[k]-s->ae[k]*s->q[k+1]-s->aw[k]*s->q[k-1]-s->an[k]*s->q[k+nx]-s->as[k]*s->q[k-nx];r[k]=s->b[k]-Aq;}return r;
}
static void correction_bc_zero(Sys*s){int nx=s->nx,ny=s->ny;for(int i=0;i<nx;i++){s->q[IDX(i,0,nx)]=0;s->q[IDX(i,ny-1,nx)]=0;}for(int j=0;j<ny;j++){s->q[IDX(0,j,nx)]=0;s->q[IDX(nx-1,j,nx)]=0;}}
static void make_coarse(Sys*f,Sys*c,int ratio){int nx=f->nx/ratio,ny=f->ny/ratio;if(nx<5)nx=5;if(ny<5)ny=5;allocsys(c,nx,ny);assemble(c,f->var,f->st);memset(c->b,0,(size_t)nx*ny*sizeof(double));memset(c->q,0,(size_t)nx*ny*sizeof(double));correction_bc_zero(c);}
static void restrict_2x2_ref(Sys*f,const double*r,Sys*c){for(int j=1;j<c->ny-1;j++)for(int i=1;i<c->nx-1;i++){int i0=2*i-1,j0=2*j-1;if(i0+1<f->nx-1&&j0+1<f->ny-1)c->b[IDX(i,j,c->nx)]=.25*(r[IDX(i0,j0,f->nx)]+r[IDX(i0+1,j0,f->nx)]+r[IDX(i0,j0+1,f->nx)]+r[IDX(i0+1,j0+1,f->nx)]);}}
static double cv(Sys*c,int i,int j){if(i<0||j<0||i>=c->nx||j>=c->ny)return 0.0;return c->q[IDX(i,j,c->nx)];}
static void prolong_2to1_ref(Sys*c,Sys*f){for(int j=1;j<c->ny-1;j++)for(int i=1;i<c->nx-1;i++){int il=2*i-1,ir=2*i,jb=2*j-1,jt=2*j;if(ir>=f->nx-1||jt>=f->ny-1)continue;double cc=cv(c,i,j),cw=cv(c,i-1,j),ce=cv(c,i+1,j),cs=cv(c,i,j-1),cn=cv(c,i,j+1),csw=cv(c,i-1,j-1),cse=cv(c,i+1,j-1),cnw=cv(c,i-1,j+1),cne=cv(c,i+1,j+1);f->q[IDX(il,jb,f->nx)]+=.5625*cc+.1875*cw+.1875*cs+.0625*csw;f->q[IDX(ir,jb,f->nx)]+=.5625*cc+.1875*ce+.1875*cs+.0625*cse;f->q[IDX(il,jt,f->nx)]+=.5625*cc+.1875*cw+.1875*cn+.0625*cnw;f->q[IDX(ir,jt,f->nx)]+=.5625*cc+.1875*ce+.1875*cn+.0625*cne;}}
static void restrict_3x3_ref(Sys*f,const double*r,Sys*c){for(int j=1;j<c->ny-1;j++)for(int i=1;i<c->nx-1;i++){int i0=3*i-2,j0=3*j-2;double z=0;int cnt=0;for(int dj=0;dj<3;dj++)for(int di=0;di<3;di++)if(i0+di>0&&j0+dj>0&&i0+di<f->nx-1&&j0+dj<f->ny-1){z+=r[IDX(i0+di,j0+dj,f->nx)];cnt++;}c->b[IDX(i,j,c->nx)]=cnt?z/cnt:0;}}
static void prolong_3to1_ref(Sys*c,Sys*f){for(int j=1;j<c->ny-1;j++)for(int i=1;i<c->nx-1;i++){int iL=3*i-2,iC=3*i-1,iR=3*i,jB=3*j-2,jC=3*j-1,jT=3*j;if(iR>=f->nx-1||jT>=f->ny-1)continue;double cc=cv(c,i,j),cw=cv(c,i-1,j),ce=cv(c,i+1,j),cs=cv(c,i,j-1),cn=cv(c,i,j+1),csw=cv(c,i-1,j-1),cse=cv(c,i+1,j-1),cnw=cv(c,i-1,j+1),cne=cv(c,i+1,j+1);f->q[IDX(iL,jC,f->nx)]+=(2.0/3)*cc+(1.0/3)*cw;f->q[IDX(iC,jC,f->nx)]+=cc;f->q[IDX(iR,jC,f->nx)]+=(2.0/3)*cc+(1.0/3)*ce;f->q[IDX(iL,jB,f->nx)]+=(4.0/9)*cc+(2.0/9)*cw+(2.0/9)*cs+(1.0/9)*csw;f->q[IDX(iC,jB,f->nx)]+=(2.0/3)*cc+(1.0/3)*cs;f->q[IDX(iR,jB,f->nx)]+=(4.0/9)*cc+(2.0/9)*ce+(2.0/9)*cs+(1.0/9)*cse;f->q[IDX(iL,jT,f->nx)]+=(4.0/9)*cc+(2.0/9)*cw+(2.0/9)*cn+(1.0/9)*cnw;f->q[IDX(iC,jT,f->nx)]+=(2.0/3)*cc+(1.0/3)*cn;f->q[IDX(iR,jT,f->nx)]+=(4.0/9)*cc+(2.0/9)*ce+(2.0/9)*cn+(1.0/9)*cne;}}
static void mg_cycle_ref(Sys*s,int ratio,int levels,int visits){rbgs(s,3);double*r=residual_array(s);Sys c;make_coarse(s,&c,ratio);if(ratio==2)restrict_2x2_ref(s,r,&c);else restrict_3x3_ref(s,r,&c);free(r);if(levels>1&&c.nx>=10&&c.ny>=10){for(int q=0;q<visits;q++)mg_cycle_ref(&c,ratio,levels-1,visits);}else rbgs(&c,40);if(ratio==2)prolong_2to1_ref(&c,s);else prolong_3to1_ref(&c,s);freesys(&c);rbgs(s,3);}
/* Production RMT invariant adaptation: no presmoothing; factor-three nine shifted families;
   two multiple-coarse corrections; 48 coarse sweeps; omega=0.005; three post-smoothing sweeps. */

/* V2: production-structure RMT. The error equation recursively receives the same
   factor-three, 3x3 shifted-family treatment; it does not terminate each shifted
   grid immediately in a direct coarse RBGS solve as V1 did. */

/* MMS V3 RMT kernel: production-structure adaptation of RMT FINAL / FINALVOL2.
 * This file is injected into the generated MMS solver by tools/v3_patch.py.
 */

typedef struct {
    int nx, ny;
    size_t n;
    double *corr;
    double *rhs;
    double *prefix;
} RMTV3Workspace;

static RMTV3Workspace g_rmtv3 = {0};

static void rmt_v3_workspace_release(void){
    free(g_rmtv3.corr);
    free(g_rmtv3.rhs);
    free(g_rmtv3.prefix);
    memset(&g_rmtv3,0,sizeof(g_rmtv3));
}

static RMTV3Workspace *rmt_v3_workspace(Sys *s){
    size_t n=(size_t)s->nx*(size_t)s->ny;
    if(g_rmtv3.nx==s->nx && g_rmtv3.ny==s->ny &&
       g_rmtv3.corr && g_rmtv3.rhs && g_rmtv3.prefix)
        return &g_rmtv3;
    rmt_v3_workspace_release();
    g_rmtv3.nx=s->nx; g_rmtv3.ny=s->ny; g_rmtv3.n=n;
    g_rmtv3.corr=calloc(n,sizeof(double));
    g_rmtv3.rhs=calloc(n,sizeof(double));
    g_rmtv3.prefix=calloc((size_t)(s->nx+1)*(size_t)(s->ny+1),sizeof(double));
    if(!g_rmtv3.corr||!g_rmtv3.rhs||!g_rmtv3.prefix) die("RMT V3 workspace allocation");
    return &g_rmtv3;
}

static int rmt_v3_ipow3(int l){
    int s=1;
    while(l-- > 0) s*=3;
    return s;
}

static int rmt_v3_auto_level_1d(int nInterior,int nCoarsest){
    int l=0,s=1;
    if(nCoarsest<2)nCoarsest=2;
    while((nInterior+s-1)/s > nCoarsest){
        if(s > 100000000/3) break;
        s*=3; l++;
        if(l>=10) break;
    }
    return l;
}

static void rmt_v3_prefix_build_density(Sys*s,const double*r,double*p){
    int nx=s->nx,ny=s->ny,pitch=ny+1;
    const double vol=s->dx*s->dy;
    memset(p,0,(size_t)(nx+1)*(size_t)(ny+1)*sizeof(double));
    for(int i=1;i<nx-1;i++){
        double row=0.0;
        for(int j=1;j<ny-1;j++){
            row += r[IDX(i,j,nx)]/vol;
            p[(size_t)i*pitch+j]=p[(size_t)(i-1)*pitch+j]+row;
        }
    }
}

static inline void rmt_v3_cv_bounds_1d(int n,int idx,int stride,int*lo,int*hi){
    const int last=n-2;
    const int half=(stride-1)/2;
    const int hasMinus=(idx-stride>=1);
    const int hasPlus=(idx+stride<=last);
    *lo=hasMinus?idx-half:1;
    *hi=hasPlus?idx+half:last;
    if(*lo<1)*lo=1;
    if(*hi>last)*hi=last;
}

static double rmt_v3_cv_average(Sys*s,const double*p,int i,int j,int sx,int sy){
    int i1,i2,j1,j2,pitch=s->ny+1;
    rmt_v3_cv_bounds_1d(s->nx,i,sx,&i1,&i2);
    rmt_v3_cv_bounds_1d(s->ny,j,sy,&j1,&j2);
    double sum=p[(size_t)i2*pitch+j2]
              -p[(size_t)(i1-1)*pitch+j2]
              -p[(size_t)i2*pitch+j1-1]
              +p[(size_t)(i1-1)*pitch+j1-1];
    double cnt=(double)(i2-i1+1)*(double)(j2-j1+1);
    return cnt>0.0?sum/cnt:0.0;
}

static void rmt_v3_fill_rhs(Sys*s,const double*prefix,double*rhs,int sx,int sy){
    int nx=s->nx,ny=s->ny;
    #pragma omp parallel for collapse(2) schedule(static)
    for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++)
        rhs[IDX(i,j,nx)]=rmt_v3_cv_average(s,prefix,i,j,sx,sy);
}

static inline void rmt_v3_laplace_dim(int n,int idx,int stride,double h,
                                      double*ap,double*am,double*az){
    int last=n-2;
    int hm=(idx-stride>=1), hp=(idx+stride<=last);
    double H=stride*h;
    *am=0.0; *az=0.0;
    if(hm&&hp){
        double a=1.0/(H*H);
        *ap+=2.0*a; *am=a; *az=a; return;
    }
    if(!hm&&hp){
        double d=idx*h;
        double V=d+0.5*H;
        double an=1.0/(H*V), ab=1.0/(d*V);
        *ap+=an+ab; *az=an; return;
    }
    if(hm&&!hp){
        double d=(n-1-idx)*h;
        double V=d+0.5*H;
        double an=1.0/(H*V), ab=1.0/(d*V);
        *ap+=an+ab; *am=an; return;
    }
    {
        double L=(n-1)*h;
        double d0=idx*h, d1=(n-1-idx)*h;
        if(d0>0.0)*ap+=1.0/(d0*L);
        if(d1>0.0)*ap+=1.0/(d1*L);
    }
}

static inline double rmt_v3_clip(double x,double a,double b){
    return x<a?a:(x>b?b:x);
}

static void rmt_v3_coeff(Sys*s,int i,int j,int sx,int sy,
                         double*ap,double*aw,double*ae,double*as,double*an){
    *ap=*aw=*ae=*as=*an=0.0;
    if(BENCH_ID=='A'){
        rmt_v3_laplace_dim(s->nx,i,sx,s->dx,ap,aw,ae);
        rmt_v3_laplace_dim(s->ny,j,sy,s->dy,ap,as,an);
        return;
    }

    double Hx=sx*s->dx, Hy=sy*s->dy;
    double x=i*s->dx, y=j*s->dy;
    double xe=rmt_v3_clip(x+0.5*Hx,0.0,3.0);
    double xw=rmt_v3_clip(x-0.5*Hx,0.0,3.0);
    double yn=rmt_v3_clip(y+0.5*Hy,0.0,1.0);
    double ys=rmt_v3_clip(y-0.5*Hy,0.0,1.0);

    double re=mms_rho(xe,y,s->st), rw=mms_rho(xw,y,s->st);
    double rn=mms_rho(x,yn,s->st), rs=mms_rho(x,ys,s->st);
    double ue=mms_uadv(xe,y,s->st), uw=mms_uadv(xw,y,s->st);
    double vn=mms_vadv(x,yn,s->st), vs=mms_vadv(x,ys,s->st);
    double de=mms_diff(xe,y,s->st), dw=mms_diff(xw,y,s->st);
    double dn=mms_diff(x,yn,s->st), ds=mms_diff(x,ys,s->st);

    double Fe=re*ue/Hx, Fw=rw*uw/Hx, Fn=rn*vn/Hy, Fs=rs*vs/Hy;
    double De=de/(Hx*Hx), Dw=dw/(Hx*Hx), Dn=dn/(Hy*Hy), Ds=ds/(Hy*Hy);

    *ae=De+fmax(-Fe,0.0);
    *aw=Dw+fmax( Fw,0.0);
    *an=Dn+fmax(-Fn,0.0);
    *as=Ds+fmax( Fs,0.0);
    *ap=*ae+*aw+*an+*as+(Fe-Fw+Fn-Fs);
    if(*ap<1e-30)*ap=1e-30;
}

static inline double rmt_v3_update_point(Sys*s,double*c,const double*rhs,
                                         int i,int j,int sx,int sy){
    int nx=s->nx,ny=s->ny;
    double ap,aw,ae,as,an;
    rmt_v3_coeff(s,i,j,sx,sy,&ap,&aw,&ae,&as,&an);
    double sum=0.0;
    if(i-sx>=1)     sum+=aw*c[IDX(i-sx,j,nx)];
    if(i+sx<=nx-2)  sum+=ae*c[IDX(i+sx,j,nx)];
    if(j-sy>=1)     sum+=as*c[IDX(i,j-sy,nx)];
    if(j+sy<=ny-2)  sum+=an*c[IDX(i,j+sy,nx)];
    return (rhs[IDX(i,j,nx)]+sum)/ap;
}

static long long rmt_v3_smooth_level(Sys*s,double*c,const double*rhs,
                                     int sx,int sy,int sweeps){
    int nx=s->nx,ny=s->ny;
    long long updates=0;
    long long nxy=(long long)(nx-2)*(long long)(ny-2);
    for(int sw=0;sw<sweeps;sw++){
        for(int color=0;color<2;color++){
            #pragma omp parallel for collapse(2) schedule(static) reduction(+:updates) if(nxy>2048)
            for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++){
                int ox=(i-1)%sx, oy=(j-1)%sy;
                int qi=(i-1-ox)/sx, qj=(j-1-oy)/sy;
                if(((qi+qj)&1)!=color)continue;
                c[IDX(i,j,nx)]=rmt_v3_update_point(s,c,rhs,i,j,sx,sy);
                updates++;
            }
        }
    }
    return updates;
}

#define RMT_V3_DIRECT_MAX 64

static int rmt_v3_dense_solve(double*A,double*b,int n){
    for(int k=0;k<n;k++){
        int piv=k; double pv=fabs(A[(size_t)k*n+k]);
        for(int i=k+1;i<n;i++){
            double v=fabs(A[(size_t)i*n+k]);
            if(v>pv){pv=v;piv=i;}
        }
        if(!(pv>1e-300)||!isfinite(pv))return 0;
        if(piv!=k){
            for(int j=k;j<n;j++){
                double t=A[(size_t)k*n+j];
                A[(size_t)k*n+j]=A[(size_t)piv*n+j];
                A[(size_t)piv*n+j]=t;
            }
            double t=b[k]; b[k]=b[piv]; b[piv]=t;
        }
        double akk=A[(size_t)k*n+k];
        for(int i=k+1;i<n;i++){
            double f=A[(size_t)i*n+k]/akk;
            A[(size_t)i*n+k]=0.0;
            for(int j=k+1;j<n;j++)A[(size_t)i*n+j]-=f*A[(size_t)k*n+j];
            b[i]-=f*b[k];
        }
    }
    for(int i=n-1;i>=0;i--){
        double z=b[i];
        for(int j=i+1;j<n;j++)z-=A[(size_t)i*n+j]*b[j];
        double aii=A[(size_t)i*n+i];
        if(!(fabs(aii)>1e-300)||!isfinite(aii))return 0;
        b[i]=z/aii;
    }
    return 1;
}

static void rmt_v3_direct_coarsest(Sys*s,double*c,const double*rhs,
                                   int sx,int sy){
    int nx=s->nx,ny=s->ny,nxi=nx-2,nyi=ny-2;
    int ngx=sx<nxi?sx:nxi, ngy=sy<nyi?sy:nyi;
    int ng=ngx*ngy,failed=0;

    #pragma omp parallel for schedule(dynamic,32) reduction(|:failed) if(ng>8)
    for(int gid=0;gid<ng;gid++){
        int ox=1+gid/ngy, oy=1+gid%ngy;
        int nxg=(ox<=nx-2)?1+(nx-2-ox)/sx:0;
        int nyg=(oy<=ny-2)?1+(ny-2-oy)/sy:0;
        int m=nxg*nyg;
        if(m<=0)continue;
        if(m>RMT_V3_DIRECT_MAX){failed=1;continue;}

        double A[RMT_V3_DIRECT_MAX*RMT_V3_DIRECT_MAX];
        double b[RMT_V3_DIRECT_MAX];
        memset(A,0,(size_t)m*(size_t)m*sizeof(double));

        for(int a=0;a<nxg;a++)for(int q=0;q<nyg;q++){
            int i=ox+a*sx,j=oy+q*sy,row=a*nyg+q;
            double ap,aw,ae,as,an;
            rmt_v3_coeff(s,i,j,sx,sy,&ap,&aw,&ae,&as,&an);
            A[(size_t)row*m+row]=ap;
            if(a>0)       A[(size_t)row*m+(row-nyg)]=-aw;
            if(a+1<nxg)   A[(size_t)row*m+(row+nyg)]=-ae;
            if(q>0)       A[(size_t)row*m+(row-1)]=-as;
            if(q+1<nyg)   A[(size_t)row*m+(row+1)]=-an;
            b[row]=rhs[IDX(i,j,nx)];
        }

        if(!rmt_v3_dense_solve(A,b,m)){failed=1;continue;}
        for(int a=0;a<nxg;a++)for(int q=0;q<nyg;q++){
            int i=ox+a*sx,j=oy+q*sy;
            c[IDX(i,j,nx)]=b[a*nyg+q];
        }
    }
    if(failed)die("RMT V3 direct coarsest solve failed");
}

static void rmt_v3_build_correction(Sys*s,const double*defect,double*c){
    RMTV3Workspace*w=rmt_v3_workspace(s);
    int nxi=s->nx-2,nyi=s->ny-2;
    int lx=rmt_v3_auto_level_1d(nxi,5);
    int ly=rmt_v3_auto_level_1d(nyi,5);
    int lm=lx>ly?lx:ly;

    memset(c,0,w->n*sizeof(double));
    rmt_v3_prefix_build_density(s,defect,w->prefix);

    for(int lc=lm;lc>=0;--lc){
        int lX=lx<lc?lx:lc, lY=ly<lc?ly:lc;
        int sx=rmt_v3_ipow3(lX), sy=rmt_v3_ipow3(lY);
        rmt_v3_fill_rhs(s,w->prefix,w->rhs,sx,sy);
        if(lc==lm)
            rmt_v3_direct_coarsest(s,c,w->rhs,sx,sy);
        else
            rmt_v3_smooth_level(s,c,w->rhs,sx,sy,16);
    }
}

static void rmt_cycle_ref(Sys*s){
    RMTV3Workspace*w=rmt_v3_workspace(s);
    double*r=residual_array(s);
    rmt_v3_build_correction(s,r,w->corr);
    #pragma omp parallel for collapse(2) schedule(static)
    for(int j=1;j<s->ny-1;j++)for(int i=1;i<s->nx-1;i++)
        s->q[IDX(i,j,s->nx)] += w->corr[IDX(i,j,s->nx)];
    free(r);
}


static int solve(Sys*s,const char*solver,double tol,int maxit){
    int it=0;
    if(strcmp(solver,"SG_RBGS")==0){
        while(it<maxit&&residual(s)>tol){rbgs(s,2);it+=2;}
        return it;
    }
    while(it<maxit&&residual(s)>tol){
        if(strcmp(solver,"RMT3H")==0){
            rmt_cycle_ref(s);
            it+=1;
            if(!isfinite(residual(s)))break;
            continue;
        }
        double before=residual(s);
        size_t n=(size_t)s->nx*s->ny;
        double*save=malloc(n*sizeof(double));
        if(!save)die("save");
        memcpy(save,s->q,n*sizeof(double));
        if(strcmp(solver,"MG2V")==0){mg_cycle_ref(s,2,2,1);it+=46;}
        else if(strcmp(solver,"MG2W")==0){mg_cycle_ref(s,2,2,2);it+=86;}
        else if(strcmp(solver,"MG3V")==0){mg_cycle_ref(s,3,2,1);it+=46;}
        else {free(save);die("unknown solver");}
        double after=residual(s);
        if(!isfinite(after)||after>1.5*before){
            memcpy(s->q,save,n*sizeof(double));
            rbgs(s,4);
            it+=4;
        }
        free(save);
    }
    return it;
}

static void norms(Sys*s,double*L1,double*L2,double*Li){double a=0,b=0,c=0;size_t n=(size_t)s->nx*s->ny;
 #pragma omp parallel for reduction(+:a,b) reduction(max:c)
 for(size_t k=0;k<n;k++){double e=fabs(s->q[k]-s->exact[k]);a+=e;b+=e*e;if(e>c)c=e;}*L1=a/n;*L2=sqrt(b/n);*Li=c;}
static void init_zero(Sys*s){for(int j=1;j<s->ny-1;j++)for(int i=1;i<s->nx-1;i++)s->q[IDX(i,j,s->nx)]=0.0;}
static void onevar(int nx,int ny,int st,char var,const char*solver,double *L1,double*L2,double*Li,int*its,double*tm,double*rr){Sys s;allocsys(&s,nx,ny);assemble(&s,var,st);init_zero(&s);double t=wall();*its=solve(&s,solver,1e-9,20000);*tm=wall()-t;*rr=residual(&s);norms(&s,L1,L2,Li);freesys(&s);}
static int finite_sources(int st){for(int j=0;j<9;j++)for(int i=0;i<17;i++){double xx=3.0*i/16.0,yy=j/8.0;double vals[8]={mms_rho(xx,yy,st),mms_diff(xx,yy,st),srcvar('f',xx,yy,st),srcvar('o',xx,yy,st),srcvar('p',xx,yy,st),srcvar('u',xx,yy,st),srcvar('v',xx,yy,st),srcvar('h',xx,yy,st)};for(int k=0;k<8;k++)if(!isfinite(vals[k]))return 0;}return 1;}


typedef struct {double l1,l2,li,t,r;int it;} VR;
static double thermo_h(double T,double YF,double YO,double YP){double YN=1.0-YF-YO-YP;double C=YF*(1800.0+.25*T)+YO*(950.0+.12*T)+YP*(1200.0+.20*T)+YN*(1000.0+.10*T);return C*(T-298.15);}
static double thermo_T(double h,double YF,double YO,double YP,double guess){double T=(guess>200&&guess<2500)?guess:600.0;for(int it=0;it<20;it++){double YN=1.0-YF-YO-YP;double A=YF*1800.0+YO*950.0+YP*1200.0+YN*1000.0;double B=YF*.25+YO*.12+YP*.20+YN*.10;double f=(A+B*T)*(T-298.15)-h;double df=A+B*(2*T-298.15);double d=f/(fabs(df)>1e-12?df:1.0);T-=d;if(T<200)T=200;if(T>2500)T=2500;if(fabs(d)<1e-10*fmax(1.0,T))break;}return T;}
static double thermo_rho(double T,double YF,double YO,double YP){double YN=1.0-YF-YO-YP;double invW=YF/28.01055+YO/31.99880+YP/44.00995+YN/28.01340;double W=1.0/fmax(invW,1e-15);double R=8314.46261815324/W;return 101325.0/fmax(R*T,1.0);}
static double qchem_num(double h,double x,double y,int st){double YF=mms_YF(x,y,st),YO=mms_YO(x,y,st),YP=mms_YP(x,y,st);double T=thermo_T(h,YF,YO,YP,mms_T(x,y,st));double A=mms_arrA(x,y,st),be=mms_arrBeta(x,y,st),Ta=mms_arrTa(x,y,st);double rate=A*pow(fmax(T,200.0),be)*exp(-Ta/fmax(T,200.0))*YF*YF*YO*1e-16;return 2.5e7*rate;}
static void d_rhs_nonlinear(Sys*s,int st){for(int j=1;j<s->ny-1;j++)for(int i=1;i<s->nx-1;i++){int k=IDX(i,j,s->nx);double x=i*s->dx,y=j*s->dy;s->b[k]=(mms_src_h(x,y,st)+qchem_num(s->q[k],x,y,st))*s->dx*s->dy;}}
static void thermo_norms(Sys*s,int st,double*T_L2,double*rho_L2,double*T_rel,double*rho_rel){double et=0,er=0,nt=0,nr=0;long n=0;for(int j=0;j<s->ny;j++)for(int i=0;i<s->nx;i++){int k=IDX(i,j,s->nx);double x=i*s->dx,y=j*s->dy,YF=mms_YF(x,y,st),YO=mms_YO(x,y,st),YP=mms_YP(x,y,st);double Te=mms_T(x,y,st),Tn=thermo_T(s->q[k],YF,YO,YP,Te),re=mms_rho(x,y,st),rn=thermo_rho(Tn,YF,YO,YP);et+=(Tn-Te)*(Tn-Te);er+=(rn-re)*(rn-re);nt+=Te*Te;nr+=re*re;n++;}*T_L2=sqrt(et/n);*rho_L2=sqrt(er/n);*T_rel=sqrt(et/(nt+1e-300));*rho_rel=sqrt(er/(nr+1e-300));}
static void onevar_v2(int nx,int ny,int st,char var,const char*solver,VR*o,double*TL2,double*rL2,double*Trel,double*rrel){Sys s;allocsys(&s,nx,ny);assemble(&s,var,st);init_zero(&s);double t=wall();int it=0;if(BENCH_ID=='D'&&var=='h'){for(int outer=0;outer<8;outer++){d_rhs_nonlinear(&s,st);it+=solve(&s,solver,1e-7,240000);if(residual(&s)<1e-7&&outer>=2)break;}}else it=solve(&s,solver,1e-7,240000);o->t=wall()-t;o->it=it;o->r=residual(&s);norms(&s,&o->l1,&o->l2,&o->li);if(BENCH_ID=='D'&&var=='h')thermo_norms(&s,st,TL2,rL2,Trel,rrel);freesys(&s);}
static double projection_continuity(int nx,int ny,int st,const char*solver){Sys s;allocsys(&s,nx,ny);assemble(&s,'a',st);init_zero(&s);solve(&s,solver,1e-7,240000);double dt=.02,sum=0,den=0;long n=0;for(int j=1;j<ny-1;j++)for(int i=1;i<nx-1;i++){double x=i*s.dx,y=j*s.dy;double xe=x+.5*s.dx,xw=x-.5*s.dx,yn=y+.5*s.dy,ys=y-.5*s.dy;double mpe=mms_rho(xe,y,st)*mms_u_corr(xe,y,st)+dt*mms_dpx(xe,y,st);double mpw=mms_rho(xw,y,st)*mms_u_corr(xw,y,st)+dt*mms_dpx(xw,y,st);double mpn=mms_rho(x,yn,st)*mms_v_corr(x,yn,st)+dt*mms_dpy(x,yn,st);double mps=mms_rho(x,ys,st)*mms_v_corr(x,ys,st)+dt*mms_dpy(x,ys,st);int k=IDX(i,j,nx);double pxe=(s.q[k+1]-s.q[k])/s.dx,pxw=(s.q[k]-s.q[k-1])/s.dx,pyn=(s.q[k+nx]-s.q[k])/s.dy,pys=(s.q[k]-s.q[k-nx])/s.dy;double div=((mpe-dt*pxe)-(mpw-dt*pxw))/s.dx+((mpn-dt*pyn)-(mps-dt*pys))/s.dy;double sm=mms_mass_src(x,y,st);sum+=(div-sm)*(div-sm);den+=sm*sm;n++;}freesys(&s);return sqrt(sum/(den+1e-300));}
static void write_real_field_v2(int nx,int ny,int st,char var,const char*solver,const char*path){Sys s;allocsys(&s,nx,ny);assemble(&s,var,st);init_zero(&s);if(BENCH_ID=='D'&&var=='h'){for(int q=0;q<8;q++){d_rhs_nonlinear(&s,st);solve(&s,solver,1e-7,240000);}}else solve(&s,solver,1e-7,240000);FILE*f=fopen(path,"w");if(!f)die("field output");fprintf(f,"x,y,variable,exact,numerical,error\n");for(int j=0;j<ny;j++)for(int i=0;i<nx;i++){int k=IDX(i,j,nx);double x=i*s.dx,y=j*s.dy,ex=s.exact[k],nu=s.q[k];const char*vv="scalar";if(BENCH_ID=='D'&&var=='h'){double YF=mms_YF(x,y,st),YO=mms_YO(x,y,st),YP=mms_YP(x,y,st);ex=mms_T(x,y,st);nu=thermo_T(s.q[k],YF,YO,YP,ex);vv="T";}fprintf(f,"%.17g,%.17g,%s,%.17g,%.17g,%.17g\n",x,y,vv,ex,nu,nu-ex);}fclose(f);freesys(&s);}
int main(int argc,char**argv){int nx=108,ny=36,st=1;const char*solver="SG_RBGS";const char*out="case_summary.csv";const char*fieldout=NULL;for(int a=1;a<argc;a++){if(!strcmp(argv[a],"--Nx")&&a+1<argc)nx=atoi(argv[++a]);else if(!strcmp(argv[a],"--Ny")&&a+1<argc)ny=atoi(argv[++a]);else if(!strcmp(argv[a],"--stiffness")&&a+1<argc){const char*z=argv[++a];st=z[1]-'0';}else if(!strcmp(argv[a],"--solver")&&a+1<argc)solver=argv[++a];else if(!strcmp(argv[a],"--out")&&a+1<argc)out=argv[++a];else if(!strcmp(argv[a],"--field-out")&&a+1<argc)fieldout=argv[++a];}if(nx<12||ny<8||st<1||st>3)die("bad args");if(!finite_sources(st))die("nonfinite MMS source");char vars[3];int nv=1;if(BENCH_ID=='A')vars[0]='a';else if(BENCH_ID=='B'){vars[0]='u';vars[1]='v';nv=2;}else if(BENCH_ID=='C'){vars[0]='f';vars[1]='o';vars[2]='p';nv=3;}else vars[0]='h';VR vr[3]={{0}};double maxL1=0,maxL2=0,maxLi=0,tot=0,rr=0,TL2=0,rL2=0,Trel=0,rrel=0;int its=0;for(int z=0;z<nv;z++){onevar_v2(nx,ny,st,vars[z],solver,&vr[z],&TL2,&rL2,&Trel,&rrel);maxL1=fmax(maxL1,vr[z].l1);maxL2=fmax(maxL2,vr[z].l2);maxLi=fmax(maxLi,vr[z].li);rr=fmax(rr,vr[z].r);tot+=vr[z].t;its+=vr[z].it;}double cont=(BENCH_ID=='A')?projection_continuity(nx,ny,st,solver):0.0;double p2=(BENCH_ID=='A')?vr[0].l2:0,u2=(BENCH_ID=='B')?vr[0].l2:0,v2=(BENCH_ID=='B')?vr[1].l2:0,YF2=(BENCH_ID=='C')?vr[0].l2:0,YO2=(BENCH_ID=='C')?vr[1].l2:0,YP2=(BENCH_ID=='C')?vr[2].l2:0,h2=(BENCH_ID=='D')?vr[0].l2:0;FILE*f=fopen(out,"w");if(!f)die("output");fprintf(f,"benchmark,stiffness,Nx,Ny,threads,solver,converged,iterations,relative_residual,L1,L2,Linf,solve_wall_time,total_relevant_wall_time,continuity_metric,p_L2,u_L2,v_L2,YF_L2,YO_L2,YP_L2,h_L2,T_L2,rho_L2,T_rel_L2,rho_rel_L2\n");fprintf(f,"%c,S%d,%d,%d,%d,%s,%d,%d,%.12e,%.12e,%.12e,%.12e,%.9f,%.9f,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e,%.12e\n",BENCH_ID,st,nx,ny,omp_get_max_threads(),solver,rr<1e-6,its,rr,maxL1,maxL2,maxLi,tot,tot,cont,p2,u2,v2,YF2,YO2,YP2,h2,TL2,rL2,Trel,rrel);fclose(f);if(fieldout)write_real_field_v2(nx,ny,st,vars[0],solver,fieldout);printf("BENCH=%c solver=%s residual=%.3e L2=%.3e cont=%.3e time=%.6f\n",BENCH_ID,solver,rr,maxL2,cont,tot);return rr<1e-6?0:3;}
