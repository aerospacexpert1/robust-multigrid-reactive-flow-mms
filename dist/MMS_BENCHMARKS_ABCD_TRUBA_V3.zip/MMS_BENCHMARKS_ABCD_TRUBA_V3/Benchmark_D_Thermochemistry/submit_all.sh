#!/usr/bin/env bash
set -euo pipefail
mkdir -p logs
echo "Submitting Benchmark D: 300 cases as three 100-case arrays"
echo "TRUBA MaxArraySize=100"
echo "Maximum simultaneous cases = 3"

JOB1_RAW=$(sbatch --parsable --array=0-99%3 --export=ALL,TASK_OFFSET=0 benchmark_D_array.slurm)
JOB1="${JOB1_RAW%%;*}"
JOB2_RAW=$(sbatch --parsable --dependency=afterany:${JOB1} --array=0-99%3 --export=ALL,TASK_OFFSET=100 benchmark_D_array.slurm)
JOB2="${JOB2_RAW%%;*}"
JOB3_RAW=$(sbatch --parsable --dependency=afterany:${JOB2} --array=0-99%3 --export=ALL,TASK_OFFSET=200 benchmark_D_array.slurm)
JOB3="${JOB3_RAW%%;*}"

cat > campaign_jobs.txt <<EOT
Benchmark D
Batch 1: real tasks   0-99  -> job $JOB1
Batch 2: real tasks 100-199 -> job $JOB2
Batch 3: real tasks 200-299 -> job $JOB3
EOT
cat campaign_jobs.txt
