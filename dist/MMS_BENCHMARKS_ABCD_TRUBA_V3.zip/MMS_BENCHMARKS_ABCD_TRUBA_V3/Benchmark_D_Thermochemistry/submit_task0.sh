#!/usr/bin/env bash
set -euo pipefail
mkdir -p logs
sbatch --array=0 --export=ALL,TASK_OFFSET=0 benchmark_D_array.slurm
