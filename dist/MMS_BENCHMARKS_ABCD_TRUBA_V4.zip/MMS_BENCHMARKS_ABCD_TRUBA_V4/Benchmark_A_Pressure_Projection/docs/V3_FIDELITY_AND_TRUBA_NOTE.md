# MMS_BENCHMARKS_ABCD_TRUBA_V4

## RMT correction

V2 built an 18-way recursive allocation tree at every RMT level.  V3 removes
that tree and follows the RMT FINAL / FINALVOL2 computational structure: one
reusable fine-index correction workspace, automatic factor-three hierarchy,
one coarsest-to-finest sawtooth traversal, simultaneous shifted families,
fine-defect prefix reuse, direct tiny coarsest solves, 16 RBGS postsmoothing
sweeps per noncoarsest level, and full correction with omega=1.

There is no V2 residual-monotonic line search and no hidden SG-RBGS fallback in
the RMT branch.  Benchmark A is the direct pressure-solver comparison; B--D
remain operator-solver extensions.

## TRUBA MaxArraySize

The 300-row manifest is unchanged.  Because TRUBA MaxArraySize=100, submit_all.sh
creates three chained arrays with local indices 0--99 and offsets 0, 100, 200.
Each array retains %3 concurrency.  Slurm logs print TASK_OFFSET and REAL_TASK_ID.
