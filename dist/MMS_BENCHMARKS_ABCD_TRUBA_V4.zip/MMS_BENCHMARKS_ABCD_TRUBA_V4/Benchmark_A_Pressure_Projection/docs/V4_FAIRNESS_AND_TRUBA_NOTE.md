# MMS_BENCHMARKS_ABCD_TRUBA_V4

## Fair-comparison contract

V4 retains the validated V3 RMT structure and repairs the conventional
geometric-MG comparison.

All five methods solve the same fine-grid discrete equation, use the same zero
interior initial guess and the same residual stopping tolerance. The logical
campaign Nx x Ny values are interval/cell counts and the numerical system uses
Nx+1 by Ny+1 nodal points, so every campaign mesh is exactly nested under both
factor-two and factor-three coarsening.

MG2V/MG2W/MG3V use dimensionally consistent residual transfer: the integrated
fine residual is converted to residual density, tensor-product full weighting
is performed, then the coarse density is multiplied by coarse control-volume
area for the rediscretized integrated coarse equation. Coarse geometry is
exactly nested and prolongation is bilinear. There is no rollback, line search
or hidden SG-RBGS fallback.

RMT3H keeps the V3 production-structure adaptation: factor-three shifted
families, automatic independent x/y depth, one fine-index correction
workspace, coarsest-to-finest sawtooth, fine-defect CV restriction, direct tiny
coarsest solves, 16 noncoarsest postsmoothing sweeps and full correction.

Benchmark A is the direct pressure-solver comparison. B-D remain
operator-solver extensions.

## TRUBA submission

The 300-row manifest is preserved, but Slurm sees only 60 physical groups:

    #SBATCH --array=0-59%3

Each array task runs the five consecutive solver rows sequentially. This avoids
both MaxArraySize=100 and the previous 300-job/QOS submission problem while
retaining 300 total solver executions.
