#!/usr/bin/env bash
set -euo pipefail
group="${1:?physical group index 0..59 required}"
if (( group < 0 || group > 59 )); then
    echo "group must be 0..59" >&2
    exit 2
fi
mkdir -p logs
sbatch --array="${group}" benchmark_A_array.slurm
