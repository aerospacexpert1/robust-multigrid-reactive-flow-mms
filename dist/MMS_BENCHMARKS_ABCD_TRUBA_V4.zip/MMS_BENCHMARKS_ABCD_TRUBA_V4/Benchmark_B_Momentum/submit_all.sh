#!/usr/bin/env bash
set -euo pipefail
mkdir -p logs
echo "Submitting Benchmark B: 60 physical groups x 5 solvers = 300 executions"
echo "Maximum simultaneous physical groups = 3"
sbatch benchmark_B_array.slurm
