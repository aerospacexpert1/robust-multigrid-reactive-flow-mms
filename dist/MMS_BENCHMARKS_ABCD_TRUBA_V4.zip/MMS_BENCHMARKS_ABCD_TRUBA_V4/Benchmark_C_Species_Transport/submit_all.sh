#!/usr/bin/env bash
set -euo pipefail
mkdir -p logs
echo "Submitting Benchmark C: 60 physical groups x 5 solvers = 300 executions"
echo "Maximum simultaneous physical groups = 3"
sbatch benchmark_C_array.slurm
